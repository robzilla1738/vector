import{o as a,a as o,s as m}from"./Bf-P7Pph.js";import"./B2Bts-Xg.js";const i=a({ids:o(m().min(1).max(200)).min(1).max(200)});export{i as DownloadsRemoveParams};
