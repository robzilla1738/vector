import{j as a}from"./CQeDwUl9.js";function s(){return a.jsx("span",{className:"aux-mark aux-brand-mark",role:"img","aria-label":"Aux"})}export{s as A};
