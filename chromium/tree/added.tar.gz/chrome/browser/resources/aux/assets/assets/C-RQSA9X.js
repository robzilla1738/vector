import{c as e,l as a,o,b as s}from"./Bf-P7Pph.js";const t=e([a(0),a(1),a(15),a(30),a(60)]),r=o({minutes:t,managed:s()}).strict();export{r as M,t as a};
