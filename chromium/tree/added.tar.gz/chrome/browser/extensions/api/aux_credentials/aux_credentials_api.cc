// Copyright 2026 Aux Authors. All rights reserved.
#include "chrome/browser/extensions/api/aux_credentials/aux_credentials_api.h"

#include "base/functional/bind.h"
#include "base/uuid.h"
#include "chrome/browser/aux/component_bootstrap.h"
#include "chrome/browser/aux/passkeys/request_broker.h"
#include "extensions/common/extension.h"
namespace extensions {
ExtensionFunction::ResponseAction AuxCredentialsFunction::RunAux() {
  const std::string method = name();
  if (!extension() || extension()->id() != aux::kVaultExtensionId) {
    return RespondNow(Error("Only Aux Vault may access passkey requests."));
  }
  if (args().empty() || !args()[0].is_string() ||
      !base::Uuid::ParseLowercase(args()[0].GetString()).is_valid()) {
    return RespondNow(Error("An active passkey request ID is required."));
  }
  const auto id = args()[0].GetString();
  if (method == "auxCredentials.getRequest" && args().size() == 1) {
    aux::passkeys::ReadRequest(
        profile(), id,
        base::BindOnce(
            [](scoped_refptr<AuxCredentialsFunction> self,
               std::optional<base::DictValue> request) {
              if (request) {
                self->Respond(self->WithArguments(std::move(*request)));
              } else {
                self->Respond(self->Error(
                    "Passkey request is unavailable, canceled or locked."));
              }
            },
            base::WrapRefCounted(this)));
    return RespondLater();
  }
  if (method == "auxCredentials.reject" && args().size() == 1) {
    return RespondNow(WithArguments(aux::passkeys::Reject(profile(), id)));
  }
  if (method == "auxCredentials.complete" && args().size() == 2 &&
      args()[1].is_dict()) {
    aux::passkeys::Complete(profile(), id, args()[1].Clone(),
                            base::BindOnce(
                                [](scoped_refptr<AuxCredentialsFunction> self,
                                   std::optional<std::string> error) {
                                  if (error) {
                                    self->Respond(self->Error(*error));
                                  } else {
                                    self->Respond(self->WithArguments(true));
                                  }
                                },
                                base::WrapRefCounted(this)));
    return RespondLater();
  }
  return RespondNow(Error("Unsupported passkey request operation."));
}
}  // namespace extensions
