// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_CREDENTIALS_AUX_CREDENTIALS_API_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_CREDENTIALS_AUX_CREDENTIALS_API_H_
#include "chrome/browser/extensions/api/aux_common/aux_api.h"
namespace extensions {
class AuxCredentialsFunction : public AuxFunction {
 protected:
  ~AuxCredentialsFunction() override = default;
  ResponseAction RunAux() override;
};
#define AUX_CREDENTIAL_FUNCTION(Class, Method, Histogram) \
  class Class final : public AuxCredentialsFunction {     \
   public:                                                \
    DECLARE_EXTENSION_FUNCTION(Method, Histogram)         \
   protected:                                             \
    ~Class() override = default;                          \
  };
AUX_CREDENTIAL_FUNCTION(AuxCredentialsGetRequestFunction,
                        "auxCredentials.getRequest",
                        AUXCREDENTIALS_GETREQUEST)
AUX_CREDENTIAL_FUNCTION(AuxCredentialsCompleteFunction,
                        "auxCredentials.complete",
                        AUXCREDENTIALS_COMPLETE)
AUX_CREDENTIAL_FUNCTION(AuxCredentialsRejectFunction,
                        "auxCredentials.reject",
                        AUXCREDENTIALS_REJECT)
#undef AUX_CREDENTIAL_FUNCTION
}  // namespace extensions
#endif
