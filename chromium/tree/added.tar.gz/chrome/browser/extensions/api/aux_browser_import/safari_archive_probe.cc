// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include <iostream>

#include "base/check.h"
#include "base/files/file_util.h"
#include "base/files/scoped_temp_dir.h"
#include "chrome/browser/extensions/api/aux_browser_import/safari_archive.h"
#include "third_party/zlib/google/zip.h"
namespace {
std::string Archive(const std::string& name, const std::string& text) {
  base::ScopedTempDir temp;
  CHECK(temp.CreateUniqueTempDir());
  auto input = temp.GetPath().AppendASCII("input");
  CHECK(base::CreateDirectory(input));
  CHECK(base::WriteFile(input.AppendASCII(name), text));
  auto output = temp.GetPath().AppendASCII("fixture.zip");
  CHECK(zip::Zip(input, output, true));
  std::string bytes;
  CHECK(base::ReadFileToString(output, &bytes));
  return bytes;
}
}  // namespace
int main() {
  auto history = aux_import::ReadSafariArchive(
      Archive(
          "History - Work.json",
          R"JSON({"metadata":{"data_type":"history","schema_version":1},"history":[{"url":"https://fixture.test/visit","title":"Safari fixture","time_usec":1700000000000123,"visit_count":7}]})JSON"),
      "history");
  CHECK(!history.FindString("error"));
  const auto& row = (*history.FindList("visits"))[0].GetDict();
  CHECK_EQ(*row.FindString("timeMicros"), "1700000000000123");
  CHECK_EQ(row.FindInt("visitCount").value_or(0), 7);
  CHECK(row.FindBool("summaryOnly").value_or(false));
  auto passwords = aux_import::ReadSafariArchive(
      Archive("Passwords.csv",
              "Title,URL,Username,Password,Notes\nFixture,https://fixture.test/"
              ",fixture-user,fixture-password,fixture-note\n"),
      "passwords");
  CHECK(!passwords.FindString("error"));
  const auto& password = (*passwords.FindList("passwords"))[0].GetDict();
  CHECK_EQ(*password.FindString("secret"), "fixture-password");
  CHECK_EQ(*password.FindString("username"), "fixture-user");
  auto html = aux_import::ReadSafariArchive(
      Archive("Bookmarks.html",
              "<!DOCTYPE NETSCAPE-Bookmark-file-1><DL><DT><A "
              "HREF=\"https://fixture.test/\">Fixture</A></DL>"),
      "bookmarks");
  CHECK(html.FindString("bookmarkHTML"));
  CHECK(aux_import::ReadSafariArchive("not a ZIP", "history")
            .FindString("error"));
  CHECK(aux_import::ReadSafariArchive(Archive("Bookmarks.html", "invalid file"),
                                      "bookmarks")
            .FindString("error"));
  CHECK(aux_import::ReadSafariArchive(
            Archive("History.json",
                    "{\"metadata\":{\"data_type\":\"wrong\"},\"history\":[]}"),
            "history")
            .FindString("error"));
  CHECK(aux_import::ReadSafariArchive(
            Archive("Passwords.csv", "not,a,password,header\n1,2,3,4"),
            "passwords")
            .FindString("error"));
  CHECK(aux_import::ReadSafariArchive(
            Archive("Bookmarks.html",
                    "<!DOCTYPE NETSCAPE-Bookmark-file-1><DL></DL>"),
            "passwords")
            .FindString("error"));
  auto traversal = Archive("SAFE.txt", "fixture");
  for (size_t offset = 0;
       (offset = traversal.find("SAFE.txt", offset)) != std::string::npos;
       offset += 8) {
    traversal.replace(offset, 8, "../x.txt");
  }
  CHECK(
      aux_import::ReadSafariArchive(traversal, "history").FindString("error"));
  CHECK(aux_import::ReadSafariArchive(
            Archive("Passwords.csv", std::string(8 * 1024 * 1024 + 1, 'x')),
            "passwords")
            .FindString("error"));
  std::cout << "Disposable Safari ZIP history timestamps/counts, password CSV, "
               "bookmark envelope, malformed/missing category probes passed\n";
}
