// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
// arc_fixture_probe <fixtures/arc>: the Arc sidebar read through the real
// migrator must equal expected-default-profile.json.
#include <iostream>

#include "base/check.h"
#include "base/command_line.h"
#include "base/files/file_util.h"
#include "base/files/scoped_temp_dir.h"
#include "base/json/json_reader.h"
#include "base/values.h"
#include "chrome/browser/extensions/api/aux_browser_import/migrator.h"

int main(int argc, char* argv[]) {
  base::CommandLine::Init(argc, argv);
  const auto args = base::CommandLine::ForCurrentProcess()->GetArgs();
  CHECK_EQ(args.size(), 1u);
  const base::FilePath fixture(args[0]);
  base::ScopedTempDir temp;
  CHECK(temp.CreateUniqueTempDir());
  const auto profile = temp.GetPath().AppendASCII("User Data").AppendASCII("Default");
  CHECK(base::CreateDirectory(profile));
  CHECK(base::CopyFile(fixture.AppendASCII("StorableSidebar.json"),
                       temp.GetPath().AppendASCII("StorableSidebar.json")));
  std::string expected_text;
  CHECK(base::ReadFileToString(fixture.AppendASCII("expected-default-profile.json"),
                               &expected_text));
  auto expected = base::JSONReader::Read(expected_text, base::JSON_PARSE_RFC);
  CHECK(expected);
  CHECK(base::WriteFile(profile.AppendASCII("Bookmarks"), R"({"roots":{}})"));
  auto snapshot = aux_import::ReadChromiumMigrationSnapshot(profile, "arc", {"bookmarks"});
  const auto* error = snapshot.FindString("error");
  CHECK(!error) << *error;
  const auto* spaces = snapshot.FindList("snapshots")->front().GetDict().FindDict("arcSpaces");
  CHECK(spaces);
  CHECK_EQ(*spaces, expected->GetDict());
  std::cout << "arc fixture ok\n";
  return 0;
}
