// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
// Approved native/adblock-import I1/I2; Chromium public parser APIs and the
// Safari portability schema documented by Apple, not reference source code.
#include "chrome/browser/extensions/api/aux_browser_import/safari_archive.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <set>
#include <vector>

#include "base/files/file_path.h"
#include "base/json/json_reader.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "components/password_manager/core/browser/import/csv_password_sequence.h"
#include "third_party/zlib/google/zip_reader.h"
#include "url/gurl.h"
#include "url/origin.h"
namespace aux_import {
namespace {
constexpr size_t kArchiveLimit = 16 * 1024 * 1024;
constexpr size_t kOutputLimit = 32 * 1024 * 1024;
bool SafePath(std::string_view raw) {
  if (raw.empty() || raw.size() > 1024 || !base::IsStringUTF8(raw) ||
      raw.find('\0') != raw.npos || raw.find('\\') != raw.npos ||
      raw.find(':') != raw.npos) {
    return false;
  }
  const auto path = base::FilePath::FromUTF8Unsafe(raw);
  if (path.IsAbsolute() || path.ReferencesParent()) {
    return false;
  }
  for (const auto& segment : path.GetComponents()) {
    if (segment == "." || segment == "..") {
      return false;
    }
  }
  return true;
}
std::optional<int64_t> Integer(const base::DictValue& row,
                               std::string_view key) {
  const auto* value = row.Find(key);
  if (!value) {
    return {};
  }
  if (value->is_int()) {
    return value->GetInt();
  }
  if (!value->is_double()) {
    return {};
  }
  const double number = value->GetDouble();
  if (!std::isfinite(number) || number < 0 || number > 9007199254740991.0 ||
      std::floor(number) != number) {
    return {};
  }
  return static_cast<int64_t>(number);
}
base::DictValue Failure(std::string reason) {
  return base::DictValue().Set("error", std::move(reason));
}
}  // namespace
base::DictValue ReadSafariArchive(std::string bytes, std::string category) {
  if (bytes.empty() || bytes.size() > kArchiveLimit) {
    return Failure("Safari ZIP must be between 1 byte and 16 MiB");
  }
  if (category != "bookmarks" && category != "passwords" &&
      category != "history") {
    return Failure("This Safari export category is not supported");
  }
  zip::ZipReader archive;
  if (!archive.OpenFromString(bytes)) {
    return Failure("Selected file is not a readable ZIP archive");
  }
  struct File {
    std::string name, text;
  };
  std::vector<File> files;
  std::set<base::FilePath> seen;
  size_t entries = 0, output = 0;
  int64_t declared = 0;
  while (const auto* entry = archive.Next()) {
    if (++entries > 1024 || entry->is_unsafe || entry->is_symbolic_link ||
        !SafePath(entry->path_in_original_encoding) ||
        entry->path.IsAbsolute() || entry->path.ReferencesParent()) {
      return Failure(
          "Safari ZIP contains an unsafe path, link or too many entries");
    }
    if (entry->is_encrypted) {
      return Failure(
          "Encrypted ZIP archives are not supported; choose an unencrypted "
          "Safari export");
    }
    if (entry->original_size < 0 || entry->original_size > 128 * 1024 * 1024 ||
        declared > 128 * 1024 * 1024 - entry->original_size) {
      return Failure("Safari ZIP exceeds the declared content size limit");
    }
    declared += entry->original_size;
    if (entry->is_directory) {
      continue;
    }
    if (!seen.insert(entry->path).second) {
      return Failure("Safari ZIP contains duplicate file paths");
    }
    const auto name = base::ToLowerASCII(entry->path.BaseName().value());
    const bool chosen =
        category == "bookmarks" ? name == "bookmarks.html"
        : category == "passwords"
            ? name == "passwords.csv"
            : name == "history.json" ||
                  (name.starts_with("history - ") && name.ends_with(".json"));
    if (!chosen) {
      continue;
    }
    if (files.size() >= 128 || (category != "history" && !files.empty())) {
      return Failure(
          "Safari ZIP contains duplicate or excessive selected category files");
    }
    std::string text;
    if (!archive.ExtractCurrentEntryToString(
            std::min<size_t>(8 * 1024 * 1024, kOutputLimit - output), &text)) {
      return Failure(
          "Safari ZIP content is corrupt or exceeds the decompressed size "
          "limit");
    }
    output += text.size();
    if (!base::IsStringUTF8(text) || text.find('\0') != text.npos) {
      return Failure("Safari category file contains invalid text");
    }
    files.push_back({entry->path.value(), std::move(text)});
  }
  if (!archive.ok()) {
    return Failure("Safari ZIP directory or checksum is invalid");
  }
  if (files.empty()) {
    return Failure("Selected Safari export does not contain this category");
  }
  if (category == "bookmarks") {
    const auto lower = base::ToLowerASCII(files.front().text);
    if (lower.find("netscape-bookmark-file") == lower.npos ||
        lower.find("<dl") == lower.npos) {
      return Failure(
          "Safari bookmark file does not have a supported export envelope");
    }
    return base::DictValue().Set("bookmarkHTML", std::move(files.front().text));
  }
  base::ListValue rows;
  if (category == "passwords") {
    password_manager::CSVPasswordSequence csv(std::move(files.front().text));
    if (csv.result() != password_manager::CSVPassword::Status::kOK) {
      return Failure("Safari password CSV has an invalid header");
    }
    size_t decoded = 0;
    for (const auto& item : csv) {
      if (rows.size() >= 50000 ||
          item.GetParseStatus() != password_manager::CSVPassword::Status::kOK ||
          !item.GetURL().has_value() ||
          !item.GetURL().value().SchemeIsHTTPOrHTTPS() ||
          item.GetPassword().empty() || item.GetPassword().size() > 4096 ||
          item.GetUsername().size() > 1024 || item.GetNote().size() > 16384) {
        return Failure(
            "Safari password CSV contains an invalid record or exceeds row "
            "limits");
      }
      const auto& url = item.GetURL().value();
      decoded += url.spec().size() + item.GetUsername().size() +
                 item.GetPassword().size() + item.GetNote().size() + 256;
      if (decoded > kOutputLimit) {
        return Failure("Safari password CSV exceeds the decoded size limit");
      }
      base::DictValue row;
      row.Set("url", url.spec());
      row.Set("action", "");
      row.Set("realm", url::Origin::Create(url).GetURL().spec());
      row.Set("usernameElement", "");
      row.Set("passwordElement", "");
      row.Set("username", item.GetUsername());
      row.Set("secret", item.GetPassword());
      row.Set("note", item.GetNote());
      row.Set("scheme", 0);
      row.Set("timesUsed", 0);
      row.Set("created", "0");
      row.Set("used", "0");
      row.Set("modified", "0");
      rows.Append(std::move(row));
    }
    return base::DictValue().Set("passwords", std::move(rows));
  }
  size_t decoded = 0;
  for (const auto& file : files) {
    auto root = base::JSONReader::ReadDict(file.text, base::JSON_PARSE_RFC);
    const auto* metadata = root ? root->FindDict("metadata") : nullptr;
    const auto* type = metadata ? metadata->FindString("data_type") : nullptr;
    const auto* history = root ? root->FindList("history") : nullptr;
    if (!type || *type != "history" || !history) {
      return Failure("Safari history export has invalid metadata or records");
    }
    for (const auto& item : *history) {
      if (!item.is_dict() || rows.size() >= 200000) {
        return Failure("Safari history record or row limit is invalid");
      }
      const auto& entry = item.GetDict();
      const auto* url = entry.FindString("url");
      const auto* title = entry.FindString("title");
      const auto time = Integer(entry, "time_usec"),
                 count = Integer(entry, "visit_count");
      if (!url || url->size() > 8192 || (title && title->size() > 8192) ||
          !GURL(*url).SchemeIsHTTPOrHTTPS() || !time || *time <= 0 || !count ||
          *count <= 0 || *count > std::numeric_limits<int>::max()) {
        return Failure("Safari history has an invalid URL, timestamp or count");
      }
      decoded += url->size() + (title ? title->size() : 0) + 256;
      if (decoded > 64 * 1024 * 1024) {
        return Failure("Safari history exceeds the decoded row size limit");
      }
      base::DictValue row;
      row.Set("url", *url);
      row.Set("title", title ? *title : "");
      row.Set("timeMicros", base::NumberToString(*time));
      row.Set("unixTime", true);
      row.Set("summaryOnly", true);
      row.Set("visitCount", static_cast<int>(*count));
      row.Set("typedCount", 0);
      row.Set("transition", 0);
      row.Set("sourceProfile", file.name);
      rows.Append(std::move(row));
    }
  }
  return base::DictValue().Set("visits", std::move(rows));
}
}  // namespace aux_import
