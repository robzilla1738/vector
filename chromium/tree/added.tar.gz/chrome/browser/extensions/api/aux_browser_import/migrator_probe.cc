// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include <iostream>

#include "base/check.h"
#include "base/environment.h"
#include "base/files/file_util.h"
#include "base/files/scoped_temp_dir.h"
#include "chrome/browser/extensions/api/aux_browser_import/migrator.h"
#include "third_party/sqlite/sqlite3.h"
namespace {
void SQLite(const base::FilePath& path, const char* sql) {
  sqlite3* db = nullptr;
  CHECK_EQ(sqlite3_open(path.value().c_str(), &db), SQLITE_OK);
  CHECK_EQ(sqlite3_exec(db, sql, nullptr, nullptr, nullptr), SQLITE_OK);
  CHECK_EQ(sqlite3_close(db), SQLITE_OK);
}
}  // namespace
int main() {
  CHECK_EQ(sqlite3_initialize(), SQLITE_OK);
  base::ScopedTempDir temp;
  CHECK(temp.CreateUniqueTempDir());
  const auto profile = base::MakeAbsoluteFilePath(temp.GetPath());
  CHECK(!profile.empty());
  SQLite(
      profile.AppendASCII("History"),
      "CREATE TABLE urls(id INTEGER PRIMARY KEY,url TEXT,title "
      "TEXT,visit_count INTEGER,typed_count INTEGER);CREATE TABLE visits(id "
      "INTEGER PRIMARY KEY,url INTEGER,visit_time INTEGER,transition "
      "INTEGER);INSERT INTO urls VALUES(1,'https://fixture.test/path','Fixture "
      "title',2,1);INSERT INTO visits "
      "VALUES(1,1,13200000000000001,1),(2,1,13200000000000002,0);");
  auto history = aux_import::ReadCategory(profile, false, "history");
  CHECK(!history.FindString("error")) << history.FindString("error")->c_str();
  auto* visits = history.FindList("visits");
  CHECK(visits);
  CHECK_EQ(visits->size(), 2u);
  CHECK_EQ(*(*visits)[0].GetDict().FindString("timeMicros"),
           "13200000000000001");
  CHECK_EQ((*visits)[0].GetDict().FindInt("typedCount").value_or(-1), 1);
  CHECK_EQ(*(*visits)[0].GetDict().FindString("title"), "Fixture title");
  CHECK(base::WriteFile(
      profile.AppendASCII("Bookmarks"),
      R"JSON({"roots":{"bookmark_bar":{"children":[{"type":"folder","name":"Folder","children":[{"type":"url","name":"Child","url":"https://fixture.test/child","date_added":"13200000000000000"}]}]},"other":{"children":[{"type":"url","name":"Other","url":"https://fixture.test/other"}]},"synced":{"children":[{"type":"url","name":"Mobile","url":"https://fixture.test/mobile"}]}}})JSON"));
  auto bookmarks = aux_import::ReadCategory(profile, false, "bookmarks");
  CHECK(!bookmarks.FindString("error"));
  CHECK_EQ(bookmarks.FindList("bookmarks")->size(), 4u);
  CHECK_EQ(
      (*bookmarks.FindList("bookmarks"))[1].GetDict().FindList("path")->size(),
      1u);
  CHECK(base::WriteFile(
      profile.AppendASCII("Preferences"),
      R"JSON({"intl":{"accept_languages":"en-US,fr"},"homepage":"https://fixture.test/","os_crypt":{"encrypted_key":"never-import-this"},"aux":{"profile_lock":"never-copy"}})JSON"));
  auto preferences = aux_import::ReadCategory(profile, false, "preferences");
  CHECK(!preferences.FindString("error"));
  CHECK_EQ(preferences.FindDict("preferences")->size(), 2u);
  CHECK(!preferences.FindDict("preferences")->Find("os_crypt"));
  SQLite(profile.AppendASCII("places.sqlite"),
         "CREATE TABLE moz_places(id INTEGER PRIMARY KEY,url TEXT,title "
         "TEXT,visit_count INTEGER,typed INTEGER);CREATE TABLE "
         "moz_historyvisits(id INTEGER,place_id INTEGER,visit_date "
         "INTEGER,visit_type INTEGER);CREATE TABLE moz_bookmarks(id "
         "INTEGER,parent INTEGER,type INTEGER,title TEXT,fk INTEGER,dateAdded "
         "INTEGER,position INTEGER);INSERT INTO moz_places "
         "VALUES(1,'https://firefox.fixture/','Firefox fixture',1,1);INSERT "
         "INTO moz_historyvisits VALUES(1,1,1700000000000123,2);INSERT INTO "
         "moz_bookmarks "
         "VALUES(2,1,2,'toolbar',NULL,1700000000000000,0),(10,2,1,'Firefox "
         "fixture',1,1700000000000000,0);");
  auto firefox = aux_import::ReadCategory(profile, true, "history");
  CHECK(!firefox.FindString("error"));
  CHECK_EQ(*(*firefox.FindList("visits"))[0].GetDict().FindString("timeMicros"),
           "1700000000000123");
  CHECK((*firefox.FindList("visits"))[0]
            .GetDict()
            .FindBool("unixTime")
            .value_or(false));
  CHECK_EQ(aux_import::ReadCategory(profile, true, "bookmarks")
               .FindList("firefoxBookmarks")
               ->size(),
           2u);
  SQLite(
      profile.AppendASCII("cookies.sqlite"),
      "CREATE TABLE "
      "moz_cookies(host,name,path,value,creationTime,expiry,lastAccessed,"
      "isSecure,isHttpOnly,sameSite,originAttributes);INSERT INTO moz_cookies "
      "VALUES('.firefox.fixture','test','/"
      "','fixture-value',1700000000000123,1700000000,1700000000000456,1,1,2,''"
      ")");
  auto cookies = aux_import::ReadCategory(profile, true, "cookies");
  CHECK(!cookies.FindString("error"));
  CHECK_EQ(*(*cookies.FindList("cookies"))[0].GetDict().FindString("expires"),
           "13344473600000000");
  CHECK_EQ(*(*cookies.FindList("cookies"))[0].GetDict().FindString("created"),
           "13344473600000123");
  SQLite(profile.AppendASCII("cookies.sqlite"),
         "UPDATE moz_cookies SET originAttributes='^userContextId=2'");
  CHECK(aux_import::ReadCategory(profile, true, "cookies").FindString("error"));
  CHECK(aux_import::ReadCategory(profile, false, "passwords")
            .FindString("error"));
#if !defined(OFFICIAL_BUILD)
  base::ScopedTempDir fixture_home;
  CHECK(fixture_home.CreateUniqueTempDir());
  const auto home = base::MakeAbsoluteFilePath(fixture_home.GetPath());
  CHECK(base::SetPosixFilePermissions(home, 0700));
  const auto support = home.AppendASCII("Library/Application Support");
  for (const auto* directory :
       {"Google/Chrome", "BraveSoftware/Brave-Browser", "Arc/User Data",
        "Dia/User Data", "com.openai.atlas", "Comet", "net.imput.helium",
        "Microsoft Edge"}) {
    const auto root = support.AppendASCII(directory);
    CHECK(base::CreateDirectory(root.AppendASCII("Default")));
    CHECK(base::WriteFile(
        root.AppendASCII("Local State"),
        R"JSON({"profile":{"info_cache":{"Default":{"name":"Fixture profile"}}}})JSON"));
  }
  const auto firefox_root =
      support.AppendASCII("Firefox/Profiles/fixture-profile");
  CHECK(base::CreateDirectory(firefox_root));
  CHECK(base::WriteFile(firefox_root.AppendASCII("places.sqlite"), ""));
  auto environment = base::Environment::Create();
  CHECK(environment->SetVar("AUX_IMPORT_FIXTURE_HOME", home.value()));
  auto sources = aux_import::DiscoverSources();
  CHECK_EQ(sources.size(), 10u);
  for (const auto& entry : sources) {
    const auto& source = entry.GetDict();
    const auto* id = source.FindString("id");
    CHECK(id);
    CHECK(source.FindBool("installed").value_or(false));
    CHECK_EQ(source.FindList("profiles")->size(), 1u);
    if (*id == "safari") {
      continue;
    }
    CHECK(source.FindBool("nativeFixture").value_or(false));
    for (const auto& category : *source.FindList("categories")) {
      CHECK_NE(category.GetString(), "passwords");
    }
    if (*id != "firefox") {
      for (const auto& category : *source.FindList("categories")) {
        CHECK_NE(category.GetString(), "cookies");
      }
    }
    const auto* native_path =
        (*source.FindList("profiles"))[0].GetDict().FindString("nativePath");
    CHECK(native_path);
    CHECK(home.IsParent(base::FilePath(*native_path)));
  }
  base::ScopedTempDir outside;
  CHECK(outside.CreateUniqueTempDir());
  const auto chrome = support.AppendASCII("Google/Chrome"),
             moved = outside.GetPath().AppendASCII("fixture-chrome");
  CHECK(base::Move(chrome, moved));
  CHECK(base::CreateSymbolicLink(moved, chrome));
  sources = aux_import::DiscoverSources();
  for (const auto& entry : sources) {
    if (*entry.GetDict().FindString("id") == "chrome") {
      CHECK(entry.GetDict().FindList("profiles")->empty());
    }
  }
  CHECK(environment->SetVar("AUX_IMPORT_FIXTURE_HOME", "/"));
  CHECK(aux_import::DiscoverSources().empty());
#endif
  std::cout
      << "Read-only native Chromium/Firefox snapshot, hierarchy, timestamp, "
         "source-count and preference allowlist probes passed\n";
}
