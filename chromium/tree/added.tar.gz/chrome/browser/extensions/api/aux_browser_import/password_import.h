// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_PASSWORD_IMPORT_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_PASSWORD_IMPORT_H_
#include "base/functional/callback_forward.h"
#include "base/values.h"
class Profile;
namespace aux_import {
// Writes staged password rows into `profile`'s password store. A login already
// there, same realm and username, keeps what it has. `done` gets the number
// written. Rows hold secrets: they stay in this call and never reach a log.
void WritePasswords(Profile* profile, base::ListValue rows,
                    base::OnceCallback<void(int)> done);
}  // namespace aux_import
#endif
