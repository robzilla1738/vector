// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
// Disposable fixtures only: never asks macOS for a real Safe Storage key.
#include <CommonCrypto/CommonCryptor.h>

#include <iostream>

#include "base/check.h"
#include "base/files/file_util.h"
#include "base/files/scoped_temp_dir.h"
#include "base/strings/string_number_conversions.h"
#include "chrome/browser/extensions/api/aux_browser_import/migrator.h"
#include "crypto/hash.h"
#include "third_party/sqlite/sqlite3.h"
namespace {
std::string Encrypt(std::string_view text, const aux_import::SourceKey& key) {
  std::string out(text.size() + 32, '\0');
  std::array<unsigned char, 16> iv;
  iv.fill(' ');
  size_t size = 0;
  CHECK_EQ(CCCrypt(kCCEncrypt, kCCAlgorithmAES, kCCOptionPKCS7Padding,
                   key.data(), key.size(), iv.data(), text.data(), text.size(),
                   out.data(), out.size(), &size),
           kCCSuccess);
  out.resize(size);
  return "v10" + out;
}
void Execute(sqlite3* db, const std::string& sql) {
  CHECK_EQ(sqlite3_exec(db, sql.c_str(), nullptr, nullptr, nullptr), SQLITE_OK);
}
}  // namespace
int main() {
  CHECK_EQ(sqlite3_initialize(), SQLITE_OK);
  base::ScopedTempDir temp;
  CHECK(temp.CreateUniqueTempDir());
  const auto profile = base::MakeAbsoluteFilePath(temp.GetPath());
  auto key = aux_import::DeriveSourceKey("fixture source password");
  CHECK_EQ(base::HexEncode(key), "AF09FA5F9F0623E56E30E339D414C6D7");
  const auto secret = Encrypt("fixture-password", key);
  CHECK_EQ(aux_import::DecryptSourceValue(secret, key).value_or(""),
           "fixture-password");
  auto wrong = aux_import::DeriveSourceKey("wrong fixture password");
  // CBC has no authentication tag: padding alone cannot prove key identity.
  CHECK_NE(aux_import::DecryptSourceValue(secret, wrong).value_or(""),
           "fixture-password");
  CHECK(!aux_import::DecryptSourceValue("v20unsupported", key));
  sqlite3* db = nullptr;
  CHECK_EQ(sqlite3_open(profile.AppendASCII("Login Data").value().c_str(), &db),
           SQLITE_OK);
  Execute(db,
          "CREATE TABLE "
          "logins(origin_url,action_url,signon_realm,username_element,username_"
          "value,password_element,password_value,date_created,date_last_used,"
          "date_password_modified,times_used,blacklisted_by_user,scheme)");
  Execute(db,
          "INSERT INTO logins "
          "VALUES('https://fixture.test/','https://fixture.test/login','https:/"
          "/fixture.test/','user','fixture-user','pass',X'" +
              base::HexEncode(secret) +
              "',13200000000000001,13200000000000002,13200000000000003,7,0,0)");
  CHECK_EQ(sqlite3_close(db), SQLITE_OK);
  auto passwords = aux_import::ReadEncryptedCategory(profile, "passwords", key);
  CHECK(!passwords.FindString("error"));
  CHECK_EQ(passwords.FindList("passwords")->size(), 1u);
  const auto& password = (*passwords.FindList("passwords"))[0].GetDict();
  CHECK_EQ(*password.FindString("secret"), "fixture-password");
  CHECK_EQ(*password.FindString("created"), "13200000000000001");
  CHECK_EQ(sqlite3_open(profile.AppendASCII("Cookies").value().c_str(), &db),
           SQLITE_OK);
  Execute(db, "CREATE TABLE meta(key,value);INSERT INTO meta "
              "VALUES('version',24);CREATE TABLE "
              "cookies(host_key,name,path,value,encrypted_value,creation_utc,"
              "expires_utc,last_access_utc,is_secure,is_httponly,samesite,"
              "priority,top_frame_site_key,has_cross_site_ancestor,source_"
              "scheme,source_port,source_type,last_update_utc)");
  auto digest = crypto::hash::Sha256(".fixture.test");
  std::string text(reinterpret_cast<const char*>(digest.data()), digest.size());
  text += "fixture-cookie";
  Execute(db, "INSERT INTO cookies VALUES('.fixture.test','fixture','/','',X'" +
                  base::HexEncode(Encrypt(text, key)) +
                  "',13200000000000001,14200000000000001,13200000000000002,1,1,"
                  "0,1,'https://top.fixture',1,2,443,1,13200000000000003)");
  CHECK_EQ(sqlite3_close(db), SQLITE_OK);
  auto cookies = aux_import::ReadEncryptedCategory(profile, "cookies", key);
  CHECK(!cookies.FindString("error"));
  const auto& cookie = (*cookies.FindList("cookies"))[0].GetDict();
  CHECK_EQ(*cookie.FindString("secret"), "fixture-cookie");
  CHECK(cookie.FindBool("httpOnly").value_or(false));
  CHECK_EQ(*cookie.FindString("partition"), "https://top.fixture");
  CHECK_EQ(sqlite3_open(profile.AppendASCII("Cookies").value().c_str(), &db),
           SQLITE_OK);
  Execute(db, "UPDATE cookies SET host_key='.tampered.test'");
  CHECK_EQ(sqlite3_close(db), SQLITE_OK);
  CHECK(aux_import::ReadEncryptedCategory(profile, "cookies", key)
            .FindString("error"));
  std::string error;
  CHECK(!aux_import::AuthorizeSourceKey("unsupported-fixture", error));
  aux_import::ClearSourceKey(key);
  for (auto byte : key) {
    CHECK_EQ(byte, 0);
  }
  std::cout << "Disposable encrypted password/cookie, host binding, exact "
               "metadata, unsupported format and key-clearing probes passed\n";
}
