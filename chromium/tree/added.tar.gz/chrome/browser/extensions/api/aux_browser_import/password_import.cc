// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include "chrome/browser/extensions/api/aux_browser_import/password_import.h"

#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include "base/functional/bind.h"
#include "base/functional/callback.h"
#include "base/memory/ptr_util.h"
#include "base/memory/scoped_refptr.h"
#include "base/memory/weak_ptr.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_string_conversions.h"
#include "chrome/browser/extensions/api/aux_browser_import/encrypted_source_bytes.h"
#include "chrome/browser/password_manager/factories/profile_password_store_factory.h"
#include "chrome/browser/profiles/profile.h"
#include "components/keyed_service/core/service_access_type.h"
#include "components/password_manager/core/browser/password_form.h"
#include "components/password_manager/core/browser/password_string.h"
#include "components/password_manager/core/browser/password_store/password_form_converters.h"
#include "components/password_manager/core/browser/password_store/password_store_consumer.h"
#include "components/password_manager/core/browser/password_store/password_store_interface.h"
#include "components/password_manager/core/browser/password_store/stored_credential.h"
#include "components/password_manager/core/common/password_manager_pref_names.h"
#include "components/prefs/pref_service.h"
#include "url/gurl.h"
#include "url/origin.h"
#include "url/scheme_host_port.h"

namespace aux_import {
namespace {
using password_manager::PasswordForm;

std::string Key(const std::string& realm, const std::u16string& username) {
  return realm + "\n" + base::UTF16ToUTF8(username);
}
std::u16string Text16(const base::DictValue& row, std::string_view field) {
  return base::UTF8ToUTF16(GetEncryptedSourceBytes(row, field).value_or(std::string_view()));
}
std::string Text(const base::DictValue& row, std::string_view field) {
  return std::string(GetEncryptedSourceBytes(row, field).value_or(std::string_view()));
}
base::Time Stamp(const base::DictValue& row, std::string_view field) {
  int64_t micros = 0;
  if (const auto* text = row.FindString(field))
    base::StringToInt64(*text, &micros);
  return base::Time::FromDeltaSinceWindowsEpoch(base::Microseconds(micros));
}
PasswordForm FormFrom(const base::DictValue& row) {
  PasswordForm form;
  form.url = GURL(Text(row, "url"));
  form.action = GURL(Text(row, "action"));
  form.signon_realm = Text(row, "realm");
  form.username_element = Text16(row, "usernameElement");
  form.username_value = Text16(row, "username");
  form.password_element = Text16(row, "passwordElement");
  form.password_value = password_manager::PasswordString(Text16(row, "secret"));
  form.submit_element = Text16(row, "submitElement");
  form.display_name = Text16(row, "displayName");
  form.icon_url = GURL(Text(row, "iconUrl"));
  if (const GURL federation(Text(row, "federationUrl")); federation.is_valid())
    form.federation_origin = url::SchemeHostPort(federation);
  form.blocked_by_user = row.FindBool("blocked").value_or(false);
  form.skip_zero_click = row.FindBool("skipZeroClick").value_or(false);
  form.times_used_in_html_form = row.FindInt("timesUsed").value_or(0);
  form.date_created = Stamp(row, "created");
  form.date_last_used = Stamp(row, "used");
  form.date_password_modified = Stamp(row, "modified");
  form.type = PasswordForm::Type::kImported;
  form.in_store = PasswordForm::Store::kProfileStore;
  if (const auto note = Text16(row, "note"); !note.empty())
    form.SetNoteWithEmptyUniqueDisplayName(note);
  return form;
}

// Owns itself from the store query until the writes are acknowledged.
class Writer final : public password_manager::PasswordStoreConsumer {
 public:
  Writer(scoped_refptr<password_manager::PasswordStoreInterface> store,
         base::ListValue rows, base::OnceCallback<void(int)> done)
      : store_(std::move(store)), rows_(std::move(rows)), done_(std::move(done)) {}
  void Start() { store_->GetAllLogins(weak_.GetWeakPtr()); }

 private:
  void OnGetPasswordStoreResultsOrErrorFrom(
      password_manager::PasswordStoreInterface*,
      base::expected<std::vector<password_manager::StoredCredential>,
                     password_manager::PasswordStoreBackendError> results) override {
    std::set<std::string> present;
    if (results.has_value()) {
      for (const auto& login : *results)
        present.insert(Key(login.signon_realm, login.username_value));
    }
    std::vector<password_manager::StoredCredential> forms;
    for (const auto& value : rows_) {
      auto form = FormFrom(value.GetDict());
      if (form.url.is_valid() && !form.signon_realm.empty() &&
          present.insert(Key(form.signon_realm, form.username_value)).second) {
        forms.push_back(password_manager::FromPasswordForm(std::move(form)));
      }
    }
    rows_.clear();
    const int written = forms.size();
    store_->AddLogins(std::move(forms), base::BindOnce(
        [](std::unique_ptr<Writer> writer, int written) {
          std::move(writer->done_).Run(written);
        }, base::WrapUnique(this), written));
  }

  scoped_refptr<password_manager::PasswordStoreInterface> store_;
  base::ListValue rows_;
  base::OnceCallback<void(int)> done_;
  base::WeakPtrFactory<Writer> weak_{this};
};
}  // namespace

void WritePasswords(Profile* profile, base::ListValue rows,
                    base::OnceCallback<void(int)> done) {
  auto store = ProfilePasswordStoreFactory::GetForProfile(
      profile, ServiceAccessType::EXPLICIT_ACCESS);
  if (!store || !profile->GetPrefs()->GetBoolean(
                    password_manager::prefs::kCredentialsEnableService)) {
    std::move(done).Run(0);
    return;
  }
  (new Writer(std::move(store), std::move(rows), std::move(done)))->Start();
}
}  // namespace aux_import
