// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include "chrome/browser/extensions/api/aux_browser_import/arc_spaces_import.h"

#include <algorithm>
#include <limits>
#include <string>
#include <utility>
#include <vector>

#include "base/callback_list.h"
#include "base/functional/bind.h"
#include "base/memory/weak_ptr.h"
#include "base/strings/string_util.h"
#include "base/task/single_thread_task_runner.h"
#include "base/timer/timer.h"
#include "base/uuid.h"
#include "chrome/browser/aux/organization/organization_profile_service.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/themes/aux_theme_editor.h"
#include "url/gurl.h"

namespace aux_import {
namespace {
namespace org = aux::organization;
// The model refuses a batch past 512 commands or a 128 KiB fingerprint.
constexpr size_t kBatchCommands = 512;
constexpr size_t kBatchFingerprint = 120 * 1024;

std::string Truncated(std::string text, size_t bytes) {
  base::TruncateUTF8ToByteSize(text, bytes, &text);
  return text;
}

// Owns itself until every batch has committed or one has not.
class Writer {
 public:
  Writer(Profile* profile, base::DictValue arc,
         base::OnceCallback<void(std::optional<int>)> done)
      : profile_(profile->GetWeakPtr()), arc_(std::move(arc)),
        done_(std::move(done)) {}

  void Try() {
    auto* owner = profile_ ? org::OrganizationProfileServiceFactory::
        GetForProfile(profile_.get()) : nullptr;
    if (!owner) return Finish(false);
    auto* model = owner->model();
    if (!model && owner->loading()) return Wait(owner->ObserveReady(Retrier()));
    if (!model || model->blocked()) return Finish(false);
    if (model->pending()) return Wait(model->ObserveSettled(Retrier()));
    subscription_ = {};
    timeout_.Stop();
    if (!built_) {
      built_ = true;
      Build(model->snapshot());
      if (batches_.empty()) return Finish(false);
    }
    org::Context context{model->snapshot().profile_id, owner->owner_generation(),
        model->snapshot().revision,
        base::Uuid::GenerateRandomV4().AsLowercaseString()};
    model->ExecuteBatch(std::move(context), std::move(batches_[next_].commands),
                        base::BindOnce(&Writer::Committed, weak_.GetWeakPtr()));
  }

 private:
  struct Batch {
    std::vector<org::Command> commands;
    size_t fingerprint = 0;
  };
  struct Theme {
    std::string space_id;
    size_t batch;
    base::DictValue tokens;
  };

  void Build(const org::Snapshot& snapshot) {
    // A profile holding only its first, empty Space takes the first Arc Space
    // in its place instead of keeping an empty one beside it.
    std::string reuse;
    if (snapshot.spaces.size() == 1) {
      const auto& only = snapshot.spaces.begin()->first;
      if (std::ranges::none_of(snapshot.entries, [&](const auto& item) {
            return item.second.space_id == only;
          }))
        reuse = only;
    }
    size_t room = org::kMaxSpaces - snapshot.spaces.size();
    if (const auto* spaces = arc_.FindList("spaces")) {
      for (const auto& value : *spaces) {
        const auto& space = value.GetDict();
        const auto* title = space.FindString("title");
        if (!title || title->empty()) continue;
        org::Command command;
        if (!reuse.empty()) {
          command.action = org::Action::kRenameSpace;
          command.id = std::exchange(reuse, {});
        } else if (room > 0) {
          --room;
          command.action = org::Action::kCreateSpace;
          command.id = base::Uuid::GenerateRandomV4().AsLowercaseString();
          command.index = std::numeric_limits<uint64_t>::max();
        } else {
          break;
        }
        command.title = Truncated(*title, 256);
        if (const auto* icon = space.FindString("icon"))
          command.icon = Truncated(*icon, 256);
        const std::string id = command.id;
        Add(std::move(command));
        if (const auto* colors = space.FindList("colors"))
          themes_.push_back({id, batches_.size() - 1, Tokens(*colors)});
        if (const auto* entries = space.FindList("entries"))
          AddEntries(*entries, id, {}, 0);
      }
    }
    if (const auto* pins = arc_.FindList("pins")) AddEntries(*pins, {}, {}, 0);
  }

  // One color is a tint; two or three are a gradient that starts at it.
  static base::DictValue Tokens(const base::ListValue& colors) {
    base::DictValue tokens;
    tokens.Set("version", 1);
    tokens.Set("tint", colors.front().GetString());
    tokens.Set("tintStrength", 0.6);
    if (colors.size() > 1) tokens.Set("colors", colors.Clone());
    return tokens;
  }

  // Top-level entries are kept in their Space, like Arc's pinned section.
  void AddEntries(const base::ListValue& entries, const std::string& space,
                  const std::string& parent, size_t depth) {
    if (depth >= org::kMaxDepth) return;
    for (const auto& value : entries) {
      const auto& entry = value.GetDict();
      const auto* title = entry.FindString("title");
      const auto* url = entry.FindString("url");
      const auto* children = entry.FindList("children");
      org::Command command;
      command.id = base::Uuid::GenerateRandomV4().AsLowercaseString();
      command.space_id = space;
      command.parent_id = parent;
      command.title = Truncated(title ? *title : std::string(), 4096);
      command.index = std::numeric_limits<uint64_t>::max();
      if (children) {
        command.action = org::Action::kCreateFolder;
      } else if (url && url->size() <= 32768 && GURL(*url).is_valid()) {
        command.action = org::Action::kCreateTab;
        command.url = *url;
        command.title_mode = entry.FindBool("renamed").value_or(false)
            ? org::TitleMode::kManual : org::TitleMode::kAutomatic;
        ++pages_;
      } else {
        continue;
      }
      const std::string id = command.id;
      Add(std::move(command));
      if (!space.empty() && parent.empty()) {
        org::Command keep;
        keep.action = org::Action::kSetKeepInSpace;
        keep.id = id;
        keep.value = true;
        Add(std::move(keep));
      }
      if (children) AddEntries(*children, space, id, depth + 1);
    }
  }

  void Add(org::Command command) {
    const size_t size = org::Fingerprint(command).size() + 16;
    if (batches_.empty() || batches_.back().commands.size() >= kBatchCommands ||
        batches_.back().fingerprint + size > kBatchFingerprint)
      batches_.emplace_back();
    batches_.back().fingerprint += size;
    batches_.back().commands.push_back(std::move(command));
  }

  base::RepeatingClosure Retrier() {
    // Settlement is announced mid-commit; start over once it has unwound.
    return base::BindRepeating(
        [](base::WeakPtr<Writer> self) {
          base::SingleThreadTaskRunner::GetCurrentDefault()->PostTask(
              FROM_HERE, base::BindOnce(&Writer::Try, self));
        },
        weak_.GetWeakPtr());
  }

  void Wait(base::CallbackListSubscription subscription) {
    subscription_ = std::move(subscription);
    if (timeout_.IsRunning()) return;
    timeout_.Start(FROM_HERE, base::Seconds(10),
                   base::BindOnce(&Writer::Finish, weak_.GetWeakPtr(), false));
  }

  void Committed(org::CommitResult result) {
    if (result.error != org::Error::kNone && result.error != org::Error::kReplay)
      return Finish(false);
    if (++next_ == batches_.size()) return Finish(true);
    base::SingleThreadTaskRunner::GetCurrentDefault()->PostTask(
        FROM_HERE, base::BindOnce(&Writer::Try, weak_.GetWeakPtr()));
  }

  void Finish(bool success) {
    // Spaces that were made keep their Arc colors even if a later batch failed.
    for (auto& theme : themes_) {
      if (profile_ && theme.batch < next_)
        aux_theme::SaveTokens(profile_.get(), theme.space_id, std::move(theme.tokens));
    }
    auto done = std::move(done_);
    const std::optional<int> pages = success ? std::make_optional(pages_) : std::nullopt;
    delete this;
    std::move(done).Run(pages);
  }

  base::WeakPtr<Profile> profile_;
  base::DictValue arc_;
  base::OnceCallback<void(std::optional<int>)> done_;
  std::vector<Batch> batches_;
  std::vector<Theme> themes_;
  size_t next_ = 0;
  int pages_ = 0;
  bool built_ = false;
  base::CallbackListSubscription subscription_;
  base::OneShotTimer timeout_;
  base::WeakPtrFactory<Writer> weak_{this};
};
}  // namespace

void ImportArcSpaces(Profile* profile,
                     base::DictValue arc,
                     base::OnceCallback<void(std::optional<int>)> done) {
  (new Writer(profile, std::move(arc), std::move(done)))->Try();
}
}  // namespace aux_import
