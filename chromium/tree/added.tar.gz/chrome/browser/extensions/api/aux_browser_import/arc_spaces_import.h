// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_ARC_SPACES_IMPORT_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_ARC_SPACES_IMPORT_H_
#include <optional>

#include "base/functional/callback.h"
#include "base/values.h"
class Profile;
namespace aux_import {
// UI sequence. Writes the migrator's Arc sidebar into `profile`'s Spaces: each
// Arc Space becomes a Space (title, emoji, colors as its theme) holding its
// pinned items, kept in the Space; Arc Favorites become global pins. `done`
// gets the number of pages added, or nullopt when the sidebar could not be
// written in full, so the caller keeps Arc's bookmark-folder form as well.
void ImportArcSpaces(Profile* profile,
                     base::DictValue arc,
                     base::OnceCallback<void(std::optional<int>)> done);
}  // namespace aux_import
#endif
