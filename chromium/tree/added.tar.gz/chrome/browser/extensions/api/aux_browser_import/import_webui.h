// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_IMPORT_WEBUI_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_IMPORT_WEBUI_H_
#include "content/public/browser/web_ui_controller.h"
#include "content/public/browser/webui_config.h"
namespace aux_import {
class ImportWebUI : public content::WebUIController {
 public:
  explicit ImportWebUI(content::WebUI*);
  ~ImportWebUI() override;
};
class ImportWebUIConfig : public content::DefaultWebUIConfig<ImportWebUI> {
 public:
  ImportWebUIConfig() : DefaultWebUIConfig("chrome", "aux-import-data") {}
};
}  // namespace aux_import
#endif
