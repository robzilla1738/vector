#include "chrome/browser/extensions/api/aux_browser_import/firefox_cookie_import.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "base/check.h"
#include "base/files/file_util.h"
#include "base/files/scoped_temp_dir.h"
#include "base/functional/bind.h"
#include "base/memory/ref_counted.h"
#include "base/strings/cstring_view.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_split.h"
#include "base/task/thread_pool.h"
#include "base/time/time.h"
#include "chrome/browser/profiles/profile.h"
#include "content/public/browser/browser_thread.h"
#include "content/public/browser/storage_partition.h"
#include "net/base/url_util.h"
#include "net/cookies/canonical_cookie.h"
#include "net/cookies/cookie_access_result.h"
#include "net/cookies/cookie_options.h"
#include "net/cookies/cookie_partition_key.h"
#include "services/network/public/mojom/cookie_manager.mojom.h"
#include "sql/database.h"
#include "sql/statement.h"
#include "url/gurl.h"

namespace aux {
namespace {

struct CookieRow {
  std::unique_ptr<net::CanonicalCookie> cookie;
  GURL source;
};

struct CookieReadResult {
  bool success = false;
  std::vector<CookieRow> rows;
};

// Nonempty Firefox origin attributes must be precisely one partitionKey pair.
// Unknown, repeated or invalid attributes are rejected, not silently imported
// as unpartitioned cookies (original 4261910..4261a68).
struct Partition {
  bool valid = false;
  std::optional<net::CookiePartitionKey> key;
};

Partition ReadPartition(const std::string& attributes) {
  if (attributes.empty())
    return {true, std::nullopt};
  if (attributes.front() != '^')
    return {};
  const GURL query("https://firefox-origin-attributes.invalid/?" +
                   attributes.substr(1));
  if (!query.is_valid())
    return {};
  std::optional<std::string> encoded;
  for (net::QueryIterator it(query); !it.IsAtEnd(); it.Advance()) {
    if (it.GetKey() != "partitionKey" || encoded)
      return {};
    encoded = it.GetUnescapedValue();
  }
  if (!encoded)
    return {};
  std::replace(encoded->begin(), encoded->end(), '+', ':');
  if (encoded->size() < 5 || encoded->front() != '(' || encoded->back() != ')')
    return {};
  auto parts = base::SplitString(
      encoded->substr(1, encoded->size() - 2), ",", base::KEEP_WHITESPACE,
      base::SPLIT_WANT_ALL);
  if (parts.size() < 2 || parts.size() > 4 ||
      (parts[0] != "http" && parts[0] != "https") || parts[1].empty())
    return {};
  int port = -1;
  bool cross_site = false;
  if (parts.size() >= 3) {
    if (parts[2] == "f") {
      if (parts.size() == 4)
        return {};
      cross_site = true;
    } else {
      if (!base::StringToInt(parts[2], &port) || port < 1 || port > 65535)
        return {};
      if (parts.size() == 4) {
        if (parts[3] != "f")
          return {};
        cross_site = true;
      }
    }
  }
  std::string site = parts[0] + "://" + parts[1];
  if (port != -1)
    site += ":" + base::NumberToString(port);
  auto parsed = net::CookiePartitionKey::FromStorage(site, cross_site);
  if (!parsed.has_value())
    return {};
  return {true, std::move(parsed.value())};
}

// Original helper 637300 strips one leading domain dot, then parses the actual
// scheme://host+path, falling back to '/' at the worker callsite if invalid.
GURL CookieSource(std::string host, const std::string& path, bool https) {
  if (!host.empty() && host.front() == '.')
    host.erase(0, 1);
  if (host.empty())
    return GURL();
  return GURL(std::string(https ? "https://" : "http://") + host + path);
}

CookieReadResult ReadCookies(const base::FilePath& profile) {
  CookieReadResult result;
  const auto source = profile.AppendASCII("cookies.sqlite");
  if (!base::PathExists(source)) {
    result.success = true;
    return result;
  }
  // Unlike the Chromium reader, Firefox requires a successful isolated copy
  // including existing WAL/journal sidecars; there is no source-open fallback.
  base::ScopedTempDir temp;
  if (!temp.CreateUniqueTempDir())
    return result;
  const auto snapshot = temp.GetPath().AppendASCII("cookies.sqlite");
  if (!base::CopyFile(source, snapshot))
    return result;
  for (const char* sidecar : {"cookies.sqlite-wal", "cookies.sqlite-journal"}) {
    const auto path = profile.AppendASCII(sidecar);
    if (base::PathExists(path) &&
        !base::CopyFile(path, temp.GetPath().AppendASCII(sidecar)))
      return result;
  }
  sql::Database db("FirefoxImporter");
  if (!db.Open(snapshot) || !db.DoesTableExist("moz_cookies"))
    return result;
  constexpr std::array<base::cstring_view, 9> required = {
      "name", "value", "host", "path", "expiry", "lastAccessed",
      "creationTime", "isSecure", "isHttpOnly"};
  for (base::cstring_view column : required) {
    if (!db.DoesColumnExist("moz_cookies", column))
      return result;
  }
  // Exact original column order and missing-column SQL literals.
  std::string query =
      "SELECT name, value, host, path, expiry, lastAccessed, creationTime, "
      "isSecure, isHttpOnly, ";
  auto append = [&db, &query](base::cstring_view column, const char* fallback) {
    if (db.DoesColumnExist("moz_cookies", column))
      query.append(column.c_str(), column.size());
    else
      query += fallback;
  };
  append("sameSite", "256");
  query += ", ";
  append("schemeMap", "0");
  query += ", ";
  append("originAttributes", "''");
  query += ", ";
  append("updateTime", "creationTime");
  query += ", ";
  append("inBrowserElement", "0");
  query += " FROM moz_cookies";
  sql::Statement statement(db.GetUniqueStatement(query));
  if (!statement.is_valid())
    return result;
  const base::Time now = base::Time::Now();
  while (statement.Step()) {
    const int64_t expiry_seconds = statement.ColumnInt64(4);
    const base::Time expiry =
        base::Time::UnixEpoch() + base::Seconds(expiry_seconds);
    if (expiry_seconds <= 0 || expiry <= now || statement.ColumnInt(13) != 0)
      continue;
    const bool secure = statement.ColumnInt(7) != 0;
    auto partition = ReadPartition(statement.ColumnString(11));
    if (!partition.valid || (partition.key && !secure))
      continue;
    const int scheme_map = statement.ColumnInt(10);
    const bool https = secure || (scheme_map & 2);
    if (!https && !(scheme_map & 1))
      continue;
    int same_site = statement.ColumnInt(9);
    if (same_site < 0 || same_site > 2)
      same_site = -1;
    auto cookie = net::CanonicalCookie::FromStorage(
        statement.ColumnString(0), statement.ColumnString(1),
        statement.ColumnString(2), statement.ColumnString(3),
        base::Time::UnixEpoch() + base::Microseconds(statement.ColumnInt64(6)),
        expiry,
        base::Time::UnixEpoch() + base::Microseconds(statement.ColumnInt64(5)),
        base::Time::UnixEpoch() + base::Microseconds(statement.ColumnInt64(12)),
        secure, statement.ColumnInt(8) != 0,
        static_cast<net::CookieSameSite>(same_site), net::COOKIE_PRIORITY_MEDIUM,
        std::move(partition.key),
        https ? net::CookieSourceScheme::kSecure
              : net::CookieSourceScheme::kNonSecure,
        -1, net::CookieSourceType::kOther,
        net::CanonicalCookieFromStorageCallSite::kCookieManager);
    if (!cookie)
      continue;
    GURL source_url = CookieSource(statement.ColumnString(2),
                                   statement.ColumnString(3), https);
    if (!source_url.is_valid())
      source_url = CookieSource(statement.ColumnString(2), "/", https);
    if (source_url.is_valid())
      result.rows.push_back({std::move(cookie), std::move(source_url)});
  }
  // SQL errors fail the worker and discard even previously parsed rows.
  result.success = statement.Succeeded();
  if (!result.success)
    result.rows.clear();
  return result;
}

class CookieWrites : public base::RefCounted<CookieWrites> {
 public:
  CookieWrites(size_t pending,
               base::RepeatingCallback<bool()> running,
               base::OnceCallback<void(bool)> settled)
      : pending_(pending), running_(std::move(running)),
        settled_(std::move(settled)) {}

  void DidWrite(net::CookieAccessResult result) {
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    if (!running_.Run() || pending_ == 0)
      return;
    if (result.status.IsInclude())
      ++included_;
    if (--pending_ == 0)
      std::move(settled_).Run(included_ != 0);
  }

 private:
  friend class base::RefCounted<CookieWrites>;
  ~CookieWrites() = default;
  size_t pending_;
  size_t included_ = 0;
  base::RepeatingCallback<bool()> running_;
  base::OnceCallback<void(bool)> settled_;
};

void DidRead(base::WeakPtr<Profile> profile,
             base::RepeatingCallback<bool()> running,
             base::OnceCallback<void(bool)> prepared,
             base::OnceCallback<void(bool)> settled,
             CookieReadResult result) {
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  if (!running.Run()) {
    std::move(prepared).Run(false);
    return;
  }
  if (!result.success || result.rows.empty()) {
    const bool success = result.success;
    std::move(settled).Run(success);
    std::move(prepared).Run(success);
    return;
  }
  auto* partition = profile ? profile->GetDefaultStoragePartition() : nullptr;
  auto* manager = partition ? partition->GetCookieManagerForBrowserProcess()
                            : nullptr;
  if (!manager) {
    std::move(settled).Run(false);
    std::move(prepared).Run(false);
    return;
  }
  auto writes = base::MakeRefCounted<CookieWrites>(
      result.rows.size(), std::move(running), std::move(settled));
  for (const auto& row : result.rows) {
    manager->SetCanonicalCookie(
        *row.cookie, row.source, net::CookieOptions::MakeAllInclusive(),
        base::BindOnce(&CookieWrites::DidWrite, writes));
  }
  // Source426438c acknowledges host preparation after enqueue, not after write
  // completion. Only CookieWrites::DidWrite produces actual import completion.
  std::move(prepared).Run(true);
}

}  // namespace

void PrepareFirefoxCookies(base::WeakPtr<Profile> profile,
                           const base::FilePath& source_profile,
                           base::RepeatingCallback<bool()> is_running,
                           base::OnceCallback<void(bool)> prepared,
                           base::OnceCallback<void(bool)> settled) {
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  CHECK(is_running && prepared && settled);
  base::ThreadPool::PostTaskAndReplyWithResult(
      FROM_HERE, {base::MayBlock(), base::TaskPriority::USER_VISIBLE},
      base::BindOnce(&ReadCookies, source_profile),
      base::BindOnce(&DidRead, std::move(profile), std::move(is_running),
                     std::move(prepared), std::move(settled)));
}

}  // namespace aux
