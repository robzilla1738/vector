// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_SAFARI_ARCHIVE_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_SAFARI_ARCHIVE_H_
#include <string>

#include "base/values.h"
namespace aux_import {
// Worker only. No filesystem extraction: validate all entries, then decompress
// only the explicitly selected category with bounded output. Bookmark HTML
// must subsequently be parsed by Chromium's sandboxed utility service.
base::DictValue ReadSafariArchive(std::string bytes, std::string category);
}  // namespace aux_import
#endif
