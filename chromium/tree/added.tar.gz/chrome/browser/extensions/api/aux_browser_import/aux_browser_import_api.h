// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_AUX_BROWSER_IMPORT_API_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_BROWSER_IMPORT_AUX_BROWSER_IMPORT_API_H_
#include "chrome/browser/extensions/api/aux_common/aux_api.h"
namespace extensions {
class AuxBrowserImportFunction : public AuxFunction {
 protected:
  ~AuxBrowserImportFunction() override = default;
  ResponseAction RunAux() override;
};
class AuxBrowserImportGetImportSourcesFunction final:public AuxBrowserImportFunction {public:DECLARE_EXTENSION_FUNCTION("auxBrowserImport.getImportSources",AUXBROWSERIMPORT_GETIMPORTSOURCES) protected:~AuxBrowserImportGetImportSourcesFunction()override=default;};
class AuxBrowserImportStartImportFunction final:public AuxBrowserImportFunction {public:DECLARE_EXTENSION_FUNCTION("auxBrowserImport.startImport",AUXBROWSERIMPORT_STARTIMPORT) protected:~AuxBrowserImportStartImportFunction()override=default;};
class AuxBrowserImportGetImportProgressFunction final:public AuxBrowserImportFunction {public:DECLARE_EXTENSION_FUNCTION("auxBrowserImport.getImportProgress",AUXBROWSERIMPORT_GETIMPORTPROGRESS) protected:~AuxBrowserImportGetImportProgressFunction()override=default;};
class AuxBrowserImportCancelImportFunction final:public AuxBrowserImportFunction {public:DECLARE_EXTENSION_FUNCTION("auxBrowserImport.cancelImport",AUXBROWSERIMPORT_CANCELIMPORT) protected:~AuxBrowserImportCancelImportFunction()override=default;};
}  // namespace extensions
#endif
