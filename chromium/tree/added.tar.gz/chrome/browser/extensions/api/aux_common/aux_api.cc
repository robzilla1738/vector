// Copyright 2026 Aux Authors. All rights reserved.
#include "chrome/browser/extensions/api/aux_common/aux_api.h"

#include "chrome/browser/aux/component_bootstrap.h"
#include "chrome/browser/buildflags.h"
#include "chrome/browser/profiles/profile.h"
#include "extensions/common/extension.h"
namespace extensions {
ExtensionFunction::ResponseAction AuxFunction::Run() {
  if (!BUILDFLAG(ENABLE_AUX_BROWSER) || !extension() ||
      extension_id() != aux::kAgentExtensionId) {
    return RespondNow(Error("Aux private capability is unavailable"));
  }
  if (!browser_context()) {
    return RespondNow(Error("Profile is no longer available"));
  }
  return RunAux();
}
Profile* AuxFunction::profile() const {
  return Profile::FromBrowserContext(browser_context());
}
}  // namespace extensions
