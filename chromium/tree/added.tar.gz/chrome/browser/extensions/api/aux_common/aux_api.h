// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_COMMON_AUX_API_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_COMMON_AUX_API_H_
#include "extensions/browser/extension_function.h"
class Profile;
namespace extensions {
class AuxFunction : public ExtensionFunction {
 protected:
  ~AuxFunction() override = default;
  ResponseAction Run() final;
  virtual ResponseAction RunAux() = 0;
  Profile* profile() const;
};
}  // namespace extensions
#endif
