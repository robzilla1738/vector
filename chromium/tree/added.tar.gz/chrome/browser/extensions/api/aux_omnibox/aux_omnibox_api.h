// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_OMNIBOX_AUX_OMNIBOX_API_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_OMNIBOX_AUX_OMNIBOX_API_H_
#include "chrome/browser/extensions/api/aux_common/aux_api.h"
namespace extensions {
class AuxOmniboxFunction : public AuxFunction {
 protected:
  ~AuxOmniboxFunction() override = default;
  ResponseAction RunAux() override;
};
class AuxOmniboxCreateSessionFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.createSession",
                             AUXOMNIBOX_CREATESESSION)
 protected:
  ~AuxOmniboxCreateSessionFunction() override = default;
};
class AuxOmniboxDestroySessionFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.destroySession",
                             AUXOMNIBOX_DESTROYSESSION)
 protected:
  ~AuxOmniboxDestroySessionFunction() override = default;
};
class AuxOmniboxGetSearchEnginesFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.getSearchEngines",
                             AUXOMNIBOX_GETSEARCHENGINES)
 protected:
  ~AuxOmniboxGetSearchEnginesFunction() override = default;
};
class AuxOmniboxOnFocusChangedFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.onFocusChanged",
                             AUXOMNIBOX_ONFOCUSCHANGED)
 protected:
  ~AuxOmniboxOnFocusChangedFunction() override = default;
};
class AuxOmniboxQueryAutocompleteFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.queryAutocomplete",
                             AUXOMNIBOX_QUERYAUTOCOMPLETE)
 protected:
  ~AuxOmniboxQueryAutocompleteFunction() override = default;
};
class AuxOmniboxStopAutocompleteFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.stopAutocomplete",
                             AUXOMNIBOX_STOPAUTOCOMPLETE)
 protected:
  ~AuxOmniboxStopAutocompleteFunction() override = default;
};
class AuxOmniboxOpenAutocompleteMatchFunction final
    : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.openAutocompleteMatch",
                             AUXOMNIBOX_OPENAUTOCOMPLETEMATCH)
 protected:
  ~AuxOmniboxOpenAutocompleteMatchFunction() override = default;
};
class AuxOmniboxSetPopupSelectionFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.setPopupSelection",
                             AUXOMNIBOX_SETPOPUPSELECTION)
 protected:
  ~AuxOmniboxSetPopupSelectionFunction() override = default;
};
class AuxOmniboxOpenPopupSelectionFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.openPopupSelection",
                             AUXOMNIBOX_OPENPOPUPSELECTION)
 protected:
  ~AuxOmniboxOpenPopupSelectionFunction() override = default;
};
class AuxOmniboxOnNavigationLikelyFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.onNavigationLikely",
                             AUXOMNIBOX_ONNAVIGATIONLIKELY)
 protected:
  ~AuxOmniboxOnNavigationLikelyFunction() override = default;
};
class AuxOmniboxDeleteAutocompleteMatchFunction final
    : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.deleteAutocompleteMatch",
                             AUXOMNIBOX_DELETEAUTOCOMPLETEMATCH)
 protected:
  ~AuxOmniboxDeleteAutocompleteMatchFunction() override = default;
};
class AuxOmniboxActivateKeywordFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.activateKeyword",
                             AUXOMNIBOX_ACTIVATEKEYWORD)
 protected:
  ~AuxOmniboxActivateKeywordFunction() override = default;
};
class AuxOmniboxExecuteActionFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.executeAction",
                             AUXOMNIBOX_EXECUTEACTION)
 protected:
  ~AuxOmniboxExecuteActionFunction() override = default;
};
class AuxOmniboxOnThumbnailRemovedFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.onThumbnailRemoved",
                             AUXOMNIBOX_ONTHUMBNAILREMOVED)
 protected:
  ~AuxOmniboxOnThumbnailRemovedFunction() override = default;
};
class AuxOmniboxGetPlaceholderConfigFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.getPlaceholderConfig",
                             AUXOMNIBOX_GETPLACEHOLDERCONFIG)
 protected:
  ~AuxOmniboxGetPlaceholderConfigFunction() override = default;
};
class AuxOmniboxGetRecentTabsFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.getRecentTabs",
                             AUXOMNIBOX_GETRECENTTABS)
 protected:
  ~AuxOmniboxGetRecentTabsFunction() override = default;
};
class AuxOmniboxGetTabPreviewFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.getTabPreview",
                             AUXOMNIBOX_GETTABPREVIEW)
 protected:
  ~AuxOmniboxGetTabPreviewFunction() override = default;
};
class AuxOmniboxGetInputStateFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.getInputState",
                             AUXOMNIBOX_GETINPUTSTATE)
 protected:
  ~AuxOmniboxGetInputStateFunction() override = default;
};
class AuxOmniboxNotifySessionStartedFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.notifySessionStarted",
                             AUXOMNIBOX_NOTIFYSESSIONSTARTED)
 protected:
  ~AuxOmniboxNotifySessionStartedFunction() override = default;
};
class AuxOmniboxNotifySessionAbandonedFunction final
    : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.notifySessionAbandoned",
                             AUXOMNIBOX_NOTIFYSESSIONABANDONED)
 protected:
  ~AuxOmniboxNotifySessionAbandonedFunction() override = default;
};
class AuxOmniboxAddFileContextFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.addFileContext",
                             AUXOMNIBOX_ADDFILECONTEXT)
 protected:
  ~AuxOmniboxAddFileContextFunction() override = default;
};
class AuxOmniboxAddTabContextFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.addTabContext",
                             AUXOMNIBOX_ADDTABCONTEXT)
 protected:
  ~AuxOmniboxAddTabContextFunction() override = default;
};
class AuxOmniboxDeleteContextFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.deleteContext",
                             AUXOMNIBOX_DELETECONTEXT)
 protected:
  ~AuxOmniboxDeleteContextFunction() override = default;
};
class AuxOmniboxClearFilesFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.clearFiles", AUXOMNIBOX_CLEARFILES)
 protected:
  ~AuxOmniboxClearFilesFunction() override = default;
};
class AuxOmniboxSubmitQueryFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.submitQuery", AUXOMNIBOX_SUBMITQUERY)
 protected:
  ~AuxOmniboxSubmitQueryFunction() override = default;
};
class AuxOmniboxOpenLensSearchFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.openLensSearch",
                             AUXOMNIBOX_OPENLENSSEARCH)
 protected:
  ~AuxOmniboxOpenLensSearchFunction() override = default;
};
class AuxOmniboxSetActiveToolModeFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.setActiveToolMode",
                             AUXOMNIBOX_SETACTIVETOOLMODE)
 protected:
  ~AuxOmniboxSetActiveToolModeFunction() override = default;
};
class AuxOmniboxSetActiveModelModeFunction final : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.setActiveModelMode",
                             AUXOMNIBOX_SETACTIVEMODELMODE)
 protected:
  ~AuxOmniboxSetActiveModelModeFunction() override = default;
};
class AuxOmniboxActivateMetricsFunnelFunction final
    : public AuxOmniboxFunction {
 public:
  DECLARE_EXTENSION_FUNCTION("auxOmnibox.activateMetricsFunnel",
                             AUXOMNIBOX_ACTIVATEMETRICSFUNNEL)
 protected:
  ~AuxOmniboxActivateMetricsFunnelFunction() override = default;
};
}  // namespace extensions
#endif
