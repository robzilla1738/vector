// Copyright 2026 Aux Authors. All rights reserved.
#import <Foundation/Foundation.h>

#include "base/apple/bundle_locations.h"
#include "base/apple/scoped_cftyperef.h"
#include <string>

#include "base/values.h"
#include "chrome/browser/mac/dock.h"
namespace extensions {
namespace {
CFStringRef AuxVibrancyDomain() {
  return CFSTR("dev.aux.browser");
}
}  // namespace
bool ReadAuxWindowVibrancyEnabled() {
  const auto domain = AuxVibrancyDomain();
  CFPreferencesAppSynchronize(domain);
  base::apple::ScopedCFTypeRef<CFPropertyListRef> disabled(
      CFPreferencesCopyAppValue(CFSTR("windowBackgroundVibrancyDisabled"), domain));
  // Matches the window bridge: Transparent only once it has been chosen.
  return disabled && CFGetTypeID(disabled.get()) == CFBooleanGetTypeID() &&
         !CFBooleanGetValue(static_cast<CFBooleanRef>(disabled.get()));
}
bool WriteAuxWindowVibrancyEnabled(bool enabled) {
  const auto domain = AuxVibrancyDomain();
  CFPreferencesSetAppValue(CFSTR("windowBackgroundVibrancyDisabled"),
                           enabled ? kCFBooleanFalse : kCFBooleanTrue, domain);
  if (!CFPreferencesAppSynchronize(domain)) {
    return false;
  }
  CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                       domain, nullptr, nullptr, true);
  return true;
}
base::DictValue ReadAuxDockState() {
  auto state = dock::ChromeIsInTheDock();
  base::DictValue value;
  // Preserve the supplied macOS contract: only confirmed absence permits Add.
  // The original isAdded expression also covers an unreadable Dock state;
  // retain `known` so that uncertainty remains observable to newer consumers.
  value.Set("supported", true);
  value.Set("isAdded", state != dock::ChromeInDockStatus::kNotPresent);
  value.Set("canAdd", state == dock::ChromeInDockStatus::kNotPresent);
  value.Set("inDock", state == dock::ChromeInDockStatus::kPresent);
  value.Set("known", state != dock::ChromeInDockStatus::kFailure);
  return value;
}
base::DictValue AddAuxToDock() {
  auto result = dock::AddIcon(base::apple::OuterBundle().bundlePath, nil);
  auto state = ReadAuxDockState();
  state.Set("success", result != dock::AddIconStatus::kFailure);
  return state;
}
// "1.0.0 (77)": the release version and build number assembly stamps into Info.plist.
std::string ReadAuxProductVersion() {
  NSDictionary* info = base::apple::OuterBundle().infoDictionary;
  NSString* version = info[@"CFBundleShortVersionString"];
  NSString* build = info[@"CFBundleVersion"];
  if (![version isKindOfClass:NSString.class] || !version.length) return {};
  if (![build isKindOfClass:NSString.class] || !build.length || [build isEqualToString:version])
    return version.UTF8String;
  return std::string(version.UTF8String) + " (" + build.UTF8String + ")";
}
}  // namespace extensions
