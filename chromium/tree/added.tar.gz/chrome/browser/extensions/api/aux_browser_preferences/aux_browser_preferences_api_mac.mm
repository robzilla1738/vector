// Copyright 2026 Aux Authors. All rights reserved.
#import <AVFoundation/AVFoundation.h>
#import <Foundation/Foundation.h>
#import <Speech/Speech.h>

#include "base/apple/bundle_locations.h"
#include "base/apple/scoped_cftyperef.h"
#include <string>
#include <utility>

#include "base/functional/bind.h"
#include "base/functional/callback.h"
#include "base/location.h"
#include "base/no_destructor.h"
#include "base/strings/sys_string_conversions.h"
#include "base/task/sequenced_task_runner.h"
#include "base/time/time.h"
#include "base/timer/timer.h"

#include "base/values.h"
#include "chrome/browser/mac/dock.h"
namespace extensions {
namespace {
CFStringRef AuxVibrancyDomain() {
  return CFSTR("dev.aux.browser");
}

// Dictation: one session at a time, owned on the UI sequence. Apple's callbacks
// arrive on their own queues and only post back here, tagged with the session's
// generation so a late callback from a replaced session is ignored.
using StartDone = base::OnceCallback<void(std::string error)>;
using StopDone = base::OnceCallback<void(std::string text, std::string error)>;
constexpr base::TimeDelta kDictationLimit = base::Minutes(2);
constexpr base::TimeDelta kFinalResultWait = base::Seconds(5);
struct Dictation {
  int generation = 0;
  bool active = false;
  bool finished = false;
  std::string text;
  std::string error;
  StartDone start_done;
  StopDone stop_done;
  base::OneShotTimer timer;
  SFSpeechRecognizer* recognizer;
  AVAudioEngine* engine;
  SFSpeechAudioBufferRecognitionRequest* request;
  SFSpeechRecognitionTask* task;
};
Dictation& CurrentDictation() {
  static base::NoDestructor<Dictation> dictation;
  return *dictation;
}
void StopAudio(Dictation& d) {
  if (d.engine) {
    [d.engine stop];
    [d.engine.inputNode removeTapOnBus:0];
    d.engine = nil;
  }
  [d.request endAudio];
}
// Ends the session; a pending start or stop learns the outcome.
void FinishDictation(std::string error) {
  auto& d = CurrentDictation();
  StopAudio(d);
  [d.task cancel];
  d.task = nil;
  d.request = nil;
  d.recognizer = nil;
  d.timer.Stop();
  if (d.error.empty()) d.error = std::move(error);
  d.finished = true;
  if (d.start_done) {
    d.active = false;
    std::move(d.start_done).Run(d.error.empty() ? "Dictation stopped." : d.error);
  }
  if (d.stop_done) {
    d.active = false;
    std::move(d.stop_done).Run(std::exchange(d.text, {}), std::exchange(d.error, {}));
  }
}
// Stops the microphone and waits briefly for the recognizer's final result.
void EndDictationAudio() {
  auto& d = CurrentDictation();
  StopAudio(d);
  d.timer.Start(FROM_HERE, kFinalResultWait, base::BindOnce(&FinishDictation, std::string()));
}
void OnDictationResult(int generation, std::string text, bool is_final, bool failed) {
  auto& d = CurrentDictation();
  if (generation != d.generation || d.finished) return;
  if (!text.empty()) d.text = std::move(text);
  if (is_final || failed)
    FinishDictation(failed && d.text.empty() && !d.stop_done ? "Dictation stopped unexpectedly. Try again." : "");
}
void BeginRecognition(int generation) {
  auto& d = CurrentDictation();
  if (generation != d.generation || d.finished) return;
  // The recognizer follows the Mac's language and region.
  d.recognizer = [[SFSpeechRecognizer alloc] init];
  if (!d.recognizer.isAvailable)
    return FinishDictation("Dictation isn't available for your language right now.");
  d.request = [[SFSpeechAudioBufferRecognitionRequest alloc] init];
  d.request.shouldReportPartialResults = YES;  // Keeps the best text so far if the final never comes.
  d.request.addsPunctuation = YES;
  // Audio stays on this Mac wherever the language supports it.
  if (d.recognizer.supportsOnDeviceRecognition) d.request.requiresOnDeviceRecognition = YES;
  d.engine = [[AVAudioEngine alloc] init];
  AVAudioInputNode* input = d.engine.inputNode;
  AVAudioFormat* format = [input outputFormatForBus:0];
  if (format.sampleRate <= 0 || format.channelCount == 0)
    return FinishDictation("No microphone is available.");
  SFSpeechAudioBufferRecognitionRequest* request = d.request;
  [input installTapOnBus:0
              bufferSize:1024
                  format:format
                   block:^(AVAudioPCMBuffer* buffer, AVAudioTime* when) {
                     [request appendAudioPCMBuffer:buffer];
                   }];
  [d.engine prepare];
  NSError* error = nil;
  if (![d.engine startAndReturnError:&error]) return FinishDictation("The microphone couldn't start.");
  auto runner = base::SequencedTaskRunner::GetCurrentDefault();
  d.task = [d.recognizer recognitionTaskWithRequest:d.request
                                    resultHandler:^(SFSpeechRecognitionResult* result, NSError* failure) {
                                      runner->PostTask(
                                          FROM_HERE,
                                          base::BindOnce(&OnDictationResult, generation,
                                                         base::SysNSStringToUTF8(result.bestTranscription.formattedString ?: @""),
                                                         result.isFinal, failure != nil));
                                    }];
  d.timer.Start(FROM_HERE, kDictationLimit, base::BindOnce(&EndDictationAudio));
  std::move(d.start_done).Run(std::string());
}
void OnMicrophoneAccess(int generation, bool granted) {
  if (generation != CurrentDictation().generation || CurrentDictation().finished) return;
  if (!granted)
    return FinishDictation("Turn on the microphone for Aux in System Settings > Privacy & Security > Microphone.");
  BeginRecognition(generation);
}
void OnSpeechAccess(int generation, SFSpeechRecognizerAuthorizationStatus status) {
  if (generation != CurrentDictation().generation || CurrentDictation().finished) return;
  if (status != SFSpeechRecognizerAuthorizationStatusAuthorized)
    return FinishDictation("Turn on Speech Recognition for Aux in System Settings > Privacy & Security > Speech Recognition.");
  if ([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio] == AVAuthorizationStatusAuthorized)
    return BeginRecognition(generation);
  auto runner = base::SequencedTaskRunner::GetCurrentDefault();
  [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio
                           completionHandler:^(BOOL granted) {
                             runner->PostTask(FROM_HERE, base::BindOnce(&OnMicrophoneAccess, generation, granted));
                           }];
}
}  // namespace
void StartAuxDictation(StartDone done) {
  auto& d = CurrentDictation();
  if (d.active) {
    // A new start replaces a session the page lost track of (a reload, say).
    FinishDictation("Dictation was restarted.");
  }
  d.generation++;
  d.active = true;
  d.finished = false;
  d.text.clear();
  d.error.clear();
  d.start_done = std::move(done);
  const int generation = d.generation;
  auto runner = base::SequencedTaskRunner::GetCurrentDefault();
  [SFSpeechRecognizer requestAuthorization:^(SFSpeechRecognizerAuthorizationStatus status) {
    runner->PostTask(FROM_HERE, base::BindOnce(&OnSpeechAccess, generation, status));
  }];
}
void StopAuxDictation(StopDone done) {
  auto& d = CurrentDictation();
  if (!d.active) return std::move(done).Run(std::string(), "Dictation isn't running.");
  if (d.stop_done) return std::move(done).Run(std::string(), "Dictation is already stopping.");
  d.stop_done = std::move(done);
  if (d.finished || d.start_done || !d.request) return FinishDictation(std::string());
  EndDictationAudio();
}
bool ReadAuxWindowVibrancyEnabled() {
  const auto domain = AuxVibrancyDomain();
  CFPreferencesAppSynchronize(domain);
  base::apple::ScopedCFTypeRef<CFPropertyListRef> disabled(
      CFPreferencesCopyAppValue(CFSTR("windowBackgroundVibrancyDisabled"), domain));
  // Matches the window bridge: Transparent only once it has been chosen.
  return disabled && CFGetTypeID(disabled.get()) == CFBooleanGetTypeID() &&
         !CFBooleanGetValue(static_cast<CFBooleanRef>(disabled.get()));
}
bool WriteAuxWindowVibrancyEnabled(bool enabled) {
  const auto domain = AuxVibrancyDomain();
  CFPreferencesSetAppValue(CFSTR("windowBackgroundVibrancyDisabled"),
                           enabled ? kCFBooleanFalse : kCFBooleanTrue, domain);
  if (!CFPreferencesAppSynchronize(domain)) {
    return false;
  }
  CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                       domain, nullptr, nullptr, true);
  return true;
}
base::DictValue ReadAuxDockState() {
  auto state = dock::ChromeIsInTheDock();
  base::DictValue value;
  // Preserve the supplied macOS contract: only confirmed absence permits Add.
  // The original isAdded expression also covers an unreadable Dock state;
  // retain `known` so that uncertainty remains observable to newer consumers.
  value.Set("supported", true);
  value.Set("isAdded", state != dock::ChromeInDockStatus::kNotPresent);
  value.Set("canAdd", state == dock::ChromeInDockStatus::kNotPresent);
  value.Set("inDock", state == dock::ChromeInDockStatus::kPresent);
  value.Set("known", state != dock::ChromeInDockStatus::kFailure);
  return value;
}
base::DictValue AddAuxToDock() {
  auto result = dock::AddIcon(base::apple::OuterBundle().bundlePath, nil);
  auto state = ReadAuxDockState();
  state.Set("success", result != dock::AddIconStatus::kFailure);
  return state;
}
// "1.0.0 (77)": the release version and build number assembly stamps into Info.plist.
std::string ReadAuxProductVersion() {
  NSDictionary* info = base::apple::OuterBundle().infoDictionary;
  NSString* version = info[@"CFBundleShortVersionString"];
  NSString* build = info[@"CFBundleVersion"];
  if (![version isKindOfClass:NSString.class] || !version.length) return {};
  if (![build isKindOfClass:NSString.class] || !build.length || [build isEqualToString:version])
    return version.UTF8String;
  return std::string(version.UTF8String) + " (" + build.UTF8String + ")";
}
}  // namespace extensions
