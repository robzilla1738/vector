// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include "chrome/browser/extensions/api/aux_adblock/filter_hooks.h"

#include "base/functional/bind.h"
#include "base/strings/escape.h"
#include "base/task/single_thread_task_runner.h"
#include "base/uuid.h"
#include "chrome/browser/extensions/api/aux_adblock/filter_service.h"
#include "chrome/browser/profiles/profile.h"
#include "content/public/browser/navigation_controller.h"
#include "content/public/browser/navigation_handle.h"
#include "content/public/browser/navigation_throttle.h"
#include "content/public/browser/navigation_throttle_registry.h"
#include "content/public/browser/render_frame_host.h"
#include "content/public/browser/web_contents.h"
#include "content/public/browser/web_contents_user_data.h"
#include "net/base/net_errors.h"
#include "net/base/registry_controlled_domains/registry_controlled_domain.h"
#include "net/base/url_util.h"
#include "net/url_request/redirect_info.h"
#include "services/network/public/cpp/resource_request.h"
#include "third_party/blink/public/common/loader/url_loader_throttle.h"
#include "third_party/blink/public/mojom/fetch/fetch_api_request.mojom.h"
#include "url/origin.h"
namespace aux_adblock {
namespace {
std::string Type(network::mojom::RequestDestination destination) {
  using D = network::mojom::RequestDestination;
  switch (destination) {
    case D::kDocument:
      return "document";
    case D::kIframe:
    case D::kFrame:
      return "subdocument";
    case D::kScript:
    case D::kWorker:
    case D::kSharedWorker:
      return "script";
    case D::kImage:
      return "image";
    case D::kStyle:
      return "stylesheet";
    case D::kFont:
      return "font";
    case D::kAudio:
    case D::kVideo:
    case D::kTrack:
      return "media";
    case D::kObject:
    case D::kEmbed:
      return "object";
    case D::kEmpty:
      return "xmlhttprequest";
    default:
      return "other";
  }
}
Request MakeRequest(const GURL& url,
                    const GURL& initiator,
                    std::string type,
                    std::string method = "GET") {
  return {url, initiator, std::move(type), std::move(method),
          !net::registry_controlled_domains::SameDomainOrHost(
              url, initiator,
              net::registry_controlled_domains::INCLUDE_PRIVATE_REGISTRIES)};
}
GURL Redirect(const Decision& decision) {
  if (!decision.rewritten_url.empty()) {
    return GURL(decision.rewritten_url);
  }
  if (decision.redirect == "noopjs") {
    return GURL("data:application/javascript,");
  }
  if (decision.redirect == "nooptext") {
    return GURL("data:text/plain,");
  }
  if (decision.redirect == "1x1.gif") {
    return GURL(
        "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///"
        "yH5BAEAAAAALAAAAAABAAEAAAIBRAA7");
  }
  return {};
}
class RequestThrottle final : public blink::URLLoaderThrottle {
 public:
  explicit RequestThrottle(Profile* profile)
      : profile_(profile->GetWeakPtr()) {}
  void WillStartRequest(network::ResourceRequest* request,
                        bool* defer) override {
    if (!profile_ || !request->url.SchemeIsHTTPOrHTTPS()) {
      return;
    }
    type_ = Type(request->destination);
    if (type_ == "document") {
      return;
    }
    initiator_ = request->request_initiator
                     ? request->request_initiator->GetURL()
                     : GURL();
    method_ = request->method;
    auto* service = FilterService::Get(profile_.get());
    if (!service->ready()) {
      *defer = true;
      service->WhenReady(base::BindOnce(
          &RequestThrottle::Ready, weak_.GetWeakPtr(),
          MakeRequest(request->url, initiator_, type_, method_)));
      return;
    }
    auto decision = service->Evaluate(
        MakeRequest(request->url, initiator_, type_, method_));
    if (decision.block) {
      delegate_->CancelWithError(net::ERR_BLOCKED_BY_CLIENT,
                                 "Aux native filter");
      return;
    }
    auto redirected = Redirect(decision);
    if (redirected.is_valid()) {
      request->url = redirected;
    }
  }
  void WillRedirectRequest(net::RedirectInfo* redirect,
                           const network::mojom::URLResponseHead&,
                           bool*,
                           network::HttpRequestHeadersUpdateParams*) override {
    if (!profile_ || type_ == "document") {
      return;
    }
    auto decision = FilterService::Get(profile_.get())
                        ->Evaluate(MakeRequest(redirect->new_url, initiator_,
                                               type_, redirect->new_method));
    if (decision.block) {
      delegate_->CancelWithError(net::ERR_BLOCKED_BY_CLIENT,
                                 "Aux native filter");
    } else if (auto rewritten = Redirect(decision); rewritten.is_valid()) {
      if (url::Origin::Create(rewritten) !=
          url::Origin::Create(redirect->new_url)) {
        delegate_->CancelWithError(net::ERR_BLOCKED_BY_CLIENT,
                                   "Aux redirect target is unavailable");
        return;
      }
      redirect->new_url = rewritten;
    }
  }

 private:
  void Ready(Request request) {
    if (!profile_) {
      delegate_->CancelWithError(net::ERR_ABORTED);
      return;
    }
    const auto decision = FilterService::Get(profile_.get())->Evaluate(request);
    if (decision.block || !decision.redirect.empty() ||
        !decision.rewritten_url.empty()) {
      delegate_->CancelWithError(net::ERR_BLOCKED_BY_CLIENT,
                                 "Aux deferred native filter");
    } else {
      delegate_->Resume();
    }
  }
  base::WeakPtr<Profile> profile_;
  GURL initiator_;
  std::string type_, method_;
  base::WeakPtrFactory<RequestThrottle> weak_{this};
};
class Bypass final : public content::WebContentsUserData<Bypass> {
 public:
  std::string token;
  GURL url;
  bool armed = false;
  base::TimeTicks expires;

 private:
  friend class content::WebContentsUserData<Bypass>;
  explicit Bypass(content::WebContents* contents)
      : content::WebContentsUserData<Bypass>(*contents) {}
  WEB_CONTENTS_USER_DATA_KEY_DECL();
};
WEB_CONTENTS_USER_DATA_KEY_IMPL(Bypass);
class DocumentThrottle final : public content::NavigationThrottle {
 public:
  explicit DocumentThrottle(content::NavigationThrottleRegistry& registry)
      : content::NavigationThrottle(registry) {}
  const char* GetNameForLogging() override { return "AuxNativeDocumentFilter"; }
  ThrottleCheckResult WillStartRequest() override { return Check(); }
  ThrottleCheckResult WillRedirectRequest() override { return Check(); }

 private:
  void Ready() {
    auto result = Check();
    if (result.action() == PROCEED) {
      Resume();
    } else {
      CancelDeferredNavigation(result);
    }
  }
  base::WeakPtrFactory<DocumentThrottle> weak_{this};
  ThrottleCheckResult Check() {
    auto* navigation = navigation_handle();
    auto* contents = navigation->GetWebContents();
    const auto url = navigation->GetURL();
    Bypass::CreateForWebContents(contents);
    auto* state = Bypass::FromWebContents(contents);
    if (url.SchemeIs("https") && url.host() == "aux-bypass.invalid" &&
        url.path() == "/continue") {
      std::string token;
      if (net::GetValueForKeyInQuery(url, "token", &token)) {
        if (navigation->IsInPrimaryMainFrame() && !token.empty() &&
            token == state->token && state->expires > base::TimeTicks::Now()) {
          state->token.clear();
          state->armed = true;
          auto target = state->url;
          base::SingleThreadTaskRunner::GetCurrentDefault()->PostTask(
              FROM_HERE,
              base::BindOnce(
                  [](base::WeakPtr<content::WebContents> tab, GURL target) {
                    if (tab) {
                      tab->GetController().LoadURL(target, content::Referrer(),
                                                   ui::PAGE_TRANSITION_TYPED,
                                                   std::string());
                    }
                  },
                  contents->GetWeakPtr(), target));
        }
      }
      return CANCEL_AND_IGNORE;
    }
    if (!url.SchemeIsHTTPOrHTTPS()) {
      return PROCEED;
    }
    if (state->armed && navigation->IsInPrimaryMainFrame()) {
      state->armed = false;
      const bool valid =
          url == state->url && state->expires > base::TimeTicks::Now();
      state->url = GURL();
      if (valid) {
        return PROCEED;
      }
    }
    auto* profile = Profile::FromBrowserContext(contents->GetBrowserContext());
    const auto initiator = navigation->GetInitiatorOrigin();
    auto* service = FilterService::Get(profile);
    if (!service->ready()) {
      service->WhenReady(
          base::BindOnce(&DocumentThrottle::Ready, weak_.GetWeakPtr()));
      return DEFER;
    }
    if (navigation->IsInPrimaryMainFrame() && !state->token.empty()) {
      state->token.clear();
    }
    auto decision = service->Evaluate(MakeRequest(
        url, initiator ? initiator->GetURL() : url,
        navigation->IsInPrimaryMainFrame() ? "document" : "subdocument",
        navigation->IsPost() ? "POST" : "GET"));
    if (!decision.block) {
      return PROCEED;
    }
    if (!navigation->IsInPrimaryMainFrame()) {
      return {BLOCK_REQUEST, net::ERR_BLOCKED_BY_CLIENT};
    }
    state->url = url;
    state->token = base::Uuid::GenerateRandomV4().AsLowercaseString();
    state->expires = base::TimeTicks::Now() + base::Minutes(1);
    state->armed = false;
    std::string html =
        "<!doctype html><meta charset=utf-8><meta name=referrer "
        "content=no-referrer><meta http-equiv=Content-Security-Policy "
        "content=\"default-src 'none'; style-src 'unsafe-inline'; script-src "
        "'nonce-" +
        state->token +
        "'\"><title>Aux blocked this page</title><style>body{font:16px "
        "system-ui;background:#f5f5f4;color:#20201f;max-width:680px;margin:"
        "15vh auto;padding:32px}button,a{display:inline-block;margin:16px 16px "
        "0 0;padding:12px;border:1px solid "
        "#aaa;border-radius:8px;background:white;color:inherit}code{word-break:"
        "break-all}</style><h1>This page was blocked</h1><p>A native content "
        "filter matched this navigation.</p><p><code>" +
        base::EscapeForHTML(url.spec()) + "</code></p><p>Filter: <code>" +
        base::EscapeForHTML(decision.filter) +
        "</code></p><button id=back>Go back</button><a "
        "href=\"https://aux-bypass.invalid/continue?token=" +
        state->token + "\">Continue once</a><script nonce=" + state->token +
        ">document.getElementById('back').onclick=()=>history.back()</script>";
    return {BLOCK_REQUEST, net::ERR_BLOCKED_BY_CLIENT, std::move(html)};
  }
};
}  // namespace
std::unique_ptr<blink::URLLoaderThrottle> CreateRequestThrottle(
    content::BrowserContext* context) {
  return std::make_unique<RequestThrottle>(
      Profile::FromBrowserContext(context));
}
void AddNavigationThrottle(content::NavigationThrottleRegistry& registry) {
  registry.AddThrottle(std::make_unique<DocumentThrottle>(registry));
}
bool BlockWebSocket(content::RenderFrameHost* frame, const GURL& url) {
  if (!frame) {
    return false;
  }
  auto* service = FilterService::Get(
      Profile::FromBrowserContext(frame->GetBrowserContext()));
  if (!service->ready()) {
    return true;
  }
  const auto decision = service->Evaluate(
      MakeRequest(url, frame->GetLastCommittedOrigin().GetURL(), "websocket"));
  // A WebSocket cannot safely consume resource redirects or query rewrites.
  return decision.block || !decision.redirect.empty() ||
         !decision.rewritten_url.empty();
}
}  // namespace aux_adblock
