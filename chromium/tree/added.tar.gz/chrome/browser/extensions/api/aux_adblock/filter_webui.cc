// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include "chrome/browser/extensions/api/aux_adblock/filter_webui.h"

#include "base/functional/bind.h"
#include "base/memory/ref_counted_memory.h"
#include "chrome/browser/extensions/api/aux_adblock/filter_service.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/common/pref_names.h"
#include "components/prefs/pref_service.h"
#include "content/public/browser/web_contents.h"
#include "content/public/browser/web_ui.h"
#include "content/public/browser/web_ui_data_source.h"
#include "content/public/browser/web_ui_message_handler.h"
#include "services/network/public/mojom/content_security_policy.mojom.h"
namespace aux_adblock {
namespace {
constexpr char kHTML[] =
    R"HTML(<!doctype html><meta charset=utf-8><title>Aux content filtering</title><style>body{font:14px system-ui;max-width:1100px;margin:32px auto;padding:0 24px;color-scheme:light dark}section{padding:16px 0;border-bottom:1px solid #8885}button,input,select,textarea{font:inherit;padding:8px;margin:4px}textarea{display:block;width:95%;height:220px;font-family:monospace}pre{white-space:pre-wrap;overflow-wrap:anywhere}#error{color:#d23c3c}label{margin-right:16px}.source{padding:12px;border:1px solid #8885;margin:8px 0}</style><h1>Content filtering</h1><p id=state>Loading native service…</p><p id=error role=alert></p><label><input type=checkbox id=enabled>Enable filtering</label><button id=refresh>Refresh state</button><section><h2>Subscriptions</h2><input id=url type=url placeholder="https://example.org/filters.txt"><input id=name placeholder="Optional name"><button id=add>Add subscription</button><button id=update>Update all</button><div id=sources></div><pre id=jobs></pre></section><section><h2>Custom rules</h2><textarea id=rules spellcheck=false></textarea><button id=save>Save rules</button><button id=manual>Reload manual filters</button><button id=cache>Clear engine cache</button></section><section><h2>Test a request</h2><input id=requestURL placeholder="Request URL"><input id=initiator placeholder="Document URL"><select id=kind></select><label><input type=checkbox id=third>Third party</label><button id=test>Test locally</button><pre id=decision></pre></section><section><h2>Diagnostics</h2><pre id=diagnostics></pre></section><script src=index.js></script>)HTML";
constexpr char kJS[] =
    R"JS('use strict';const $=id=>document.getElementById(id),pending=new Map;let seq=0;
 window.cr={webUIResponse:(id,ok,value)=>{const request=pending.get(id);if(request){pending.delete(id);ok?request.resolve(value):request.reject(Error(value));}}};
 function call(method,args=[]){return new Promise((resolve,reject)=>{const id='aux-'+(++seq);pending.set(id,{resolve,reject});chrome.send('auxFilter',[id,method,args]);});}
 async function action(fn){$('error').textContent='';try{return await fn()}catch(error){$('error').textContent=error.message;throw error}}
 const json=value=>JSON.stringify(value,null,2);let editing=false;
 async function refresh(){const[state,sources,custom,diagnostics]=await Promise.all(['getState','getSubscriptions','getCustomRules','getDiagnostics'].map(x=>call(x)));$('enabled').checked=state.enabled;$('state').textContent=`Loaded: ${state.stateLoaded}; compiling: ${state.compiling}; requested generation ${state.requestedGeneration}; active ${state.activeGeneration}`;$('diagnostics').textContent=json(diagnostics);if(!editing)$('rules').value=custom.pendingRules??custom.rules;$('sources').replaceChildren();for(const source of sources){const row=document.createElement('div');row.className='source';const label=document.createElement('p');label.textContent=`${source.name} — ${source.url} — ${source.status}${source.lastError?' — '+source.lastError:''}`;row.append(label);for(const[text,method,args]of[[source.enabled?'Disable':'Enable','setSubscriptionEnabled',[source.id,!source.enabled]],['Update','startSubscriptionUpdate',[{ids:[source.id]}]],['Remove','removeSubscription',[source.id]]]){const button=document.createElement('button');button.textContent=text;button.onclick=()=>action(async()=>{const result=await call(method,args);if(result?.jobId)poll(result.jobId);await refresh()}).catch(()=>{});row.append(button)}$('sources').append(row)}}
 async function poll(id){try{const job=await call('getSubscriptionUpdateProgress',[id]);$('jobs').textContent=json(job);if(job.status==='running')setTimeout(()=>poll(id),500);else await refresh()}catch(error){$('error').textContent=error.message}}
 $('rules').oninput=()=>editing=true;$('enabled').onchange=()=>action(async()=>{await call('setEnabled',[$('enabled').checked]);await refresh()}).catch(()=>{});$('refresh').onclick=()=>action(refresh).catch(()=>{});
 $('add').onclick=()=>action(async()=>{const result=await call('addSubscription',[{url:$('url').value,name:$('name').value}]);poll(result.updateJobId);await refresh()}).catch(()=>{});$('update').onclick=()=>action(async()=>{const job=await call('startSubscriptionUpdate');poll(job.jobId)}).catch(()=>{});
 $('save').onclick=()=>action(async()=>{await call('saveCustomRules',[{rules:$('rules').value}]);editing=false;await refresh();setTimeout(()=>action(refresh).catch(()=>{}),500)}).catch(()=>{});for(const[id,method]of[['manual','reloadManualFilters'],['cache','clearEngineCache']])$(id).onclick=()=>action(async()=>{await call(method);await refresh()}).catch(()=>{});
 for(const type of 'script image stylesheet xmlhttprequest document subdocument websocket font media object ping other'.split(' ')){const option=document.createElement('option');option.value=type;option.textContent=type;$('kind').append(option)}
 $('test').onclick=()=>action(async()=>{$('decision').textContent=json(await call('testRequest',[{url:$('requestURL').value,initiator:$('initiator').value,requestType:$('kind').value,thirdParty:$('third').checked}]))}).catch(()=>{});action(refresh).catch(()=>{});
)JS";
class Handler final : public content::WebUIMessageHandler {
 public:
  void RegisterMessages() override {
    web_ui()->RegisterMessageCallback(
        "auxFilter",
        base::BindRepeating(&Handler::Invoke, base::Unretained(this)));
  }

 private:
  void Invoke(const base::ListValue& args) {
    if (args.size() != 3 || !args[0].is_string() || !args[1].is_string() ||
        !args[2].is_list()) {
      return;
    }
    AllowJavascript();
    auto id = args[0].GetString();
    FilterService::Get(Profile::FromWebUI(web_ui()))
        ->Invoke(args[1].GetString(), args[2].GetList().Clone(),
                 base::BindOnce(
                     [](base::WeakPtr<Handler> self, std::string id,
                        std::optional<base::Value> result, std::string error) {
                       if (!self || !self->IsJavascriptAllowed()) {
                         return;
                       }
                       if (result) {
                         self->ResolveJavascriptCallback(base::Value(id),
                                                         *result);
                       } else {
                         self->RejectJavascriptCallback(base::Value(id),
                                                        base::Value(error));
                       }
                     },
                     weak_.GetWeakPtr(), std::move(id)));
  }
  base::WeakPtrFactory<Handler> weak_{this};
};
}  // namespace
FilterWebUI::FilterWebUI(content::WebUI* web_ui)
    : content::WebUIController(web_ui) {
  auto* source = content::WebUIDataSource::CreateAndAdd(
      web_ui->GetWebContents()->GetBrowserContext(), "aux-adblock-internals");
  source->OverrideContentSecurityPolicy(
      network::mojom::CSPDirectiveName::StyleSrc,
      "style-src 'self' 'unsafe-inline';");
  source->SetRequestFilter(
      base::BindRepeating([](const std::string& path) {
        return path.empty() || path == "index.html" || path == "index.js";
      }),
      base::BindRepeating(
          [](const std::string& path,
             content::WebUIDataSource::GotDataCallback callback) {
            std::move(callback).Run(
                base::MakeRefCounted<base::RefCountedString>(
                    path == "index.js" ? kJS : kHTML));
          }));
  web_ui->AddMessageHandler(std::make_unique<Handler>());
}
FilterWebUI::~FilterWebUI() = default;
bool FilterWebUIConfig::IsWebUIEnabled(content::BrowserContext* browser_context) {
  return Profile::FromBrowserContext(browser_context)
      ->GetPrefs()
      ->GetBoolean(prefs::kExtensionsUIDeveloperMode);
}
}  // namespace aux_adblock
