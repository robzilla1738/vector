// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include "chrome/browser/extensions/api/aux_adblock/cosmetic_host.h"

#include "base/callback_list.h"
#include "base/functional/bind.h"
#include "base/json/json_writer.h"
#include "base/memory/weak_ptr.h"
#include "chrome/browser/extensions/api/aux_adblock/filter_service.h"
#include "chrome/browser/profiles/profile.h"
#include "content/public/browser/document_service.h"
#include "content/public/browser/render_frame_host.h"
#include "mojo/public/cpp/bindings/remote.h"
namespace aux_adblock {
namespace {
class Host final : public content::DocumentService<mojom::CosmeticHost> {
 public:
  Host(content::RenderFrameHost& frame,
       mojo::PendingReceiver<mojom::CosmeticHost> receiver)
      : DocumentService(frame, std::move(receiver)) {}
  void GetResources(GetResourcesCallback callback) override {
    const auto url = render_frame_host().GetLastCommittedURL();
    if (!url.SchemeIsHTTPOrHTTPS()) {
      std::move(callback).Run("{}");
      return;
    }
    auto* profile =
        Profile::FromBrowserContext(render_frame_host().GetBrowserContext());
    FilterService::Get(profile)->WhenReady(
        base::BindOnce(&Host::Reply, weak_.GetWeakPtr(), std::move(callback)));
  }

  void Watch(mojo::PendingRemote<mojom::CosmeticClient> client) override {
    client_.Bind(std::move(client));
    auto* profile =
        Profile::FromBrowserContext(render_frame_host().GetBrowserContext());
    auto* service = FilterService::Get(profile);
    subscription_ = service->ObserveCosmetics(
        base::BindRepeating(&Host::Changed, weak_.GetWeakPtr()));
    service->WhenReady(base::BindOnce(&Host::Changed, weak_.GetWeakPtr()));
  }

 private:
  void Changed() {
    if (!client_.is_bound()) {
      return;
    }
    const auto url = render_frame_host().GetLastCommittedURL();
    auto* profile =
        Profile::FromBrowserContext(render_frame_host().GetBrowserContext());
    client_->ResourcesChanged(
        base::WriteJson(url.SchemeIsHTTPOrHTTPS()
                            ? FilterService::Get(profile)->Cosmetics(url)
                            : base::DictValue())
            .value_or("{}"));
  }
  void Reply(GetResourcesCallback callback) {
    const auto url = render_frame_host().GetLastCommittedURL();
    auto* profile =
        Profile::FromBrowserContext(render_frame_host().GetBrowserContext());
    std::move(callback).Run(
        base::WriteJson(FilterService::Get(profile)->Cosmetics(url))
            .value_or("{}"));
  }
  mojo::Remote<mojom::CosmeticClient> client_;
  base::CallbackListSubscription subscription_;
  base::WeakPtrFactory<Host> weak_{this};
};
}  // namespace
void BindCosmeticHost(content::RenderFrameHost* frame,
                      mojo::PendingReceiver<mojom::CosmeticHost> receiver) {
  if (frame) {
    new Host(*frame, std::move(receiver));
  }
}
}  // namespace aux_adblock
