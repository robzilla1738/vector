// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_AUX_ADBLOCK_API_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_AUX_ADBLOCK_API_H_
#include "chrome/browser/extensions/api/aux_common/aux_api.h"
namespace extensions {
class AuxAdblockFunction : public AuxFunction {
 protected:
  ~AuxAdblockFunction() override = default;
  ResponseAction RunAux() override;
};
class AuxAdblockGetStateFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.getState",AUXADBLOCK_GETSTATE) protected:~AuxAdblockGetStateFunction()override=default;};
class AuxAdblockSetEnabledFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.setEnabled",AUXADBLOCK_SETENABLED) protected:~AuxAdblockSetEnabledFunction()override=default;};
class AuxAdblockGetSubscriptionsFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.getSubscriptions",AUXADBLOCK_GETSUBSCRIPTIONS) protected:~AuxAdblockGetSubscriptionsFunction()override=default;};
class AuxAdblockAddSubscriptionFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.addSubscription",AUXADBLOCK_ADDSUBSCRIPTION) protected:~AuxAdblockAddSubscriptionFunction()override=default;};
class AuxAdblockSetSubscriptionEnabledFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.setSubscriptionEnabled",AUXADBLOCK_SETSUBSCRIPTIONENABLED) protected:~AuxAdblockSetSubscriptionEnabledFunction()override=default;};
class AuxAdblockRemoveSubscriptionFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.removeSubscription",AUXADBLOCK_REMOVESUBSCRIPTION) protected:~AuxAdblockRemoveSubscriptionFunction()override=default;};
class AuxAdblockStartSubscriptionUpdateFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.startSubscriptionUpdate",AUXADBLOCK_STARTSUBSCRIPTIONUPDATE) protected:~AuxAdblockStartSubscriptionUpdateFunction()override=default;};
class AuxAdblockGetSubscriptionUpdateProgressFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.getSubscriptionUpdateProgress",AUXADBLOCK_GETSUBSCRIPTIONUPDATEPROGRESS) protected:~AuxAdblockGetSubscriptionUpdateProgressFunction()override=default;};
class AuxAdblockGetCustomRulesFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.getCustomRules",AUXADBLOCK_GETCUSTOMRULES) protected:~AuxAdblockGetCustomRulesFunction()override=default;};
class AuxAdblockSaveCustomRulesFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.saveCustomRules",AUXADBLOCK_SAVECUSTOMRULES) protected:~AuxAdblockSaveCustomRulesFunction()override=default;};
class AuxAdblockTestRequestFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.testRequest",AUXADBLOCK_TESTREQUEST) protected:~AuxAdblockTestRequestFunction()override=default;};
class AuxAdblockGetDiagnosticsFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.getDiagnostics",AUXADBLOCK_GETDIAGNOSTICS) protected:~AuxAdblockGetDiagnosticsFunction()override=default;};
class AuxAdblockReloadManualFiltersFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.reloadManualFilters",AUXADBLOCK_RELOADMANUALFILTERS) protected:~AuxAdblockReloadManualFiltersFunction()override=default;};
class AuxAdblockClearEngineCacheFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.clearEngineCache",AUXADBLOCK_CLEARENGINECACHE) protected:~AuxAdblockClearEngineCacheFunction()override=default;};
class AuxAdblockPauseSiteFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.pauseSite",AUXADBLOCK_PAUSESITE) protected:~AuxAdblockPauseSiteFunction()override=default;};
class AuxAdblockResumeSiteFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.resumeSite",AUXADBLOCK_RESUMESITE) protected:~AuxAdblockResumeSiteFunction()override=default;};
class AuxAdblockGetPausedSitesFunction final:public AuxAdblockFunction {public:DECLARE_EXTENSION_FUNCTION("auxAdblock.getPausedSites",AUXADBLOCK_GETPAUSEDSITES) protected:~AuxAdblockGetPausedSitesFunction()override=default;};
}  // namespace extensions
#endif
