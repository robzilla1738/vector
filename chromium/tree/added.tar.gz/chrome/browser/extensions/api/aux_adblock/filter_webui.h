// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_FILTER_WEBUI_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_FILTER_WEBUI_H_
#include "content/public/browser/web_ui_controller.h"
#include "content/public/browser/webui_config.h"
namespace aux_adblock {
class FilterWebUI : public content::WebUIController {
 public:
  explicit FilterWebUI(content::WebUI*);
  ~FilterWebUI() override;
};
class FilterWebUIConfig : public content::DefaultWebUIConfig<FilterWebUI> {
 public:
  FilterWebUIConfig() : DefaultWebUIConfig("chrome", "aux-adblock-internals") {}
  // A debug page: it answers only with Developer mode on.
  bool IsWebUIEnabled(content::BrowserContext* browser_context) override;
};
}  // namespace aux_adblock
#endif
