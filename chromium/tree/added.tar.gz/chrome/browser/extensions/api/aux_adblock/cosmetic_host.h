// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_COSMETIC_HOST_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_COSMETIC_HOST_H_
#include "components/aux_adblock/mojom/filters.mojom.h"
#include "mojo/public/cpp/bindings/pending_receiver.h"
namespace content {
class RenderFrameHost;
}
namespace aux_adblock {
void BindCosmeticHost(content::RenderFrameHost*,
                      mojo::PendingReceiver<mojom::CosmeticHost>);
}
#endif
