// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#include "chrome/browser/extensions/api/aux_adblock/aux_adblock_api.h"

#include "base/functional/bind.h"
#include "chrome/browser/extensions/api/aux_adblock/filter_service.h"
namespace extensions {
ExtensionFunction::ResponseAction AuxAdblockFunction::RunAux() {
  aux_adblock::FilterService::Get(profile())->Invoke(
      std::string(std::string_view(name()).substr(11)), args().Clone(),
      base::BindOnce(
          [](scoped_refptr<AuxAdblockFunction> self,
             std::optional<base::Value> result, std::string error) {
            if (!result) {
              self->Respond(self->Error(error));
            } else if (result->is_none()) {
              self->Respond(self->NoArguments());
            } else {
              self->Respond(self->WithArguments(std::move(*result)));
            }
          },
          base::WrapRefCounted(this)));
  return did_respond() ? AlreadyResponded() : RespondLater();
}
}  // namespace extensions
