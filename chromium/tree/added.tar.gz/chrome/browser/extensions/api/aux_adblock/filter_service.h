// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_FILTER_SERVICE_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_FILTER_SERVICE_H_
#include <deque>
#include <map>

#include "base/callback_list.h"
#include "base/files/file_path.h"
#include "base/memory/weak_ptr.h"
#include "base/supports_user_data.h"
#include "base/task/sequenced_task_runner.h"
#include "chrome/browser/profiles/profile.h"
#include "components/aux_adblock/engine.h"
#include "services/network/public/cpp/simple_url_loader.h"
namespace aux_adblock {
class FilterService final : public base::SupportsUserData::Data {
 public:
  static FilterService* Get(Profile* profile);
  explicit FilterService(Profile* profile);
  ~FilterService() override;
  bool ready() const { return loaded_ && engine_ != nullptr; }
  void WhenReady(base::OnceClosure ready);
  base::CallbackListSubscription ObserveCosmetics(
      base::RepeatingClosure changed);
  bool loaded() const { return loaded_; }
  bool enabled() const { return enabled_; }
  Decision Evaluate(const Request& request) const;
  base::DictValue Cosmetics(const GURL& document) const;
  // Callback always runs on UI. Unknown/invalid operations return an error.
  using Reply =
      base::OnceCallback<void(std::optional<base::Value>, std::string)>;
  void Invoke(std::string method, base::ListValue arguments, Reply reply);

 private:
  void DidLoad(base::DictValue stored);
  base::DictValue State() const;
  base::DictValue Diagnostics() const;
  base::DictValue CustomRules() const;
  void Compile();
  void StartCompile();
  void DidCompile(uint64_t generation,
                  base::TimeTicks began,
                  std::shared_ptr<const Engine> engine);
  void Persist();
  base::DictValue* Subscription(std::string_view id);
  std::string StartUpdate(const std::vector<std::string>& ids);
  void DownloadNext();
  void DidDownload(std::string job_id,
                   std::string id,
                   std::optional<std::string> body);
  void FinishItem(std::string job_id,
                  std::string id,
                  std::string status,
                  std::string error);
  base::RepeatingClosureList cosmetic_observers_;
  std::vector<base::OnceClosure> ready_callbacks_;
  base::WeakPtr<Profile> profile_;
  const base::FilePath directory_;
  scoped_refptr<base::SequencedTaskRunner> files_;
  bool loaded_ = false, enabled_ = true, compiling_ = false,
       compile_inflight_ = false;
  uint64_t requested_ = 0, active_ = 0;
  double compile_ms_ = 0, installed_ms_ = 0;
  std::string rules_, compile_error_, manual_error_;
  std::optional<std::string> pending_rules_;
  base::ListValue subscriptions_;
  std::map<std::string, std::string> texts_;
  std::map<std::string, std::optional<std::string>> previous_texts_;
  std::vector<Source> manual_;
  std::map<std::string, base::DictValue> jobs_;
  std::deque<std::pair<std::string, std::string>> queue_;
  std::shared_ptr<const Engine> engine_;
  std::unique_ptr<network::SimpleURLLoader> loader_;
  base::WeakPtrFactory<FilterService> weak_{this};
};
}  // namespace aux_adblock
#endif
