// Copyright 2026 Aux Authors. BSD-3-Clause; see //LICENSE.
#ifndef CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_FILTER_HOOKS_H_
#define CHROME_BROWSER_EXTENSIONS_API_AUX_ADBLOCK_FILTER_HOOKS_H_
#include <memory>

#include "base/functional/callback_forward.h"
#include "content/public/browser/frame_tree_node_id.h"
class GURL;
namespace blink {
class URLLoaderThrottle;
}
namespace content {
class BrowserContext;
class NavigationThrottleRegistry;
class RenderFrameHost;
class WebContents;
}  // namespace content
namespace aux_adblock {
std::unique_ptr<blink::URLLoaderThrottle> CreateRequestThrottle(
    content::BrowserContext* context,
    base::RepeatingCallback<content::WebContents*()> wc_getter,
    content::FrameTreeNodeId frame);
bool BlockWebSocket(content::RenderFrameHost* frame, const GURL& url);
void AddNavigationThrottle(content::NavigationThrottleRegistry& registry);
}  // namespace aux_adblock
#endif
