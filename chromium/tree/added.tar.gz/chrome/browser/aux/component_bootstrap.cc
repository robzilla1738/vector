// Copyright 2026 Aux Authors. All rights reserved.
// Independent component identity/new-tab registration, platform.md P5.
#include "chrome/browser/aux/component_bootstrap.h"

#include "base/base64.h"
#include "base/files/file_util.h"
#include "base/json/json_reader.h"
#include "components/crx_file/id_util.h"
namespace aux {
std::optional<std::vector<ComponentManifest>> ReadBundledComponents(
    const BundlePaths& paths) {
  std::vector<ComponentManifest> result;
  const auto root = base::MakeAbsoluteFilePath(paths.root);
  if (root.empty()) {
    return std::nullopt;
  }
  for (const auto& [id, directory] :
       std::vector<std::pair<std::string, base::FilePath>>{
           {kAgentExtensionId, paths.agent_extension}}) {
    const auto canonical = base::MakeAbsoluteFilePath(directory);
    const auto manifest_path =
        base::MakeAbsoluteFilePath(directory.AppendASCII("manifest.json"));
    std::string text;
    if (canonical.empty() || manifest_path.empty() ||
        !root.IsParent(canonical) || !canonical.IsParent(manifest_path) ||
        !base::ReadFileToStringWithMaxSize(manifest_path, &text, 1048576)) {
      return std::nullopt;
    }
    auto manifest = base::JSONReader::ReadDict(text, base::JSON_PARSE_RFC);
    const std::string* key = manifest ? manifest->FindString("key") : nullptr;
    auto decoded = key ? base::Base64Decode(*key) : std::nullopt;
    if (!decoded || crx_file::id_util::GenerateId(*decoded) != id) {
      return std::nullopt;
    }
    if (id == kAgentExtensionId) {
      const auto* override = manifest->FindDict("chrome_url_overrides");
      const auto* page = override ? override->FindString("newtab") : nullptr;
      if (!page || page->empty() || page->find(":") != std::string::npos ||
          page->find("..") != std::string::npos ||
          base::FilePath(*page).IsAbsolute()) {
        return std::nullopt;
      }
      const auto page_path =
          base::MakeAbsoluteFilePath(canonical.AppendASCII(*page));
      if (page_path.empty() || !canonical.IsParent(page_path) ||
          !base::PathExists(page_path)) {
        return std::nullopt;
      }
    }
    result.push_back({id, canonical, std::move(*manifest)});
  }
  return result;
}
bool RegisterBundledComponents(
    std::vector<ComponentManifest> components,
    base::RepeatingCallback<std::string(base::DictValue, const base::FilePath&)>
        installer) {
  if (components.size() != 1 || components[0].id != kAgentExtensionId) {
    return false;
  }
  for (auto& component : components) {
    if (installer.Run(std::move(component.manifest), component.directory) !=
        component.id) {
      return false;
    }
  }
  return true;
}
}  // namespace aux
