// Copyright 2026 Aux Authors. All rights reserved.
// Disposable-home integration probe; never prints keys, signatures or tokens.
#include "base/at_exit.h"
#include "base/command_line.h"
#include "base/files/file_util.h"
#include "base/json/json_reader.h"
#include "base/json/json_writer.h"
#include "chrome/browser/aux/installation_auth.h"
#include "chrome/browser/devtools/aux_cdp_authority.h"
#include "net/base/ip_address.h"
int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  base::CommandLine::Init(argc, argv);
  const auto home =
      base::CommandLine::ForCurrentProcess()->GetSwitchValuePath("home");
  if (home.empty()) {
    return 1;
  }
  std::string fixture;
  if (!base::ReadFileToString(home.AppendASCII("input.json"), &fixture)) {
    return 2;
  }
  auto input = base::JSONReader::ReadDict(fixture, base::JSON_PARSE_RFC);
  if (!input) {
    return 3;
  }
  const auto* challenge = input->FindString("challenge");
  const auto* signature = input->FindString("signature");
  if (!challenge || !signature) {
    return 4;
  }
  auto key = aux::LoadInstallationPublicKey(home);
  if (!key || !aux::VerifyInstallationChallenge(*key, *challenge, *signature)) {
    return 5;
  }
  auto native_signature = aux::SignDaemonChallenge(home, *challenge);
  if (!native_signature ||
      !base::WriteFile(home.AppendASCII("native-signature"),
                       *native_signature) ||
      !base::SetPosixFilePermissions(home.AppendASCII("native-signature"),
                                     0600)) {
    return 6;
  }
  aux::CdpAuthority authority(*key, 45203, {});
  net::HttpServerRequestInfo request;
  request.peer = net::IPEndPoint(net::IPAddress::IPv4Localhost(), 40000);
  request.method = "GET";
  request.path = "/json/challenge";
  request.headers["host"] = "127.0.0.1:45203";
  auto response = authority.Filter(request, false);
  if (!response || response->status != 200) {
    return 7;
  }
  auto issued =
      base::JSONReader::ReadDict(response->body, base::JSON_PARSE_RFC);
  if (!issued) {
    return 8;
  }
  auto signed_challenge =
      aux::SignDaemonChallenge(home, *issued->FindString("challenge"));
  if (!signed_challenge) {
    return 9;
  }
  base::DictValue session;
  session.Set("challengeId", *issued->FindString("challengeId"));
  session.Set("signedChallenge", *signed_challenge);
  request.method = "POST";
  request.path = "/json/auth/session";
  request.data = base::WriteJson(session).value_or("");
  response = authority.Filter(request, false);
  if (!response || response->status != 200) {
    return 10;
  }
  auto token = base::JSONReader::ReadDict(response->body, base::JSON_PARSE_RFC);
  if (!token || !token->FindString("access_token")) {
    return 11;
  }
  response = authority.Filter(request, false);
  if (!response || response->status != 401) {
    return 12;
  }
  request.method = "GET";
  request.path = "/json/version?test=1";
  request.data.clear();
  response = authority.Filter(request, false);
  if (!response || response->status != 401) {
    return 13;
  }
  request.headers["authorization"] =
      "AuxSessionToken " + *token->FindString("access_token");
  if (authority.Filter(request, false)) {
    return 14;
  }
  request.path = "/devtools/browser/disposable";
  if (authority.Filter(request, true)) {
    return 15;
  }
  request.headers["host"] = "evil.example";
  response = authority.Filter(request, true);
  if (!response || response->status != 403) {
    return 16;
  }
  request.headers["host"] = "127.0.0.1:45203";
  request.headers["origin"] = "https://evil.example";
  response = authority.Filter(request, false);
  if (!response || response->status != 403) {
    return 17;
  }
  return 0;
}
