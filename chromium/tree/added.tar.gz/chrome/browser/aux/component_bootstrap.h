// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_AUX_COMPONENT_BOOTSTRAP_H_
#define CHROME_BROWSER_AUX_COMPONENT_BOOTSTRAP_H_
#include <optional>
#include <string>
#include <vector>

#include "base/functional/callback.h"
#include "base/values.h"
#include "chrome/browser/aux/daemon_supervisor.h"
namespace aux {
inline constexpr char kAgentExtensionId[] = "gokkffaiccpmoeodpmeamcjajcagjmkm";
inline constexpr char kVaultExtensionId[] = "nbpghnminpifekjbgjefioajhiilbfla";
struct ComponentManifest {
  std::string id;
  base::FilePath directory;
  base::DictValue manifest;
};
// Read on a worker before profile extensions initialize. Both bundles must
// validate.
std::optional<std::vector<ComponentManifest>> ReadBundledComponents(
    const BundlePaths& paths);
// Call on UI before initial normal tab navigation; bind installer to
// ComponentLoader::Add.
bool RegisterBundledComponents(
    std::vector<ComponentManifest> components,
    base::RepeatingCallback<std::string(base::DictValue, const base::FilePath&)>
        installer);
}  // namespace aux
#endif
