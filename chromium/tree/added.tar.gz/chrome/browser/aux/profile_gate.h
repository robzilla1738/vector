// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_AUX_PROFILE_GATE_H_
#define CHROME_BROWSER_AUX_PROFILE_GATE_H_
#include <memory>

#include "base/functional/callback.h"
class BrowserWindowInterface;
class Profile;
class GURL;
namespace content {
class WebContents;
}
namespace aux {
// Header-only lifecycle seam for the actual native Profile creation owner.
// The definition and enum remain in the existing profile identity/UI owners;
// this declaration introduces no reverse dependency on the full UI target.
enum class FreshProfileIdentityInitialization;
FreshProfileIdentityInitialization InitializeFreshProfileIdentity(Profile* profile);
// Local browser visibility lifecycle. Account and daemon authorization are
// separate from browser visibility; Aux does not include a password vault.
bool CanShowBrowser(
    BrowserWindowInterface* browser,
    base::RepeatingCallback<void(content::WebContents*)> initialize_tab = {});
// Native post-profile-setup continuation; enables new-tab preloading without
// opening the excluded Vault/account onboarding product.
void RequestProfileBootstrap(Profile* profile);
void ShutdownProfileGates();
}  // namespace aux
#endif
