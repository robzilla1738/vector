#include "AuxSelectedStateHome.h"
#include "AuxNativeParentColdLaunch.h"
#include "chrome/browser/aux/ui_storage_migration_completion.h"
#include "AuxBrowserPrivateRoots.h"
#include "base/files/scoped_file.h"
#include "base/base64.h"
#include "base/functional/bind.h"
#include "base/threading/thread.h"
#include "base/threading/platform_thread.h"
#include "base/time/time.h"
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <limits.h>
#include <chrono>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <array>
#include <iterator>
#include <mutex>
#include <optional>
#include <set>

namespace aux::peer {
namespace {
constexpr auto kMaximumReadyPulseAge = std::chrono::seconds(10);
constexpr uint32_t kServiceReceiveTimeoutMs = 250;
struct State {
  const pid_t process = getpid();
  std::mutex mutex;
  bool selected_route = false;
  bool closed = false;
  bool initializing = false;
  bool monitor_running = false;
  uint64_t active_reads = 0;
  std::shared_ptr<SelectedNativeHome> selected;
  std::shared_ptr<const BrowserPrivateRoots> admitted_browser_roots;
  uint64_t browser_generation = 0;
  bool browser_attempted = false;
  uint32_t browser_shutdown_phase = 0;
  bool browser_shutdown_uncertain = false;
  std::optional<base::PlatformThreadRef> browser_shutdown_thread;
  std::optional<NativeChildObservation> child_close;
  std::unique_ptr<base::Thread> monitor;
  std::optional<base::PlatformThreadRef> monitor_creator;
};
State& CurrentState() {
  static auto* state = new State;
  return *state;
}
bool Fresh(const ReadyHomePulse& pulse) {
  auto now = std::chrono::steady_clock::now();
  return pulse.exports && pulse.observed <= now && now - pulse.observed <= kMaximumReadyPulseAge;
}
std::optional<base::FilePath> PhysicalPath(int descriptor) {
  std::array<char, PATH_MAX> path{}, resolved{};
  if (fcntl(descriptor, F_GETPATH, path.data()) != 0) return std::nullopt;
  const auto path_end = std::find(path.begin(), path.end(), '\0');
  if (path_end == path.end() || !realpath(path.data(), resolved.data())) return std::nullopt;
  const auto resolved_end = std::find(resolved.begin(), resolved.end(), '\0');
  if (resolved_end == resolved.end() ||
      !std::equal(path.begin(), path_end, resolved.begin(), resolved_end)) return std::nullopt;
  base::ScopedFD reopened(open(path.data(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC));
  struct stat retained{}, current{};
  if (!reopened.is_valid() || fstat(descriptor, &retained) != 0 || fstat(reopened.get(), &current) != 0 ||
      retained.st_dev != current.st_dev || retained.st_ino != current.st_ino) return std::nullopt;
  return base::FilePath(std::string(path.begin(), path_end));
}
void Monitor(std::shared_ptr<SelectedNativeHome> selected) {
  auto& state = CurrentState();
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.selected != selected) return;
    state.monitor_running = true;
  }
  bool admission_closed = false;
  for (;;) {
    bool closed;
    {
      std::lock_guard<std::mutex> lock(state.mutex);
      if (state.selected != selected) break;
      closed = state.closed;
    }
    if (!closed) {
      auto status = selected->ServicePeerOnce(kServiceReceiveTimeoutMs);
      if (status == ExchangeStatus::authenticated || status == ExchangeStatus::timedOut) continue;
      std::lock_guard<std::mutex> lock(state.mutex);
      state.closed = true;
    }
    // Keep the existing sole child reaper alive after admission closes. Closing
    // a peer is not exit evidence; a still-running child remains retained.
    if (!admission_closed) {
      selected->CloseNativeAdmission();
      admission_closed = true;
    }
    auto child = selected->InspectOwnedChild();
    {
      std::lock_guard<std::mutex> lock(state.mutex);
      state.child_close = child;
    }
    if (child.exit_observed_and_reaped || child.launch_failed ||
        child.exit_ownership_unknown || child.wrong_process) break;
    // This is the existing background monitor, never a UI-thread shutdown wait.
    base::PlatformThread::Sleep(base::Milliseconds(kServiceReceiveTimeoutMs));
  }
  std::lock_guard<std::mutex> lock(state.mutex);
  state.monitor_running = false;
}
SelectedStateHomeObservation ObserveLocked(const State& state) {
  auto route = SelectedStateHomeRoute::unselected;
  if (state.closed) route = SelectedStateHomeRoute::closed;
  else if (state.selected_route) route = SelectedStateHomeRoute::unavailable;
  return {route, state.monitor_running, state.active_reads, state.initializing,
          state.monitor != nullptr, state.child_close};
}
enum class AuthorityOperation { daemonSignature, publicKeys, inboxKeyV2 };
void ClearPayload(DaemonAuthorityReply& reply) {
  for (auto& byte : reply.payload) {
    volatile uint8_t& owned_byte = byte;
    owned_byte = 0;
  }
  reply.payload.clear();
}
DaemonAuthorityReply CallAuthority(AuthorityOperation operation, std::span<const uint8_t> message, bool observe_only = false) {
  auto& state = CurrentState();
  if (getpid() != state.process) return {DaemonAuthorityStatus::wrongProcess, {}};
  std::shared_ptr<SelectedNativeHome> owner;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if ((state.closed || state.browser_shutdown_phase != 0)) return {DaemonAuthorityStatus::closed, {}};
    if (!state.selected_route || state.initializing || !state.selected)
      return {DaemonAuthorityStatus::refused, {}};
    owner = state.selected;
    ++state.active_reads;
  }
  auto finish = +[](State* retained) {
    std::lock_guard<std::mutex> lock(retained->mutex);
    --retained->active_reads;
  };
  std::unique_ptr<State, decltype(finish)> active(&state, finish);
  auto before = owner->InspectReadyPulse();
  if (!before || !Fresh(*before)) return {DaemonAuthorityStatus::pending, {}};
  DaemonAuthorityReply reply;
  switch (operation) {
    case AuthorityOperation::daemonSignature: reply = owner->SignDaemonChallenge(message, 2'000, observe_only); break;
    case AuthorityOperation::publicKeys: reply = owner->GetInstallationPublicKeys(2'000); break;
    case AuthorityOperation::inboxKeyV2: reply = owner->GetAgentInboxV2MasterKey(2'000); break;
  }
  if (reply.status == DaemonAuthorityStatus::closed || reply.status == DaemonAuthorityStatus::wrongProcess ||
      reply.status == DaemonAuthorityStatus::cleanupUnresolved) {
    {
      std::lock_guard<std::mutex> lock(state.mutex);
      state.closed = true;
    }
    auto closed = owner->CloseNativeAdmission();
    std::lock_guard<std::mutex> lock(state.mutex);
    state.child_close = closed;
    ClearPayload(reply);
    return reply;
  }
  if (reply.status != DaemonAuthorityStatus::ready) {
    ClearPayload(reply);
    return reply;
  }
  auto after = owner->InspectReadyPulse();
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if ((state.closed || state.browser_shutdown_phase != 0) || state.selected != owner) {
      ClearPayload(reply);
      return {DaemonAuthorityStatus::closed, {}};
    }
    if (!after || !Fresh(*after) || after->generation != before->generation || after->exports < before->exports) {
      ClearPayload(reply);
      return {DaemonAuthorityStatus::pending, {}};
    }
  }
  if (reply.payload.empty() || reply.payload.size() > 8192 ||
      (operation == AuthorityOperation::inboxKeyV2 && reply.payload.size() != 32)) {
    ClearPayload(reply);
    return {DaemonAuthorityStatus::refused, {}};
  }
  // The private response ticket remains unacknowledged until this actual
  // publication fence. The transport revalidates owner/generation at ACK.
  // No mutex crosses that authenticated peer callback.
  const auto accepted = owner->AcceptAuthorityReply(reply, 2'000);
  if (accepted != DaemonAuthorityStatus::ready) {
    ClearPayload(reply);
    return {accepted, {}};
  }
  // Do not discard an acknowledged signature in a second post-ACK fence:
  // the supervisor retains it before its own later publication validation.
  return reply;
}
}  // namespace
bool InstallNativeSelectedStateHome(std::unique_ptr<SelectedNativeHome> selected) {
  auto& state = CurrentState();
  if (getpid() != state.process || !selected) return false;
  auto owner = std::shared_ptr<SelectedNativeHome>(std::move(selected));
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if ((state.closed || state.browser_shutdown_phase != 0) || state.selected_route) return false;
    state.selected_route = true;
    state.initializing = true;
    state.selected = owner;
  }
  // No mutex crosses Security/resource callbacks or thread initialization.
  auto pulse = owner->InspectReadyPulse();
  base::ScopedFD directory(owner->DuplicateRevalidatedDirectory());
  auto monitor = std::make_unique<base::Thread>("AuxSelectedHomePeer");
  const bool thread_started = pulse && Fresh(*pulse) && directory.is_valid() && monitor->Start();
  const bool queued = thread_started && monitor->task_runner()->PostTask(FROM_HERE, base::BindOnce(&Monitor, owner));
  bool installed = false;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    state.initializing = false;
    if (thread_started) {
      // Even failed/closed initialization retains its actual thread until a
      // later creator-thread close observes the monitor has left callbacks.
      state.monitor_creator = base::PlatformThread::CurrentRef();
      state.monitor = std::move(monitor);
    }
    installed = queued && !(state.closed || state.browser_shutdown_phase != 0);
    if (!installed) state.closed = true;
  }
  if (!installed) {
    auto closed = owner->CloseNativeAdmission();
    std::lock_guard<std::mutex> lock(state.mutex);
    state.child_close = closed;
  }
  return installed;
}
SelectedStateHomeResolution ReadNativeSelectedStateHome() {
  auto& state = CurrentState();
  if (getpid() != state.process) return {SelectedStateHomeRoute::wrongProcess, {}};
  std::shared_ptr<SelectedNativeHome> owner;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if ((state.closed || state.browser_shutdown_phase != 0)) return {SelectedStateHomeRoute::closed, {}};
    if (!state.selected_route) return {SelectedStateHomeRoute::unselected, {}};
    if (state.initializing || !state.selected) return {SelectedStateHomeRoute::unavailable, {}};
    owner = state.selected;
    ++state.active_reads;
  }
  auto finish = +[](State* retained) {
    std::lock_guard<std::mutex> lock(retained->mutex);
    --retained->active_reads;
  };
  std::unique_ptr<State, decltype(finish)> active(&state, finish);
  auto pulse = owner->InspectReadyPulse();
  if (!pulse || !Fresh(*pulse)) return {SelectedStateHomeRoute::unavailable, {}};
  base::ScopedFD directory(owner->DuplicateRevalidatedDirectory());
  auto path = directory.is_valid() ? PhysicalPath(directory.get()) : std::nullopt;
  if (!path) return {SelectedStateHomeRoute::unavailable, {}};
  auto current = owner->InspectReadyPulse();
  auto child = owner->InspectOwnedChild();
  if (child.closed || child.wrong_process || child.exit_observed_and_reaped ||
      child.exit_ownership_unknown || child.child_pid <= 1) return {SelectedStateHomeRoute::unavailable, {}};
  std::lock_guard<std::mutex> lock(state.mutex);
  if ((state.closed || state.browser_shutdown_phase != 0)) return {SelectedStateHomeRoute::closed, {}};
  if (state.selected != owner || !current || current->generation != pulse->generation ||
      current->exports < pulse->exports || !Fresh(*current)) return {SelectedStateHomeRoute::unavailable, {}};
  return {SelectedStateHomeRoute::current, *path, current->exports, child.child_pid};
}
DaemonAuthorityReply ExchangeNativeSelectedHostFrame(std::span<const uint8_t> frame) {
  auto& state = CurrentState();
  if (getpid() != state.process) return {DaemonAuthorityStatus::wrongProcess, {}};
  if (frame.empty() || frame.size() > 8192) return {};
  std::shared_ptr<SelectedNativeHome> owner;
  std::shared_ptr<const BrowserPrivateRoots> roots;
  uint64_t generation = 0;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.closed || state.browser_shutdown_phase || state.initializing ||
        !state.selected || !state.admitted_browser_roots || !state.browser_generation) return {};
    owner = state.selected; roots = state.admitted_browser_roots;
    generation = state.browser_generation;
    ++state.active_reads;
  }
  auto finish = +[](State* held) { std::lock_guard<std::mutex> lock(held->mutex); --held->active_reads; };
  std::unique_ptr<State, decltype(finish)> active(&state, finish);
  auto valid = [&] {
    auto pulse = owner->InspectReadyPulse();
    auto child = owner->InspectOwnedChild();
    if (!pulse || !Fresh(*pulse) || pulse->generation != generation || !roots->Revalidate() ||
        child.closed || child.wrong_process || child.exit_observed_and_reaped ||
        child.exit_ownership_unknown || child.child_pid <= 1) return false;
    std::lock_guard<std::mutex> lock(state.mutex);
    return !state.closed && !state.browser_shutdown_phase && state.selected == owner &&
        state.admitted_browser_roots == roots && state.browser_generation == generation;
  };
  if (!valid()) return {};
  auto reply = owner->ExchangeNativeHostFrame(frame, 2'000);
  if (reply.status != DaemonAuthorityStatus::ready) return reply;
  // A lost holder fence/ACK is unknown, not proof that physical IO did not run.
  if (!valid()) return {};
  auto accepted = owner->AcceptAuthorityReply(reply, 2'000);
  if (accepted != DaemonAuthorityStatus::ready) return {accepted, {}};
  if (!valid()) return {};
  return reply;
}
DaemonAuthorityReply ExchangeNativeSelectedUiCaptureFrame(std::span<const uint8_t> frame) {
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
  // This bounded ordinary mode has no migration/privileged drain authority.
  return {DaemonAuthorityStatus::refused, {}};
#else
  auto& state = CurrentState();
  if (getpid() != state.process) return {DaemonAuthorityStatus::wrongProcess, {}};
  if (frame.empty() || frame.size() > 8192) return {};
  std::shared_ptr<SelectedNativeHome> owner;
  std::shared_ptr<const BrowserPrivateRoots> roots;
  uint64_t generation = 0;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.closed || state.browser_shutdown_phase || state.initializing ||
        !state.selected || !state.admitted_browser_roots || !state.browser_generation) return {};
    owner = state.selected; roots = state.admitted_browser_roots;
    generation = state.browser_generation;
    ++state.active_reads;
  }
  auto finish = +[](State* held) { std::lock_guard<std::mutex> lock(held->mutex); --held->active_reads; };
  std::unique_ptr<State, decltype(finish)> active(&state, finish);
  auto valid = [&] {
    auto pulse = owner->InspectReadyPulse();
    auto child = owner->InspectOwnedChild();
    if (!pulse || !Fresh(*pulse) || pulse->generation != generation || !roots->Revalidate() ||
        child.closed || child.wrong_process || child.exit_observed_and_reaped ||
        child.exit_ownership_unknown || child.child_pid <= 1) return false;
    std::lock_guard<std::mutex> lock(state.mutex);
    return !state.closed && !state.browser_shutdown_phase && state.selected == owner &&
        state.admitted_browser_roots == roots && state.browser_generation == generation;
  };
  if (!valid()) return {};
  auto reply = owner->ExchangeUiCaptureFrame(frame, 2'000);
  if (reply.status != DaemonAuthorityStatus::ready) return reply;
  // A lost holder fence/ACK is unknown, not proof that physical IO did not run.
  if (!valid()) return {};
  auto accepted = owner->AcceptAuthorityReply(reply, 2'000);
  if (accepted != DaemonAuthorityStatus::ready) return {accepted, {}};
  if (!valid()) return {};
  return reply;
#endif
}
std::optional<UiStorageMigrationOwnerAck> AcceptNativeSelectedUiMigrationCompletion(
    UiStorageMigrationCompletion& completion) {
  auto& state = CurrentState();
  if (getpid() != state.process || !completion.IsCurrent() ||
      !completion.native_generation()) return std::nullopt;
  const std::string fingerprint(completion.terminal_fingerprint());
  if (fingerprint.size() != 64 || !std::all_of(fingerprint.begin(), fingerprint.end(),
      [](char value) { return (value >= '0' && value <= '9') ||
                            (value >= 'a' && value <= 'f'); })) return std::nullopt;
  std::shared_ptr<SelectedNativeHome> owner;
  std::shared_ptr<const BrowserPrivateRoots> roots;
  const uint64_t generation = completion.native_generation();
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.closed || state.browser_shutdown_phase || state.initializing ||
        !state.selected || !state.admitted_browser_roots ||
        state.browser_generation != generation) return std::nullopt;
    owner = state.selected;
    roots = state.admitted_browser_roots;
  }
  auto current = base::BindRepeating([](std::weak_ptr<SelectedNativeHome> weak_owner,
      std::shared_ptr<const BrowserPrivateRoots> expected_roots,
      uint64_t expected_generation) {
    auto& actual = CurrentState();
    auto retained = weak_owner.lock();
    if (getpid() != actual.process || !retained || !expected_roots->Revalidate()) return false;
    auto pulse = retained->InspectReadyPulse();
    auto child = retained->InspectOwnedChild();
    if (!pulse || !Fresh(*pulse) || pulse->generation != expected_generation ||
        child.closed || child.wrong_process || child.exit_observed_and_reaped ||
        child.exit_ownership_unknown || child.child_pid <= 1) return false;
    std::lock_guard<std::mutex> lock(actual.mutex);
    return !actual.closed && !actual.browser_shutdown_phase && !actual.initializing &&
        actual.selected == retained && actual.admitted_browser_roots == expected_roots &&
        actual.browser_generation == expected_generation;
  }, std::weak_ptr<SelectedNativeHome>(owner), roots, generation);
  if (!current.Run()) return std::nullopt;
  const auto frame = completion.TerminalReadFrame();
  // Read-only exact terminal-record discovery on the original native journal.
  // Neither a root/path nor a publication/readiness boolean is accepted here.
  if (frame.size() != 21 || frame.front() != 10) return std::nullopt;
  auto reply = ExchangeNativeSelectedUiCaptureFrame(frame);
  if (reply.status != DaemonAuthorityStatus::ready || !current.Run() ||
      !completion.IsCurrent() || completion.native_generation() != generation ||
      completion.terminal_fingerprint() != fingerprint ||
      !completion.MatchesTerminalReply(reply.payload)) return std::nullopt;
  // This ACK acknowledges the actual durable UI-transaction terminal record.
  // It cannot select an installation, change its format or admit other writers.
  return UiStorageMigrationOwnerAck(generation, fingerprint, std::move(current));
}

// No caller path, token, FD, generation or readiness flag can mint admission.
bool AuthorizeNativeBrowserStartupBeforeLocalState() {
  auto refused = [](int stage) {
    fprintf(stderr, "Aux browser startup authorization refused at phase %d\n", stage);
    return false;
  };
  auto& state = CurrentState();
  if (getpid() != state.process) return refused(1);
  auto roots = CaptureActualChromiumBrowserRoots();
  if (!roots) return refused(2);
  std::shared_ptr<SelectedNativeHome> owner;
  uint64_t admitted_generation = 0;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if ((state.closed || state.browser_shutdown_phase != 0) || state.initializing || !state.selected) return refused(3);
    owner = state.selected;
    admitted_generation = state.browser_generation;
    if (!admitted_generation) {
      if (state.browser_attempted) return refused(4);
      state.browser_attempted = true;
    }
    ++state.active_reads;
  }
  auto finish = +[](State* held) {std::lock_guard<std::mutex> lock(held->mutex);--held->active_reads;};
  std::unique_ptr<State, decltype(finish)> active(&state, finish);
  auto pulse = owner->InspectReadyPulse();
  if (!pulse || !Fresh(*pulse) || !roots->Revalidate()) return refused(5);
  if (!admitted_generation) {
    const auto deadline = NativeBrowserStartupDeadline();
    auto current_startup = [&] {
      if (deadline.is_null() || base::TimeTicks::Now() >= deadline) return false;
      const auto current = owner->InspectReadyPulse();
      const auto child = owner->InspectOwnedChild();
      if (!current || !Fresh(*current) || current->generation != pulse->generation ||
          current->exports < pulse->exports || !roots->Revalidate() ||
          child.closed || child.wrong_process || child.exit_observed_and_reaped ||
          child.exit_ownership_unknown || child.child_pid <= 1) return false;
      std::lock_guard<std::mutex> lock(state.mutex);
      return !state.closed && !state.browser_shutdown_phase && !state.initializing &&
          state.selected == owner && !state.browser_generation &&
          base::TimeTicks::Now() < deadline;
    };
    auto next_slice = [&]() -> uint32_t {
      // RequestAuthority may send/receive twice when retiring a failed reply.
      // Bound all four transport waits by the remaining original budget.
      const int64_t remaining = (deadline - base::TimeTicks::Now()).InMilliseconds();
      return remaining < 4 ? 0 : static_cast<uint32_t>(std::min<int64_t>(2'000, remaining / 4));
    };
    auto transient = [](DaemonAuthorityStatus status) {
      return status == DaemonAuthorityStatus::timedOut || status == DaemonAuthorityStatus::pending;
    };
    auto pause_observation = [&] {
      const auto remaining = deadline - base::TimeTicks::Now();
      if (remaining.is_positive())
        base::PlatformThread::Sleep(std::min(base::Milliseconds(25), remaining));
    };
    DaemonAuthorityReply reply;
    for (;;) {
      if (!current_startup()) return refused(6);
      const auto slice = next_slice();
      if (!slice) return refused(6);
      // Same operation/body retains the original native nonce. After any send
      // attempt this observes that request; it never repeats the root grant.
      reply = owner->GetBrowserStartupLease(slice);
      if (!current_startup()) return refused(6);
      if (!transient(reply.status)) break;
      pause_observation();
    }
    if (reply.status != DaemonAuthorityStatus::ready)
      fprintf(stderr, "Aux browser startup lease status=%d bytes=%zu\n",
              static_cast<int>(reply.status), reply.payload.size());
    if (reply.status != DaemonAuthorityStatus::ready || reply.payload.size() != 72) return refused(6);
    uint64_t generation = 0;
    for (size_t i = 0; i < 8; ++i) generation |= static_cast<uint64_t>(reply.payload[i]) << (8*i);
    if (!generation || generation != pulse->generation) return refused(7);
    for (uint32_t role = 1; role <= 2; ++role) {
      auto digest = roots->PathDigest(role);
      if (!std::equal(digest.begin(), digest.end(), reply.payload.begin()+8+32*(role-1))) return refused(8);
    }
    auto current = owner->InspectReadyPulse();
    if (!current || !Fresh(*current) || current->generation != generation || !roots->Revalidate()) return refused(9);
    {
      std::lock_guard<std::mutex> lock(state.mutex);
      if ((state.closed || state.browser_shutdown_phase != 0) || state.selected != owner) return refused(10);
    }
    for (;;) {
      if (!current_startup()) return refused(11);
      const auto slice = next_slice();
      if (!slice) return refused(11);
      // Retain this exact ready publication across ACK uncertainty. Repeating
      // its nonce-bound ACK is idempotent; a timeout is never acceptance.
      const auto accepted = owner->AcceptAuthorityReply(reply, slice);
      if (!current_startup()) return refused(11);
      if (accepted == DaemonAuthorityStatus::ready) break;
      if (!transient(accepted)) return refused(11);
      pause_observation();
    }
#if !defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
    if (!owner->BindBrowserDescendantScope(generation)) return refused(12);
#endif
    admitted_generation = generation;
  }
  auto child = owner->InspectOwnedChild();
  auto after = owner->InspectReadyPulse();
  if (child.closed || child.wrong_process || child.exit_observed_and_reaped || child.exit_ownership_unknown ||
      !after || !Fresh(*after) || after->generation != admitted_generation || !roots->Revalidate()) return refused(13);
  std::lock_guard<std::mutex> lock(state.mutex);
  if ((state.closed || state.browser_shutdown_phase != 0) || state.selected != owner ||
      (state.admitted_browser_roots && state.admitted_browser_roots != roots)) return refused(14);
  state.admitted_browser_roots = std::move(roots);
  state.browser_generation = admitted_generation;
  return true;
}

std::optional<base::CommandLine> PrepareNativeHostPathWriteRestrictions(
    const base::CommandLine& host) {
  auto& state = CurrentState();
  if (getpid() != state.process || host.GetProgram().empty()) return std::nullopt;
  std::shared_ptr<SelectedNativeHome> owner;
  std::shared_ptr<const BrowserPrivateRoots> roots;
  uint64_t generation = 0;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.closed || state.browser_shutdown_phase || state.initializing ||
        !state.selected || !state.admitted_browser_roots || !state.browser_generation)
      return std::nullopt;
    owner = state.selected;
    roots = state.admitted_browser_roots;
    generation = state.browser_generation;
    ++state.active_reads;
  }
  auto finish = +[](State* held) {std::lock_guard<std::mutex> lock(held->mutex);--held->active_reads;};
  std::unique_ptr<State, decltype(finish)> active(&state, finish);
  if (!roots->Revalidate()) return std::nullopt;
  base::ScopedFD data(roots->DuplicateRevalidatedRoot(1));
  base::ScopedFD cache(roots->DuplicateRevalidatedRoot(2));
  auto data_path = data.is_valid() ? PhysicalPath(data.get()) : std::nullopt;
  auto cache_path = cache.is_valid() ? PhysicalPath(cache.get()) : std::nullopt;
  if (!data_path || !cache_path || *data_path == base::FilePath("/") ||
      *cache_path == base::FilePath("/")) return std::nullopt;
  // Parameters carry paths as data, never executable policy fragments.
  constexpr char kNativeHostPathRestrictions[] = R"aux((version 1)
(allow default)
(deny file-write* (subpath (param "AUX_DATA_ROOT")) (subpath (param "AUX_CACHE_ROOT")))
(deny file-link (subpath (param "AUX_DATA_ROOT")) (subpath (param "AUX_CACHE_ROOT")))
)aux";
  std::string policy(kNativeHostPathRestrictions);
  base::CommandLine wrapped(base::FilePath("/usr/bin/sandbox-exec"));
  auto parameter = [&](const std::string& key, const base::FilePath& path) {
    wrapped.AppendArg("-D");
    wrapped.AppendArg(key + "=" + path.value());
  };
  parameter("AUX_DATA_ROOT", *data_path);
  parameter("AUX_CACHE_ROOT", *cache_path);
  std::set<base::FilePath> ancestors;
  for (auto path : {*data_path, *cache_path}) {
    for (path = path.DirName(); path != path.DirName(); path = path.DirName())
      ancestors.insert(path);
  }
  size_t index = 0;
  for (const auto& path : ancestors) {
    const std::string key = "AUX_PARENT_" + std::to_string(index++);
    parameter(key, path);
    // Prevent a host from moving an ancestor then writing via the new path.
    policy += "(deny file-write-unlink (literal (param \"" + key + "\")))\n";
  }
  wrapped.AppendArg("-p");
  wrapped.AppendArg(policy);
  wrapped.AppendArg("--");
  wrapped.AppendArgPath(host.GetProgram());
  // GetArgs() excludes switches. Keep every original argv entry after the
  // program, including switches and the literal -- separator, in exact order.
  const auto& original_argv = host.argv();
  for (size_t i = 1; i < original_argv.size(); ++i)
    wrapped.AppendArg(original_argv[i]);
  auto pulse = owner->InspectReadyPulse();
  auto child = owner->InspectOwnedChild();
  if (!pulse || !Fresh(*pulse) || pulse->generation != generation || child.closed ||
      child.wrong_process || child.exit_observed_and_reaped || child.exit_ownership_unknown ||
      !roots->Revalidate()) return std::nullopt;
  std::lock_guard<std::mutex> lock(state.mutex);
  if (state.closed || state.browser_shutdown_phase || state.selected != owner ||
      state.admitted_browser_roots != roots || state.browser_generation != generation)
    return std::nullopt;
  return wrapped;
}
namespace {
void AdvanceNativeBrowserShutdown(uint32_t expected) {
  auto& state = CurrentState();
  if (getpid() != state.process) return;
  std::lock_guard<std::mutex> lock(state.mutex);
  const auto thread = base::PlatformThread::CurrentRef();
  if (expected == 1 && !state.browser_shutdown_thread)
    state.browser_shutdown_thread = thread;
  if (!state.browser_shutdown_thread || *state.browser_shutdown_thread != thread ||
      expected != state.browser_shutdown_phase + 1) {
    state.browser_shutdown_uncertain = true;
    // Even an out-of-order first observation closes future admissions.
    if (!state.browser_shutdown_phase) state.browser_shutdown_phase = 1;
    return;
  }
  state.browser_shutdown_phase = expected;
}
}
void BeginNativeBrowserShutdown() {
  aux::features::CloseNativeFeatureIoAdmission();
  AdvanceNativeBrowserShutdown(1);
}
void ObserveNativeBrowserProfileTeardown() { AdvanceNativeBrowserShutdown(2); }
void ObserveNativeBrowserThreadsDestroyed() { AdvanceNativeBrowserShutdown(3); }
void ObserveNativeBrowserProcessDestroyed() { AdvanceNativeBrowserShutdown(4); }
void ObserveNativeBrowserPostShutdownIO() { AdvanceNativeBrowserShutdown(5); }
void ObserveNativeBrowserPartsDestroyed() { AdvanceNativeBrowserShutdown(6); }
BrowserShutdownObservation InspectNativeBrowserShutdown() {
  auto& state = CurrentState();
  if (getpid() != state.process) return {.wrong_process = true};
  std::lock_guard<std::mutex> lock(state.mutex);
  // Later content/service/file writers are not proven drained.
  return {false, state.browser_shutdown_phase != 0,
          state.browser_shutdown_uncertain, state.browser_shutdown_phase,
          state.browser_generation, state.active_reads, state.monitor_running,
          false, aux::features::InspectNativeFeatureWrites()};
}
SelectedStateHomeObservation InspectNativeSelectedOwnedChildForShutdown() {
  auto& state = CurrentState();
  if (getpid() != state.process) return {SelectedStateHomeRoute::wrongProcess};
  std::shared_ptr<SelectedNativeHome> owner;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    if (state.initializing || !state.selected) return ObserveLocked(state);
    owner = state.selected;
    ++state.active_reads;
  }
  // Existing sole original-child wait/birth/reap owner. Never close its peer
  // merely because the authenticated shutdown request has been acknowledged.
  auto child = owner->InspectOwnedChild();
  std::lock_guard<std::mutex> lock(state.mutex);
  --state.active_reads;
  if (state.selected != owner) {
    state.browser_shutdown_uncertain = true;
    return {SelectedStateHomeRoute::unavailable};
  }
  state.child_close = child;
  return ObserveLocked(state);
}
SelectedStateHomeObservation CloseNativeSelectedStateHome() {
  aux::features::CloseNativeFeatureIoAdmission();
  auto& state = CurrentState();
  if (getpid() != state.process) return {SelectedStateHomeRoute::wrongProcess};
  std::shared_ptr<SelectedNativeHome> owner;
  std::unique_ptr<base::Thread> monitor;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    state.closed = true;
    owner = state.selected;
    // Never wait for a protected/resource callback on this close path. Join
    // only after the monitor has left callbacks, from its actual creator.
    // Other calls retain explicit pending thread/initialization observations.
    if (state.monitor && !state.monitor_running && !state.initializing &&
        state.monitor_creator == base::PlatformThread::CurrentRef() &&
        !state.monitor->task_runner()->RunsTasksInCurrentSequence())
      monitor = std::move(state.monitor);
  }
  if (owner) {
    auto closed = owner->CloseNativeAdmission();
    std::lock_guard<std::mutex> lock(state.mutex);
    state.child_close = closed;
  }
  if (monitor) monitor->Stop();
  std::lock_guard<std::mutex> lock(state.mutex);
  return ObserveLocked(state);
}
NativeDaemonSignatureReply ObserveNativeSelectedDaemonChallenge(std::string_view encoded_message, bool observe_only) {
  auto message = base::Base64Decode(encoded_message);
  constexpr char prefix[] = "Aux Daemon Auth v1\0";
  constexpr size_t prefix_size = sizeof(prefix) - 1;
  if (!message || message->size() != prefix_size + 32 ||
      !std::equal(std::begin(prefix), std::prev(std::end(prefix)), message->begin()))
    return {DaemonAuthorityStatus::refused, std::nullopt};
  auto reply = CallAuthority(AuthorityOperation::daemonSignature,
      std::span(*message), observe_only);
  if (reply.status != DaemonAuthorityStatus::ready) return {reply.status, std::nullopt};
  auto signature = base::Base64Encode(reply.payload);
  ClearPayload(reply);
  if (signature.empty() || signature.size() > 8192) return {DaemonAuthorityStatus::refused, std::nullopt};
  return {DaemonAuthorityStatus::ready, std::move(signature)};
}
std::optional<std::string> SignNativeSelectedDaemonChallenge(std::string_view encoded_message) {
  auto reply = ObserveNativeSelectedDaemonChallenge(encoded_message);
  return reply.status == DaemonAuthorityStatus::ready ? std::move(reply.signature) : std::nullopt;
}
std::optional<std::string> GetNativeSelectedInstallationPublicKeys() {
  auto reply = CallAuthority(AuthorityOperation::publicKeys, {});
  if (reply.status != DaemonAuthorityStatus::ready) return std::nullopt;
  std::string json(reply.payload.begin(), reply.payload.end());
  ClearPayload(reply);
  return json;
}
std::optional<std::array<uint8_t, 32>> GetNativeSelectedAgentInboxV2MasterKey() {
  auto reply = CallAuthority(AuthorityOperation::inboxKeyV2, {});
  if (reply.status != DaemonAuthorityStatus::ready || reply.payload.size() != 32) {
    ClearPayload(reply);
    return std::nullopt;
  }
  std::array<uint8_t, 32> key;
  std::copy(reply.payload.begin(), reply.payload.end(), key.begin());
  ClearPayload(reply);
  return key;
}
}  // namespace aux::peer
