// Copyright 2026 Aux Authors. All rights reserved.
// Platform bridge to the supplied native authority; no replacement private key.
#include "chrome/browser/aux/installation_auth.h"


#include <algorithm>
#include <array>

#include "base/base64.h"
#include "base/containers/span.h"
#include "base/environment.h"
#include "base/files/file.h"
#include "base/files/file_util.h"
#include "base/json/json_reader.h"
#include "base/path_service.h"
#include "base/functional/bind.h"
#include "base/task/thread_pool.h"
#include "base/strings/string_util.h"
#include "base/time/time.h"
#include "chrome/browser/aux/daemon_supervisor.h"
#include "AuxSelectedStateHome.h"
#include "crypto/sign.h"
namespace aux {
namespace {
constexpr size_t kMaxCarrierOutput = 32768;
std::optional<std::string> DecodeChallenge(std::string_view challenge) {
  auto bytes = base::Base64Decode(challenge);
  if (!bytes || bytes->size() != 32)
    return std::nullopt;
  return std::string(bytes->begin(), bytes->end());
}
std::optional<std::string> HttpMessage(std::string_view challenge) {
  auto bytes = DecodeChallenge(challenge);
  if (!bytes)
    return std::nullopt;
  return std::string("Aux Daemon Auth v1\0", sizeof("Aux Daemon Auth v1\0") - 1) + *bytes;
}
bool VerifyMessage(const crypto::keypair::PublicKey &key,
                   std::string_view message, std::string_view signature) {
  if (signature.size() > 8192)
    return false;
  auto bytes = base::Base64Decode(signature);
  if (!bytes)
    return false;
  if (key.IsEcP256()) {
    return crypto::sign::Verify(crypto::sign::ECDSA_SHA256, key,
                                base::as_byte_span(message), *bytes);
  }
  return key.IsMldsa65() &&
         crypto::sign::Verify(crypto::sign::MLDSA_65, key,
                              base::as_byte_span(message), *bytes);
}
} // namespace
base::FilePath StateHome() {
  auto selected = peer::ReadNativeSelectedStateHome();
  if (selected.route != peer::SelectedStateHomeRoute::unselected)
    return selected.route == peer::SelectedStateHomeRoute::current ? selected.path : base::FilePath();
  auto env = base::Environment::Create();
  if (auto value = env->GetVar("AUX_HOME"); value && !value->empty())
    return base::FilePath(*value);
  base::FilePath home;
  return base::PathService::Get(base::DIR_HOME, &home)
             ? home.AppendASCII(".aux")
             : base::FilePath();
}
std::optional<std::array<uint8_t, 32>> LoadAgentInboxV2MasterKey(const base::FilePath& home) {
  auto selected = peer::ReadNativeSelectedStateHome();
  if (selected.route != peer::SelectedStateHomeRoute::current || selected.path != home) return std::nullopt;
  return peer::GetNativeSelectedAgentInboxV2MasterKey();
}
std::optional<crypto::keypair::PrivateKey>
LoadInstallationPrivateKey(const base::FilePath & /*home*/) {
  // Legacy independent credential broker cannot export the supplied authority's
  // private key. Keep it fail-closed until the actual Vault proxy is
  // integrated.
  return std::nullopt;
}
std::optional<crypto::keypair::PublicKey>
ParseInstallationPublicKey(std::string_view json) {
  if (json.size() > kMaxCarrierOutput)
    return std::nullopt;
  auto input = base::JSONReader::ReadDict(json, base::JSON_PARSE_RFC);
  const auto *scheme = input ? input->FindString("scheme") : nullptr;
  const auto *sig = input ? input->FindString("sig") : nullptr;
  if (!scheme || !sig)
    return std::nullopt;
  auto bytes = base::Base64Decode(*sig);
  if (!bytes)
    return std::nullopt;
  if (*scheme == "p256_v1" && bytes->size() == 65 && (*bytes)[0] == 4)
    return crypto::keypair::PublicKey::FromEcP256Point(*bytes);
  if (*scheme == "pq_v1" && bytes->size() == 1952)
    return crypto::keypair::PublicKey::FromMldsa65PublicKey(*bytes);
  return std::nullopt;
}
std::optional<crypto::keypair::PublicKey>
LoadInstallationPublicKey(const base::FilePath &home) {
  if (peer::ReadNativeSelectedStateHome().route == peer::SelectedStateHomeRoute::unselected)
    return std::nullopt;
  auto json = peer::GetNativeSelectedInstallationPublicKeys();
  return json ? ParseInstallationPublicKey(*json) : std::nullopt;
}
peer::NativeDaemonSignatureReply ObserveNativeDaemonChallenge(std::string_view challenge, bool observe_only) {
  auto message = HttpMessage(challenge);
  if (!message) return {peer::DaemonAuthorityStatus::refused, std::nullopt};
  return peer::ObserveNativeSelectedDaemonChallenge(base::Base64Encode(*message), observe_only);
}
std::optional<std::string> SignDaemonChallenge(const base::FilePath &home,
                                               std::string_view challenge) {
  auto message = HttpMessage(challenge);
  if (!message)
    return std::nullopt;
  if (peer::ReadNativeSelectedStateHome().route == peer::SelectedStateHomeRoute::unselected)
    return std::nullopt;
  return peer::SignNativeSelectedDaemonChallenge(base::Base64Encode(*message));
}
bool VerifyInstallationChallenge(const crypto::keypair::PublicKey &key,
                                 std::string_view challenge,
                                 std::string_view signature) {
  auto message = HttpMessage(challenge);
  return message && VerifyMessage(key, *message, signature);
}
bool VerifyCdpChallenge(const crypto::keypair::PublicKey &key,
                        std::string_view challenge,
                        std::string_view signature) {
  auto bytes = DecodeChallenge(challenge);
  return bytes && VerifyMessage(key, *bytes, signature);
}
} // namespace aux
