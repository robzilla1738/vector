#pragma once
#include "AuxCliSealedImages.h"
#include "AuxCliWire.h"
#include <array>
#include <atomic>
#include <memory>
#include <string>
#include <vector>
namespace aux::cli {
// Native terminal frontend. Performs a credential-free audited Hello before
// sending argv/environment or any actual stdio/directory capabilities.
int ForwardTerminalInvocation(int argc,char* argv[]);
int ForwardTerminalReadOnlyQuery(int argc,char* argv[]);
// The same route for a caller that owns stdout and outlives the query, as aux
// mcp does: `arguments` is argv without the program name, the reply lands in
// `reply`, signal handlers stay as they are, and `cancelled` ends the wait
// without telling the browser. Safe to call from several threads at once.
int QueryBrowser(const std::vector<std::string>& arguments,std::string* reply,const std::atomic_bool& cancelled);
class Invocation final {
 public:
  ~Invocation();
  Invocation(const Invocation&)=delete;Invocation& operator=(const Invocation&)=delete;
  bool Current()const;
  bool IsReadOnlyQuery()const;
  const Arguments& arguments()const;
  int directory()const;
  int input()const;int output()const;int error()const;
  // Returns only an authenticated request signal, never child completion.
  int PollSignal(uint32_t timeout_ms);
 private:
  struct State;explicit Invocation(std::unique_ptr<State>);
  std::unique_ptr<State> state_;
  friend class Ingress;
  friend class BrowserInvocation;
  friend class ManualProfileApprovalRequest;
  friend class ApprovedCliInvocation;
  friend class NativeOpenService;
  friend class NativeOpenOperation;
  audit_token_t KernelPeerForNativeAdmission() const;
  bool CompleteAfterObservedExit(int exit_code);
  bool CompleteAfterNativeOpenResult(int exit_code);
  bool CompleteReadOnlyQuery(std::string_view json, int exit_code);
};
class Ingress final {
 public:
  static std::unique_ptr<Ingress> CreateForActualBrowser();
  ~Ingress();
  // Call on an owned native service thread. Result retains the peer, private
  // channel, cwd/stdin/out/err. It grants no installation/profile authority.
  std::unique_ptr<Invocation> ReceiveOne(uint32_t timeout_ms);
  void CloseAdmission();
  bool AdmissionClosed() const;
  static size_t UnresolvedSendRights();
 private:
  struct State;explicit Ingress(std::shared_ptr<State>);
  std::shared_ptr<State> state_;
};
}
