#import <AppKit/AppKit.h>
#include "AuxCliOpenCommand.h"
#include "AuxCliOpenArguments.h"
#include "chrome/browser/aux/ordinary_startup_build.h"
#include "chrome/browser/aux/routing/routing_service.h"
#include "base/json/json_writer.h"
#include "AuxCliManualProfileApproval.h"
#include "chrome/browser/aux/cli/AuxCliIngress.h"
#include "chrome/browser/aux/AuxSelectedStateHome.h"
#include "chrome/browser/aux/profile_identity.h"
#include "base/functional/bind.h"
#include "base/memory/weak_ptr.h"
#include "base/no_destructor.h"
#include "base/strings/string_util.h"
#include "base/strings/utf_string_conversions.h"
#include "base/task/single_thread_task_runner.h"
#include "base/threading/thread.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "chrome/browser/aux/browser_platform.h"
#include "chrome/browser/browser_process.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/profiles/profile_attributes_entry.h"
#include "chrome/browser/profiles/profile_attributes_storage.h"
#include "chrome/browser/profiles/profile_manager.h"
#include "chrome/browser/profiles/keep_alive/profile_keep_alive_types.h"
#include "chrome/browser/profiles/keep_alive/scoped_profile_keep_alive.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/browser_window/public/global_browser_collection.h"
#include "chrome/browser/ui/navigator/browser_navigator.h"
#include "chrome/browser/ui/navigator/browser_navigator_params.h"
#include "chrome/browser/ui/tabs/tab_strip_model.h"
#include "chrome/browser/ui/views/frame/aux_native_task_feed.h"
#include "components/sessions/core/session_id.h"
#include "content/public/browser/browser_thread.h"
#include "content/public/browser/navigation_handle.h"
#include "content/public/browser/web_contents.h"
#include "ui/base/base_window.h"
#include "ui/base/window_open_disposition.h"
#include "ui/base/page_transition_types.h"
#include "url/gurl.h"
#include "ui/gfx/native_ui_types.h"
#include <signal.h>
#include <unistd.h>
#include <algorithm>
#include <atomic>
#include <map>
#include <memory>
#include <set>
#include <utility>
namespace aux::cli {
class NativeOpenOperation;
namespace {
const pid_t kProcess = getpid();
constexpr size_t kPendingLimit = 64;
std::map<NativeOpenOperation*,std::shared_ptr<NativeOpenOperation>>& Pending(){
  static auto* pending = new std::map<NativeOpenOperation*,std::shared_ptr<NativeOpenOperation>>;
  return *pending;
}
bool admission_closed = true;  // Actual admission mutation stays on UI.
struct OpenCounters {
  std::atomic_bool started{false},closed{true},receiver_running{false};
  std::atomic_uint64_t queued{0},profile_operations{0};
};
OpenCounters& Counters(){static auto* counters=new OpenCounters;return *counters;}
bool ActualNativeReady(){
  const auto state=aux::peer::InspectNativeBrowserShutdown();
  return getpid()==kProcess && !state.wrong_process && !state.admission_closed &&
      !state.sequence_uncertain && state.admitted_generation &&
      aux::peer::ReadNativeSelectedStateHome().route==aux::peer::SelectedStateHomeRoute::current;
}
bool UsableWindow(BrowserWindowInterface* window){
  return window && window->GetType()==BrowserWindowInterface::TYPE_NORMAL &&
      window->GetProfile() && window->GetProfile()->IsRegularProfile() &&
      !window->GetProfile()->IsOffTheRecord() && window->GetWindow() &&
      window->GetWindow()->IsVisible();
}
base::WeakPtr<BrowserWindowInterface> SelectActualWindow(const std::string& selector){
  auto* collection=GlobalBrowserCollection::GetInstance();
  if(!collection || !g_browser_process || !g_browser_process->profile_manager())return{};
  if(selector.empty()){
    auto* active=collection->GetActiveBrowser();
    return UsableWindow(active)?active->GetWeakPtr():base::WeakPtr<BrowserWindowInterface>();
  }
  auto& attributes=g_browser_process->profile_manager()->GetProfileAttributesStorage();
  std::map<Profile*,base::WeakPtr<BrowserWindowInterface>> ids,names;
  // Creation order only chooses among windows of the SAME native Profile.
  // Multiple distinct matching Profiles always refuse, never first-match fallthrough.
  collection->ForEach([&](BrowserWindowInterface* window){
    if(!UsableWindow(window))return true;
    auto* profile=window->GetProfile();
    auto* entry=attributes.GetProfileAttributesWithPath(profile->GetPath());
    if(!entry)return true;
    if(aux::GetProfileId(profile)==selector)ids.try_emplace(profile,window->GetWeakPtr());
    if(base::UTF16ToUTF8(entry->GetName())==selector)names.try_emplace(profile,window->GetWeakPtr());
    return true;
  },BrowserCollection::Order::kCreation);
  if(!ids.empty())return ids.size()==1?ids.begin()->second:base::WeakPtr<BrowserWindowInterface>();
  return names.size()==1?names.begin()->second:base::WeakPtr<BrowserWindowInterface>();
}
}
class NativeOpenOperation final : public std::enable_shared_from_this<NativeOpenOperation> {
 public:
  static void Begin(std::unique_ptr<Invocation> invocation){
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    if(!invocation)return;
    const auto arguments=ParseNativeOpenArguments(invocation->arguments().argv);
    const GURL url(arguments.url);
    if(admission_closed || !ActualNativeReady() || Pending().size()>=kPendingLimit ||
       arguments.status!=OpenParseStatus::accepted || !arguments.space.empty() || !url.is_valid() ||
       !url.SchemeIsHTTPOrHTTPS() || url.has_username() || url.has_password()){
      invocation->CompleteAfterNativeOpenResult(64);return;
    }
    auto window=SelectActualWindow(arguments.profile);
    if(!window || !invocation->Current()){
      invocation->CompleteAfterNativeOpenResult(78);return;
    }
    auto operation=std::shared_ptr<NativeOpenOperation>(new NativeOpenOperation(std::move(invocation),window,url));
    if(!operation->TargetCurrent()){
      operation->invocation_->CompleteAfterNativeOpenResult(78);return;
    }
    // Register the exact native Profile BEFORE activation, permission callback,
    // or navigation. The three native switch/restore gates consult this record.
    Pending().emplace(operation.get(),operation);
    Counters().profile_operations.fetch_add(1);
    operation->focus_deadline_=base::TimeTicks::Now()+base::Seconds(3);
    window->GetWindow()->Activate();
    operation->focus_.Start(FROM_HERE,base::Milliseconds(50),
        base::BindRepeating([](std::weak_ptr<NativeOpenOperation> weak){
          if(auto operation=weak.lock())operation->FocusThenApprove();
        },std::weak_ptr<NativeOpenOperation>(operation)));
    operation->FocusThenApprove();
  }
  Profile* profile()const{return profile_.get();}
  void Cancel(int code=130){
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    if(phase_==Phase::finished)return;
    if(phase_==Phase::navigating){canceled_during_navigation_=true;return;}
    Finish(code);
  }
 private:
  enum class Phase{focusing,approving,navigating,finished};
  NativeOpenOperation(std::unique_ptr<Invocation> invocation,
      base::WeakPtr<BrowserWindowInterface> window,GURL url)
      :invocation_(std::move(invocation)),window_(window),profile_(window->GetProfile()->GetWeakPtr()),url_(std::move(url)),
       profile_id_(aux::GetProfileId(profile_.get())),
       binding_epoch_(aux::GetProfileCookieBindingEpoch(profile_.get())),
       restore_epoch_(aux::GetProfileCookieRestoreEpoch(profile_.get())),
       generation_(aux::peer::InspectNativeBrowserShutdown().admitted_generation){}
  bool TargetCurrent()const{
    return !admission_closed && ActualNativeReady() && window_ && profile_ &&
        window_->GetProfile()==profile_.get() && UsableWindow(window_.get()) &&
        !profile_id_.empty() && !binding_epoch_.empty() && !restore_epoch_.empty() &&
        aux::GetProfileId(profile_.get())==profile_id_ &&
        aux::GetProfileCookieBindingEpoch(profile_.get())==binding_epoch_ &&
        aux::GetProfileCookieRestoreEpoch(profile_.get())==restore_epoch_ &&
        !aux::IsProfileCookieRestorePending(profile_.get()) &&
        aux::peer::InspectNativeBrowserShutdown().admitted_generation==generation_;
  }
  void FocusThenApprove(){
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    auto keep=shared_from_this();
    if(phase_!=Phase::focusing)return;
    if(!TargetCurrent() || !invocation_ || !invocation_->Current() ||
       base::TimeTicks::Now()>=focus_deadline_){Finish(78);return;}
    const int signal=invocation_->PollSignal(0);
    if(signal==SIGINT || signal==SIGTERM || signal==SIGHUP){Finish(130);return;}
    auto* native=window_->GetWindow()->GetNativeWindow().GetNativeNSWindow();
    if(!native || ![native isKeyWindow] || !NSApp.active)return;
    focus_.Stop();phase_=Phase::approving;
    request_=ManualProfileApprovalRequest::BeginForActualWindow(*window_,std::move(invocation_),
        base::BindOnce([](std::weak_ptr<NativeOpenOperation> weak,std::unique_ptr<ApprovedCliInvocation> approval){
          if(auto operation=weak.lock())operation->Approved(std::move(approval));
        },std::weak_ptr<NativeOpenOperation>(keep)));
    if(!request_)Finish(78);
  }
  void Approved(std::unique_ptr<ApprovedCliInvocation> approval){
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    auto keep=shared_from_this();
    if(phase_!=Phase::approving)return;
    if(!approval || !TargetCurrent() || approval->RevalidatedNativeProfile()!=profile_.get()){
      Finish(78);return;
    }
    auto retained_profile=ScopedProfileKeepAlive::TryAcquire(profile_.get(),ProfileKeepAliveOrigin::kBrowserWindow);
    if(!retained_profile){Finish(78);return;}
    invocation_=approval->ConsumeForNativeOpen(profile_.get());
    if(!invocation_ || !invocation_->Current() || !TargetCurrent()){Finish(78);return;}
    // The 15-second OS approval is now consumed. It is never used as a timer
    // for active navigation ownership, cancellation or lifecycle settlement.
    approval.reset();request_.reset();phase_=Phase::navigating;
    NavigateParams params(window_.get(),url_,ui::PAGE_TRANSITION_TYPED);
    params.disposition=WindowOpenDisposition::NEW_FOREGROUND_TAB;
    params.should_trigger_session_restore=false;
    auto navigation=Navigate(&params);
    bool started=false;
    // Navigate has returned to the same UI sequence. A live handle plus actual
    // parented WebContents proves native start/handoff, not network/page success.
    if(navigation && TargetCurrent() && params.browser==window_.get()){
      auto* contents=navigation->GetWebContents();
      started=contents && contents==params.navigated_or_inserted_contents &&
          contents->GetBrowserContext()==profile_.get() &&
          window_->GetTabStripModel()->GetIndexOfWebContents(contents)!=TabStripModel::kNoTab;
    }
    const int result=started&&!canceled_during_navigation_?0:75;
    Finish(result);
  }
  void Finish(int code){
    auto keep=shared_from_this();
    if(phase_==Phase::finished)return;
    phase_=Phase::finished;focus_.Stop();
    if(request_)request_->Cancel();
    request_.reset();
    if(invocation_)invocation_->CompleteAfterNativeOpenResult(code);
    invocation_.reset();
    if(Pending().erase(this)==1)Counters().profile_operations.fetch_sub(1);
  }
  std::unique_ptr<Invocation> invocation_;
  base::WeakPtr<BrowserWindowInterface> window_;
  base::WeakPtr<Profile> profile_;
  const GURL url_;
  const std::string profile_id_,binding_epoch_,restore_epoch_;
  const uint64_t generation_;
  Phase phase_=Phase::focusing;
  bool canceled_during_navigation_=false;
  base::TimeTicks focus_deadline_;
  base::RepeatingTimer focus_;
  std::unique_ptr<ManualProfileApprovalRequest> request_;
};
class NativeOpenService final : public std::enable_shared_from_this<NativeOpenService> {
 public:
  NativeOpenService():receiver_("Aux native CLI open"){}
  bool Start(){
    ui_=base::SingleThreadTaskRunner::GetCurrentDefault();ingress_=Ingress::CreateForActualBrowser();
    if(!ingress_){closing_.store(true);return false;}
    if(!receiver_.Start()){ingress_->CloseAdmission();closing_.store(true);return false;}
    running_.store(true);Counters().receiver_running.store(true);auto self=shared_from_this();
    if(!receiver_.task_runner()->PostTask(FROM_HERE,base::BindOnce(&NativeOpenService::ReceiveNext,self))){
      closing_.store(true);ingress_->CloseAdmission();receiver_.Stop();running_.store(false);Counters().receiver_running.store(false);return false;
    }
    return true;
  }
  void Close(){
    if(closing_.exchange(true))return;
    ingress_->CloseAdmission();receiver_.Stop();running_.store(false);Counters().receiver_running.store(false);
  }
  // UI sequence. Answers every in-flight chats/status query with a refusal.
  static void CancelReadOnlyQueries();
 private:
  static void Refuse(Invocation* invocation,int code){
    if(invocation->IsReadOnlyQuery())invocation->CompleteReadOnlyQuery(R"({"ok":false,"error":"query-unavailable"})",code);
    else invocation->CompleteAfterNativeOpenResult(code);
  }
  // The owner a read-only query was admitted against: a visible normal window,
  // its Profile and cookie binding epoch, and the admitted native generation.
  // Every query rechecks it after reading, so a changed owner always refuses.
  struct QueryOwner{
    base::WeakPtr<BrowserWindowInterface> window;
    base::WeakPtr<Profile> profile;
    std::string epoch;
    uint64_t generation=0;
    static QueryOwner For(base::WeakPtr<BrowserWindowInterface> window){
      QueryOwner owner;owner.window=window;
      owner.profile=window?window->GetProfile()->GetWeakPtr():base::WeakPtr<Profile>();
      owner.epoch=owner.profile?aux::GetProfileCookieBindingEpoch(owner.profile.get()):std::string();
      owner.generation=aux::peer::InspectNativeBrowserShutdown().admitted_generation;
      return owner;
    }
    bool Current(const NativeOpenService& service,const Invocation& invocation)const{
      return !service.closing_.load()&&!admission_closed&&ActualNativeReady()&&invocation.Current()&&
          window&&profile&&UsableWindow(window.get())&&window->GetProfile()==profile.get()&&
          !epoch.empty()&&aux::GetProfileCookieBindingEpoch(profile.get())==epoch&&
          !aux::IsProfileCookieRestorePending(profile.get())&&
          aux::peer::InspectNativeBrowserShutdown().admitted_generation==generation;
    }
  };
  static void CompleteQuery(Invocation& invocation,const base::DictValue& result,int code){
    auto json=base::WriteJson(result);
    if(!json||json->size()>kPayloadLimit){json=R"({"ok":false,"error":"query-result-too-large"})";code=75;}
    invocation.CompleteReadOnlyQuery(*json,code);
  }
  // Rows stop well under the reply limit and say so, rather than fail the query.
  static constexpr size_t kRowBudget=kPayloadLimit-2048;
  static std::string Clip(std::string_view text,size_t bytes){
    return std::string(base::TruncateUTF8ToByteSize(text,bytes));
  }
  // Narrows routing state profiles to one exact ID, else one unique name.
  static bool SelectProfile(base::ListValue& profiles,const std::string& selector){
    if(selector.empty())return true;
    std::string selected;size_t matches=0;
    for(const auto& value:profiles){
      const auto* id=value.GetDict().FindString("id");
      if(id&&*id==selector){selected=*id;matches=1;break;}
    }
    if(selected.empty())for(const auto& value:profiles){
      const auto* id=value.GetDict().FindString("id");
      const auto* name=value.GetDict().FindString("name");
      if(id&&name&&*name==selector){selected=*id;++matches;}
    }
    if(matches!=1)return false;
    profiles.EraseIf([&](const base::Value& value){const auto* id=value.GetDict().FindString("id");return !id||*id!=selected;});
    return true;
  }
  static base::DictValue Failure(std::string_view error){return base::DictValue().Set("ok",false).Set("error",error);}
  // Loaded tabs of every visible normal window whose Profile is in `profiles`.
  static base::DictValue Tabs(const base::ListValue& profiles){
    std::set<std::string> ids;
    for(const auto& value:profiles)if(const auto* id=value.GetDict().FindString("id"))ids.insert(*id);
    base::ListValue tabs;size_t bytes=0;bool truncated=false;
    GlobalBrowserCollection::GetInstance()->ForEach([&](BrowserWindowInterface* window){
      if(!UsableWindow(window))return true;
      const auto profile=aux::GetProfileId(window->GetProfile());
      if(!ids.contains(profile))return true;
      auto* strip=window->GetTabStripModel();
      for(int i=0;strip&&i<strip->count();++i){
        auto* contents=strip->GetWebContentsAt(i);
        if(!contents)continue;
        auto row=base::DictValue().Set("profileId",profile).Set("windowId",window->GetSessionID().id())
            .Set("index",i).Set("active",i==strip->active_index()).Set("pinned",strip->IsTabPinned(i))
            .Set("title",Clip(base::UTF16ToUTF8(contents->GetTitle()),256))
            .Set("url",Clip(contents->GetVisibleURL().spec(),2048));
        const auto size=base::WriteJson(row).value_or(std::string()).size()+1;
        if(bytes+size>kRowBudget){truncated=true;return false;}
        bytes+=size;tabs.Append(std::move(row));
      }
      return true;
    },BrowserCollection::Order::kActivation);
    return base::DictValue().Set("ok",true).Set("tabs",std::move(tabs)).Set("truncated",truncated);
  }
  // One agent turn for aux ask or exec, on the same profile-bound feed and
  // browser-held daemon authorization as the queries around it. The prompt goes
  // in as the command bar's Ask does, so Aux's approval rules decide what runs.
  class AgentTurn final : public std::enable_shared_from_this<AgentTurn> {
   public:
    static void Begin(std::shared_ptr<NativeOpenService> service,std::unique_ptr<Invocation> invocation,
                      QueryOwner owner,AgentCommand command){
      auto keep_alive=ScopedProfileKeepAlive::TryAcquire(owner.profile.get(),ProfileKeepAliveOrigin::kBrowserWindow);
      if(!keep_alive){CompleteQuery(*invocation,Failure("routing-authority-unavailable"),78);return;}
      auto turn=std::shared_ptr<AgentTurn>(new AgentTurn(std::move(service),std::move(invocation),std::move(owner),std::move(command)));
      turn->keep_alive_=std::move(keep_alive);
      Turns().emplace(turn.get(),turn);
      std::weak_ptr<AgentTurn> weak=turn;
      turn->deadline_.Start(FROM_HERE,base::Minutes(30),base::BindOnce([](std::weak_ptr<AgentTurn> weak){
        if(auto turn=weak.lock())turn->Finish(Failure("turn-timed-out"),75);
      },weak));
      turn->feed_=std::make_unique<AuxNativeTaskFeed>(turn->owner_.profile.get(),base::BindRepeating(
          [](std::weak_ptr<AgentTurn> weak,const AuxNativeTaskFeed::Snapshot& snapshot){
            if(auto turn=weak.lock())turn->Received(snapshot);
          },weak));
      turn->feed_->Refresh();
    }
    static void CancelAll(){
      auto actual=Turns();
      for(auto& [identity,turn]:actual)turn->Finish(Failure("query-unavailable"),78);
    }
    static bool AnyAwaitingApproval(){
      return std::ranges::any_of(Turns(),[](const auto& entry){return entry.second->awaiting_approval_;});
    }
   private:
    using Step=void(AgentTurn::*)(const base::Value&);
    AgentTurn(std::shared_ptr<NativeOpenService> service,std::unique_ptr<Invocation> invocation,
              QueryOwner owner,AgentCommand command)
        :service_(std::move(service)),invocation_(std::move(invocation)),owner_(std::move(owner)),command_(std::move(command)){}
    static std::map<AgentTurn*,std::shared_ptr<AgentTurn>>& Turns(){
      static auto* turns=new std::map<AgentTurn*,std::shared_ptr<AgentTurn>>;
      return *turns;
    }
    base::DictValue Session()const{return base::DictValue().Set("sessionId",session_);}
    void Call(const char* method,bool mutation,base::DictValue input,Step step){
      feed_->Rpc(method,mutation,std::move(input),base::BindOnce(
          [](std::weak_ptr<AgentTurn> weak,Step step,std::string method,std::optional<base::Value> value){
            auto turn=weak.lock();
            if(!turn)return;
            if(!value){turn->Finish(Failure("agent-request-failed").Set("detail",method),75);return;}
            ((*turn).*step)(*value);
          },weak_from_this(),step,std::string(method)));
    }
    void Received(const AuxNativeTaskFeed::Snapshot& snapshot){
      using State=AuxNativeTaskFeed::State;
      if(started_||snapshot.state==State::kConnecting)return;
      if(snapshot.state!=State::kReady){
        Finish(Failure("agent-locked-or-unbound").Set("detail",base::UTF16ToUTF8(snapshot.error)),69);return;
      }
      started_=true;
      if(command_.exec)Create(&AgentTurn::OnCreated);
      else Call("settings.agentGet",false,base::DictValue(),&AgentTurn::OnAgent);
    }
    void OnAgent(const base::Value& agent){
      const auto* home=agent.is_dict()?agent.GetDict().FindString("homeSessionId"):nullptr;
      if(!home){Create(&AgentTurn::OnCreatedHome);return;}
      session_=*home;
      ReadBaseline(agent);
    }
    // A chat for the CLI, bound to a browser the way the daemon binds CLI chats.
    // exec's is ephemeral; the first ask's becomes the home thread.
    void Create(Step step){
      auto input=base::DictValue().Set("trigger",base::DictValue().Set("type","user").Set("source","cli"));
      if(command_.exec){input.Set("title","Aux CLI");input.Set("ephemeral",true);}
      Call("sessions.create",true,std::move(input),step);
    }
    bool TakeSession(const base::Value& session){
      const auto* id=session.is_dict()?session.GetDict().FindString("id"):nullptr;
      if(!id){Finish(Failure("agent-request-failed"),75);return false;}
      session_=*id;
      return true;
    }
    void OnCreated(const base::Value& session){if(TakeSession(session))ReadBaseline(session);}
    void OnCreatedHome(const base::Value& session){
      if(TakeSession(session))Call("settings.agentSetHome",true,Session(),&AgentTurn::ReadBaseline);
    }
    // Whatever turn is newest now isn't this one, even if it's still running.
    void ReadBaseline(const base::Value&){
      Call("sessions.turns.list",false,Session().Set("limit",1),&AgentTurn::OnBaseline);
    }
    static const base::DictValue* LatestTurn(const base::Value& overview){
      const auto* turns=overview.is_dict()?overview.GetDict().FindList("turns"):nullptr;
      return turns&&!turns->empty()?turns->back().GetIfDict():nullptr;
    }
    void OnBaseline(const base::Value& overview){
      const auto* latest=LatestTurn(overview);
      const auto* id=latest?latest->FindString("id"):nullptr;
      if(id)baseline_=*id;
      Call("sessions.queue",true,Session().Set("prompt",command_.prompt),&AgentTurn::OnPrompted);
    }
    void OnPrompted(const base::Value&){Poll();}
    void Wait(){poll_.Start(FROM_HERE,base::Seconds(1),base::BindOnce(&AgentTurn::Poll,shared_from_this()));}
    void Poll(){
      if(owner_.Current(*service_,*invocation_)){
        Call("sessions.turns.list",false,Session().Set("limit",1),&AgentTurn::OnTurns);
      }else if(command_.exec){
        Call("sessions.abort",true,Session(),&AgentTurn::OnAborted);
      }else Finish(Failure("query-owner-changed"),78);
    }
    void OnAborted(const base::Value&){Finish(Failure("query-owner-changed"),78);}
    void OnTurns(const base::Value& overview){
      const auto* latest=LatestTurn(overview);
      const auto* id=latest?latest->FindString("id"):nullptr;
      const auto* status=latest?latest->FindString("status"):nullptr;
      if(!id||!status||*id==baseline_){Wait();return;}
      awaiting_approval_=*status=="waiting"&&!command_.exec;
      if(*status=="completed")Reply(*latest);
      else if(*status=="interrupted"){
        const auto* error=latest->FindString("error");
        Finish(Failure("turn-interrupted").Set("detail",error?*error:std::string()),75);
      }else if(*status=="waiting"&&command_.exec)Call("sessions.get",false,Session(),&AgentTurn::OnWaiting);
      else Wait();
    }
    // The name --allow uses: a tool's own name, else what kind of access it is.
    static std::string ApprovalName(const base::DictValue* scope){
      const auto* type=scope?scope->FindString("type"):nullptr;
      if(!type)return std::string();
      const char* detail=*type=="tool"?"tool":*type=="file"?"mode":*type=="browser"?"action":nullptr;
      const auto* value=detail?scope->FindString(detail):nullptr;
      return !value?*type:*type=="tool"?*value:*type+":"+*value;
    }
    void OnWaiting(const base::Value& session){
      const auto* suspension=session.is_dict()?session.GetDict().FindDict("suspension"):nullptr;
      const auto* tool_call=suspension?suspension->FindString("toolCallId"):nullptr;
      const auto* kind=suspension?suspension->FindString("kind"):nullptr;
      if(!tool_call||!kind||answered_.contains(*tool_call)){Wait();return;}
      answered_.insert(*tool_call);
      if(*kind!="approval"){
        refused_.Append(*kind);
        auto input=Session().Set("toolCallId",*tool_call).Set("error","aux exec has no one to answer this.");
        if(const auto* id=suspension->FindString("suspensionId"))input.Set("suspensionId",*id);
        Call("sessions.rejectSuspension",true,std::move(input),&AgentTurn::OnPrompted);
        return;
      }
      const auto* request=suspension->FindDict("request");
      const auto name=ApprovalName(request?request->FindDict("scope"):nullptr);
      const bool allowed=!name.empty()&&std::ranges::contains(command_.allowed,name);
      feed_->ResolveApproval(session_,*tool_call,allowed,
          base::BindOnce([](std::weak_ptr<AgentTurn> weak,std::string name,std::optional<std::u16string> error,bool granted){
            auto turn=weak.lock();
            if(!turn)return;
            if(error){turn->Finish(Failure("agent-request-failed").Set("detail",base::UTF16ToUTF8(*error)),75);return;}
            (granted?turn->approved_:turn->refused_).Append(std::move(name));
            turn->Poll();
          },weak_from_this(),name));
    }
    void Reply(const base::DictValue& latest){
      const auto* messages=latest.FindList("finalMessage");
      const auto* message=messages&&!messages->empty()?messages->back().GetIfDict():nullptr;
      const auto* content=message?message->FindList("content"):nullptr;
      std::string text;
      if(content)for(const auto& part:*content){
        const auto* row=part.GetIfDict();
        const auto* type=row?row->FindString("type"):nullptr;
        const auto* value=row?row->FindString("text"):nullptr;
        if(type&&*type=="text"&&value)text+=*value;
      }
      const bool truncated=text.size()>kRowBudget;
      text=Clip(text,kRowBudget);
      if(command_.exec){
        Finish(base::DictValue().Set("ok",true).Set("sessionId",session_).Set("reply",text).Set("truncated",truncated)
            .Set("approved",std::move(approved_)).Set("refused",refused_.Clone()),refused_.empty()?0:77);
        return;
      }
      if(truncated)text+="\n[Cut short; the rest is in the chat in Aux.]";
      Finish(base::DictValue(),0,text.empty()?"(The agent sent no text.)":text);
    }
    // `text` is what aux ask prints; everything else is JSON.
    void Finish(base::DictValue result,int code,std::string text=std::string()){
      auto keep=shared_from_this();
      if(done_)return;
      done_=true;deadline_.Stop();poll_.Stop();
      if(!owner_.Current(*service_,*invocation_))CompleteQuery(*invocation_,Failure("query-owner-changed"),78);
      else if(!text.empty())invocation_->CompleteReadOnlyQuery(text,code);
      else CompleteQuery(*invocation_,result,code);
      base::SingleThreadTaskRunner::GetCurrentDefault()->PostTask(FROM_HERE,base::BindOnce(
          [](std::unique_ptr<AuxNativeTaskFeed> feed,std::unique_ptr<ScopedProfileKeepAlive>){feed.reset();},
          std::move(feed_),std::move(keep_alive_)));
      Turns().erase(this);
    }
    bool awaiting_approval_=false;
    const std::shared_ptr<NativeOpenService> service_;
    const std::unique_ptr<Invocation> invocation_;
    const QueryOwner owner_;
    const AgentCommand command_;
    std::string session_,baseline_;
    std::set<std::string> answered_;
    base::ListValue approved_,refused_;
    std::unique_ptr<ScopedProfileKeepAlive> keep_alive_;
    std::unique_ptr<AuxNativeTaskFeed> feed_;
    base::OneShotTimer deadline_,poll_;
    bool started_=false,done_=false;
  };
  // One-shot account-scoped chat read through the same profile-bound feed as
  // the sidebar: Vault/binding checks before and after, browser-held daemon
  // authorization, never another profile's account. It reads; it never acts.
  class FeedQuery final : public std::enable_shared_from_this<FeedQuery> {
   public:
    static void Begin(std::shared_ptr<NativeOpenService> service,std::unique_ptr<Invocation> invocation,
                      QueryOwner owner,ReadOnlyQueryKind kind,base::DictValue status){
      auto keep_alive=ScopedProfileKeepAlive::TryAcquire(owner.profile.get(),ProfileKeepAliveOrigin::kBrowserWindow);
      if(!keep_alive){CompleteQuery(*invocation,Failure("routing-authority-unavailable"),78);return;}
      auto query=std::shared_ptr<FeedQuery>(new FeedQuery(std::move(service),std::move(invocation),std::move(owner),kind,std::move(status)));
      query->keep_alive_=std::move(keep_alive);
      Queries().emplace(query.get(),query);
      std::weak_ptr<FeedQuery> weak=query;
      query->deadline_.Start(FROM_HERE,base::Seconds(15),base::BindOnce([](std::weak_ptr<FeedQuery> weak){
        if(auto query=weak.lock())query->Finish(Failure("query-timed-out"),75);
      },weak));
      query->feed_=std::make_unique<AuxNativeTaskFeed>(query->owner_.profile.get(),base::BindRepeating(
          [](std::weak_ptr<FeedQuery> weak,const AuxNativeTaskFeed::Snapshot& snapshot){
            if(auto query=weak.lock())query->Received(snapshot);
          },weak));
      query->feed_->Refresh();
    }
    static void CancelAll(){
      auto actual=Queries();
      for(auto& [identity,query]:actual)query->Finish(Failure("query-unavailable"),78);
    }
   private:
    FeedQuery(std::shared_ptr<NativeOpenService> service,std::unique_ptr<Invocation> invocation,
              QueryOwner owner,ReadOnlyQueryKind kind,base::DictValue status)
        :service_(std::move(service)),invocation_(std::move(invocation)),owner_(std::move(owner)),kind_(kind),status_(std::move(status)){}
    static std::map<FeedQuery*,std::shared_ptr<FeedQuery>>& Queries(){
      static auto* queries=new std::map<FeedQuery*,std::shared_ptr<FeedQuery>>;
      return *queries;
    }
    void Received(const AuxNativeTaskFeed::Snapshot& snapshot){
      using State=AuxNativeTaskFeed::State;
      if(snapshot.state==State::kConnecting)return;
      const bool ready=snapshot.state==State::kReady;
      const auto detail=base::UTF16ToUTF8(snapshot.error);
      if(kind_==ReadOnlyQueryKind::mcp){
        if(!ready){Finish(Failure("agent-locked-or-unbound").Set("detail",detail),69);return;}
        if(mcp_requested_)return;
        mcp_requested_=true;
        std::weak_ptr<FeedQuery> weak=weak_from_this();
        feed_->Rpc("settings.get",false,base::DictValue().Set("key","mcp"),base::BindOnce(
            [](std::weak_ptr<FeedQuery> weak,std::optional<base::Value> value){
              if(auto query=weak.lock())query->Servers(value);
            },weak));
        return;
      }
      if(kind_==ReadOnlyQueryKind::chats){
        if(!ready){Finish(Failure(snapshot.state==State::kError?"chats-unavailable":"agent-locked-or-unbound").Set("detail",detail),69);return;}
        base::ListValue chats;size_t bytes=0;bool truncated=false;
        for(const auto& task:snapshot.tasks){
          auto row=base::DictValue().Set("id",task.id).Set("title",Clip(base::UTF16ToUTF8(task.title),256))
              .Set("status",task.status).Set("unread",task.unread).Set("pinned",task.pinned)
              .Set("needsYou",task.pending_action?base::Value(task.pending_action->kind):base::Value());
          const auto size=base::WriteJson(row).value_or(std::string()).size()+1;
          if(bytes+size>kRowBudget){truncated=true;break;}
          bytes+=size;chats.Append(std::move(row));
        }
        Finish(base::DictValue().Set("ok",true).Set("profileId",aux::GetProfileId(owner_.profile.get()))
            .Set("chats",std::move(chats)).Set("truncated",truncated),0);
        return;
      }
      size_t working=0,waiting=0,unread=0;
      for(const auto& task:snapshot.tasks){
        working+=task.status=="running";
        waiting+=task.pending_action.has_value()||task.status=="suspended";
        unread+=task.unread;
      }
      auto agent=base::DictValue().Set("state",ready?"ready":snapshot.state==State::kError?"error":"locked-or-unbound");
      if(ready){
        agent.Set("chats",static_cast<int>(snapshot.tasks.size()));agent.Set("working",static_cast<int>(working));
        agent.Set("waiting",static_cast<int>(waiting));agent.Set("unread",static_cast<int>(unread));
      }else agent.Set("detail",detail);
      agent.Set("cliTurnAwaitingApproval",AgentTurn::AnyAwaitingApproval());
      status_.Set("agent",std::move(agent));
      Finish(std::move(status_),0);
    }
    // Names and shape only: a server's command, env, URL and auth stay in Aux.
    void Servers(const std::optional<base::Value>& value){
      const auto* mcp=value?value->GetIfDict():nullptr;
      const auto* servers=mcp?mcp->FindDict("servers"):nullptr;
      if(!servers){Finish(Failure("mcp-unavailable"),69);return;}
      const auto* inventories=mcp->FindDict("inventories");
      base::ListValue rows;
      for(const auto [name,server]:*servers){
        if(!server.is_dict())continue;
        const auto* transport=server.GetDict().FindString("transport");
        auto row=base::DictValue().Set("name",name).Set("enabled",server.GetDict().FindBool("enabled").value_or(true))
            .Set("transport",transport?*transport:std::string());
        const auto* inventory=inventories?inventories->FindDict(name):nullptr;
        if(const auto* tools=inventory?inventory->FindList("tools"):nullptr)row.Set("tools",static_cast<int>(tools->size()));
        rows.Append(std::move(row));
      }
      Finish(base::DictValue().Set("ok",true).Set("profileId",aux::GetProfileId(owner_.profile.get())).Set("servers",std::move(rows)),0);
    }
    void Finish(base::DictValue result,int code){
      auto keep=shared_from_this();
      if(done_)return;
      done_=true;deadline_.Stop();
      if(!owner_.Current(*service_,*invocation_)){result=Failure("query-owner-changed");code=78;}
      CompleteQuery(*invocation_,result,code);
      // The feed may be running this call: release it once it returns, and keep
      // its Profile alive until then.
      base::SingleThreadTaskRunner::GetCurrentDefault()->PostTask(FROM_HERE,base::BindOnce(
          [](std::unique_ptr<AuxNativeTaskFeed> feed,std::unique_ptr<ScopedProfileKeepAlive>){feed.reset();},
          std::move(feed_),std::move(keep_alive_)));
      Queries().erase(this);
    }
    const std::shared_ptr<NativeOpenService> service_;
    const std::unique_ptr<Invocation> invocation_;
    const QueryOwner owner_;
    const ReadOnlyQueryKind kind_;
    base::DictValue status_;
    std::unique_ptr<ScopedProfileKeepAlive> keep_alive_;
    std::unique_ptr<AuxNativeTaskFeed> feed_;
    base::OneShotTimer deadline_;
    bool done_=false,mcp_requested_=false;
  };
  void ReadOnlyQuery(std::unique_ptr<Invocation> invocation){
    DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
    const auto parsed=ParseNativeReadOnlyQuery(invocation->arguments().argv);
    auto agent=ParseNativeAgentCommand(invocation->arguments().argv);
    // A terminal query does not activate Aux. Retain a visible normal window
    // in activation order; GetActiveBrowser() is null while Terminal is active.
    base::WeakPtr<BrowserWindowInterface> window;
    if(auto* collection=GlobalBrowserCollection::GetInstance()){
      collection->ForEach([&](BrowserWindowInterface* candidate){
        if(!UsableWindow(candidate))return true;
        window=candidate->GetWeakPtr();return false;
      },BrowserCollection::Order::kActivation);
    }
    const auto owner=QueryOwner::For(window);
    if((!parsed&&!agent)||!owner.Current(*this,*invocation)){
      CompleteQuery(*invocation,Failure(parsed||agent?"routing-authority-unavailable":"invalid-query"),parsed||agent?78:64);return;
    }
    if(agent){
      const auto target=agent->profile.empty()?owner:QueryOwner::For(SelectActualWindow(agent->profile));
      if(!target.Current(*this,*invocation)){CompleteQuery(*invocation,Failure("profile-missing-or-ambiguous"),69);return;}
      AgentTurn::Begin(shared_from_this(),std::move(invocation),target,std::move(*agent));return;
    }
    const auto& destination=parsed->destination;
    auto* profile=owner.profile.get();
    base::DictValue result;
    int code=0;
    switch(parsed->kind){
      case ReadOnlyQueryKind::resolve:
        result=aux::routing::Resolve(profile,{.url=GURL(destination.url),.profile=destination.profile,.space=destination.space,.authority=aux::routing::Authority::kExternal});
        if(!result.FindBool("ok").value_or(false))code=69;
        break;
      case ReadOnlyQueryKind::chats:
      case ReadOnlyQueryKind::mcp:
      case ReadOnlyQueryKind::status:{
        // The agent's chats belong to one Profile's account: the named one, else
        // the window this query was admitted against.
        const auto target=destination.profile.empty()?owner:QueryOwner::For(SelectActualWindow(destination.profile));
        if(!target.Current(*this,*invocation)){result=Failure("profile-missing-or-ambiguous");code=69;break;}
        if(parsed->kind!=ReadOnlyQueryKind::status){
          FeedQuery::Begin(shared_from_this(),std::move(invocation),target,parsed->kind,base::DictValue());return;
        }
        size_t windows=0,tabs=0;
        GlobalBrowserCollection::GetInstance()->ForEach([&](BrowserWindowInterface* candidate){
          if(!UsableWindow(candidate))return true;
          ++windows;if(auto* strip=candidate->GetTabStripModel())tabs+=static_cast<size_t>(strip->count());
          return true;
        },BrowserCollection::Order::kActivation);
        auto status=base::DictValue().Set("ok",true)
            .Set("daemon",base::DictValue().Set("authorized",!aux::BrowserPlatform::Get().authorization().empty()))
            .Set("profileId",aux::GetProfileId(target.profile.get()))
            .Set("windows",static_cast<int>(windows)).Set("tabs",static_cast<int>(tabs));
        FeedQuery::Begin(shared_from_this(),std::move(invocation),target,parsed->kind,std::move(status));return;
      }
      case ReadOnlyQueryKind::list:
      case ReadOnlyQueryKind::spaces:
      case ReadOnlyQueryKind::tabs:{
        auto state=aux::routing::GetState(profile);
        auto* profiles=state.FindList("profiles");
        if(!state.FindBool("ok").value_or(false)||!profiles){result=std::move(state);code=69;break;}
        if(!SelectProfile(*profiles,destination.profile)){result=Failure("profile-missing-or-ambiguous");code=69;break;}
        if(parsed->kind==ReadOnlyQueryKind::list){
          result=base::DictValue().Set("ok",true).Set("profiles",std::move(*profiles)).Set("spacesAreLoadedOnly",true);
        }else if(parsed->kind==ReadOnlyQueryKind::tabs){
          result=Tabs(*profiles);
        }else{
          base::ListValue spaces;
          for(const auto& value:*profiles){
            const auto* id=value.GetDict().FindString("id");
            const auto* rows=value.GetDict().FindList("spaces");
            if(!id||!rows)continue;
            for(const auto& space:*rows)spaces.Append(space.GetDict().Clone().Set("profileId",*id));
          }
          result=base::DictValue().Set("ok",true).Set("spaces",std::move(spaces)).Set("spacesAreLoadedOnly",true);
        }
        break;
      }
    }
    if(!owner.Current(*this,*invocation)){result=Failure("query-owner-changed");code=78;}
    CompleteQuery(*invocation,result,code);
  }
  void ReceiveNext(){
    if(closing_.load())return;
    auto invocation=ingress_->ReceiveOne(250);
    if(invocation){
      if(closing_.load() || queued_.load()>=kPendingLimit)Refuse(invocation.get(),78);
      else{
        queued_.fetch_add(1);Counters().queued.fetch_add(1);auto self=shared_from_this();
        // A shared native receiver state survives a shutdown until every
        // actually posted UI request reports no-start or hands off natively.
        auto delivery=std::make_shared<std::unique_ptr<Invocation>>(std::move(invocation));
        if(!ui_->PostTask(FROM_HERE,base::BindOnce([](std::shared_ptr<NativeOpenService> service,
            std::shared_ptr<std::unique_ptr<Invocation>> actual){
          service->queued_.fetch_sub(1);Counters().queued.fetch_sub(1);
          if(service->closing_.load()){
            if(*actual)Refuse(actual->get(),78);
          }else if(*actual&&(*actual)->IsReadOnlyQuery())service->ReadOnlyQuery(std::move(*actual));
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP) && AUX_BROWSER_ONLY_NATIVE_STARTUP
          else if(*actual)(*actual)->CompleteAfterNativeOpenResult(64);
#else
          else NativeOpenOperation::Begin(std::move(*actual));
#endif
        },self,delivery))){
          queued_.fetch_sub(1);Counters().queued.fetch_sub(1);if(*delivery)Refuse(delivery->get(),78);
        }
      }
    }
    if(!closing_.load())receiver_.task_runner()->PostTask(FROM_HERE,
        base::BindOnce(&NativeOpenService::ReceiveNext,shared_from_this()));
  }
  std::unique_ptr<Ingress> ingress_;
  base::Thread receiver_;
  scoped_refptr<base::SingleThreadTaskRunner> ui_;
  std::atomic_bool closing_{false},running_{false};
  std::atomic_uint64_t queued_{0};
};
void NativeOpenService::CancelReadOnlyQueries(){FeedQuery::CancelAll();AgentTurn::CancelAll();}
namespace {
std::shared_ptr<NativeOpenService>& RetainedService(){
  // Actual Close/join and retained counters remain explicit. Static teardown
  // must not destroy a service/thread or manufacture a settled observation.
  static base::NoDestructor<std::shared_ptr<NativeOpenService>> service;
  return *service;
}
bool start_attempted=false;
}
bool StartNativeOpenServiceAtActualBrowserStartup(){
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  if(getpid()!=kProcess || start_attempted)return false;
  if(!ActualNativeReady()){
    const auto state=aux::peer::InspectNativeBrowserShutdown();
    LOG(ERROR)<<"Aux CLI service not started: generation "<<state.admitted_generation
              <<", route "<<static_cast<int>(aux::peer::ReadNativeSelectedStateHome().route);
    return false;
  }
  auto& service=RetainedService();
  start_attempted=true;Counters().started.store(true);service=std::make_shared<NativeOpenService>();
  if(!service->Start()){LOG(ERROR)<<"Aux CLI service failed to register";return false;}
  admission_closed=false;Counters().closed.store(false);return true;
}
void CloseNativeOpenServiceAdmission(){
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  if(getpid()!=kProcess)return;
  auto& service=RetainedService();
  admission_closed=true;Counters().closed.store(true);if(service)service->Close();
  NativeOpenService::CancelReadOnlyQueries();
  // Cancellation can reenter this map through the actual OS reply callback.
  auto actual=Pending();for(auto& [identity,operation]:actual)operation->Cancel(78);
}
NativeOpenObservation InspectNativeOpenService(){
  if(getpid()!=kProcess){NativeOpenObservation invalid;invalid.wrong_process=true;return invalid;}
  auto& actual=Counters();
  return{actual.started.load(),actual.closed.load(),actual.receiver_running.load(),false,
         actual.queued.load(),actual.profile_operations.load()};
}
bool IsNativeCliOpenPendingForProfile(Profile* profile){
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  if(getpid()!=kProcess || !profile)return true;
  for(const auto& [identity,operation]:Pending())if(operation->profile()==profile)return true;
  return false;
}
}
