// Proposed native terminal frontend. This does not admit the existing SEA.
#include "AuxCliIngress.h"
#include "AuxCliOpenArguments.h"
#include <vector>
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
#import <AppKit/AppKit.h>
#include <atomic>
#include <memory>
#endif
#include "AuxNativeEndpointDelivery.h"
#include "packaged-identity-admission.h"
#include <mach-o/dyld.h>
#include <mach/mach.h>
#include <climits>
#include <cstdio>
#include <iostream>
#include <string_view>
#include <cstring>
#include <cstdlib>
#include <string>
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
namespace {
int DispatchOrdinaryOpen(const std::string& root, const aux::cli::OpenArguments& parsed) {
  const auto envelope = aux::cli::EncodeNativeOpenEnvelope(parsed);
  constexpr std::string_view suffix = "/Contents/Resources/aux";
  if (!envelope || !root.ends_with(suffix) || root.size() <= suffix.size()) {
    std::cerr << "Aux open needs one http(s) URL.\n";
    return 64;
  }
  const std::string app = root.substr(0, root.size() - suffix.size());
  NSString* app_path = [[NSString alloc] initWithBytes:app.data() length:app.size()
                                           encoding:NSUTF8StringEncoding];
  NSString* request = [[NSString alloc] initWithBytes:envelope->data() length:envelope->size()
                                           encoding:NSUTF8StringEncoding];
  NSURL* app_url = app_path ? [NSURL fileURLWithPath:app_path isDirectory:YES] : nil;
  NSURL* url = request ? [NSURL URLWithString:request] : nil;
  if (!app_url || !url) return 64;
  auto status = std::make_shared<std::atomic_int>(-1);
  NSWorkspaceOpenConfiguration* config = [NSWorkspaceOpenConfiguration configuration];
  config.activates = YES;
  config.createsNewApplicationInstance = NO;
  [[NSWorkspace sharedWorkspace] openURLs:@[url] withApplicationAtURL:app_url
      configuration:config completionHandler:^(NSRunningApplication* application, NSError* error) {
        status->store(application && !error ? 0 : 69);
      }];
  NSDate* deadline = [NSDate dateWithTimeIntervalSinceNow:10];
  while (status->load() < 0 && deadline.timeIntervalSinceNow > 0) {
    [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode
                           beforeDate:[NSDate dateWithTimeIntervalSinceNow:0.05]];
  }
  const int code = status->load();
  if (code == 0) {
    std::cout << "Sent to Aux.\n";
    return 0;
  }
  std::cerr << (code < 0 ? "Aux didn't confirm in time; the link may still open.\n"
                        : "Couldn't reach Aux.\n");
  return code < 0 ? 75 : code;
}
}  // namespace
#endif
int main(int argc,char* argv[]){
 @autoreleasepool {
 char executable[PATH_MAX];uint32_t length=sizeof(executable);if(_NSGetExecutablePath(executable,&length))return 78;
 char resolved[PATH_MAX];if(!realpath(executable,resolved))return 78;
 const std::string self(resolved),suffix="/apps/cli/Aux CLI.app/Contents/MacOS/aux-cli";
 if(!self.ends_with(suffix)||self.size()<=suffix.size())return 78;
 const auto root=self.substr(0,self.size()-suffix.size());
 const auto endpoint=AuxTakeNativeParentEndpointForBootstrap();
 if(endpoint!=MACH_PORT_NULL){
  mach_port_deallocate(mach_task_self(),endpoint);
  // A browser-owned Node/installation role remains unsupported regardless of
  // immutable marker contents. No marker creates an installation owner.
  if(!aux::packaged_identity::MarkerAllowedAt(root+"/bundle.json")){
   std::cerr << std::string_view("Aux packaged state identity is unsupported or unaccepted\n");return 78;
  }
  // Explicit until the real typed proxy owner, role image graph and sealed
  // Node entry are joined. Never recursively forward a browser-owned child.
  std::cerr << std::string_view("Aux CLI retained runtime join is not paired\n");return 78;
 }
 std::vector<std::string> arguments;
 if(!aux::cli::CopyNativeMainArguments(argc,argv,&arguments))return 64;
 if(arguments.empty()||arguments.front()=="--help"||arguments.front()=="-h"||arguments.front()=="help"){
  std::cout << "Usage: aux <command> [options]\n\n"
               "  open <https://URL> [--space <ID or name>] [--profile <ID or name>]\n"
               "                       Open a link in Aux.\n"
               "  list [--profile <ID or name>]      Profiles and their Spaces.\n"
               "  spaces [--profile <ID or name>]    Spaces, one row each.\n"
               "  tabs [--profile <ID or name>]      Open tabs.\n"
               "  chats [--profile <ID or name>]     Recent agent chats.\n"
               "  status                             Aux, daemon and agent state.\n"
               "  resolve <https://URL> [--profile <ID or name> [--space <ID or name>]]\n"
               "                       Where Aux would open a link, without opening it.\n\n"
               "Every command but open prints JSON. Aux must be running.\n";
  return 0;
 }
 // Read-only queries go to the running browser over the authenticated native
 // channel. They carry argv only: no environment, stdio or directory.
 const auto& command=arguments.front();
 if(command=="list"||command=="resolve"||command=="spaces"||command=="tabs"||command=="chats"||command=="status"){
  if(arguments.size()==2&&(arguments[1]=="--help"||arguments[1]=="-h")){
   if(command=="resolve")std::cout << "Usage: aux resolve <https://URL> [--profile <ID or unique name> [--space <ID or unique name>]]\n";
   else if(command=="status")std::cout << "Usage: aux status\n";
   else std::cout << "Usage: aux " << command << " [--profile <ID or unique name>]\n";
   return 0;
  }
  if(!aux::cli::ParseNativeReadOnlyQuery(arguments)){
   std::cerr << "Invalid aux " << command << " arguments; run aux " << command << " --help.\n";return 64;
  }
  const int status=aux::cli::ForwardTerminalReadOnlyQuery(argc,argv);
  // 69 without JSON means no running Aux answered this CLI's locator.
  if(status)std::cerr << "aux " << command << " failed (exit " << status << "). If no JSON was printed, open Aux and try again.\n";
  return status;
 }
 const auto parsed=aux::cli::ParseNativeOpenArguments(arguments);
 if(parsed.status==aux::cli::OpenParseStatus::help){
  std::cout << std::string_view("Usage: aux open <https://URL> [--space <Space ID or unique name>] [--profile <native profile ID or unique name>]\n");return 0;
 }
 if(parsed.status!=aux::cli::OpenParseStatus::accepted){
  // Only open and the read-only queries exist; nothing else reads a home or starts Node.
  std::cerr << std::string_view(arguments.front()=="open"
      ? "Aux open needs one http(s) URL.\n"
      : "Unknown command. Run aux --help.\n");
  return 64;
 }
 // Native open is admitted only by the exact browser peer, its genuine native
 // startup/Profile binding and actual one-shot OS approval. Markers grant none.
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
 // An OS URL receipt is ordinary external navigation only. It does not grant
 // task execution, installation ownership or privileged CLI peer admission.
 return DispatchOrdinaryOpen(root,parsed);
#else
 return aux::cli::ForwardTerminalInvocation(argc,argv);
#endif
 }
}
