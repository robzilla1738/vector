// Proposed native terminal frontend. This does not admit the existing SEA.
#include "AuxCliIngress.h"
#include "AuxCliMcpServer.h"
#include "AuxCliOpenArguments.h"
#include <vector>
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
#import <AppKit/AppKit.h>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <memory>
#include <mutex>
#include <thread>
#endif
#include "AuxNativeEndpointDelivery.h"
#include "packaged-identity-admission.h"
#include <mach-o/dyld.h>
#include <mach/mach.h>
#include <climits>
#include <cstdio>
#include <iostream>
#include <string_view>
#include <cstring>
#include <cstdlib>
#include <string>
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
namespace {
aux::cli::OpenOutcome DispatchOrdinaryOpen(const std::string& root, const aux::cli::OpenArguments& parsed) {
  const auto envelope = aux::cli::EncodeNativeOpenEnvelope(parsed);
  constexpr std::string_view suffix = "/Contents/Resources/aux";
  if (!envelope || !root.ends_with(suffix) || root.size() <= suffix.size()) {
    return {64, "Aux open needs one http(s) URL."};
  }
  const std::string app = root.substr(0, root.size() - suffix.size());
  NSString* app_path = [[NSString alloc] initWithBytes:app.data() length:app.size()
                                           encoding:NSUTF8StringEncoding];
  NSString* request = [[NSString alloc] initWithBytes:envelope->data() length:envelope->size()
                                           encoding:NSUTF8StringEncoding];
  NSURL* app_url = app_path ? [NSURL fileURLWithPath:app_path isDirectory:YES] : nil;
  NSURL* url = request ? [NSURL URLWithString:request] : nil;
  if (!app_url || !url) return {64, "Aux open needs one http(s) URL."};
  auto status = std::make_shared<std::atomic_int>(-1);
  NSWorkspaceOpenConfiguration* config = [NSWorkspaceOpenConfiguration configuration];
  config.activates = YES;
  config.createsNewApplicationInstance = NO;
  [[NSWorkspace sharedWorkspace] openURLs:@[url] withApplicationAtURL:app_url
      configuration:config completionHandler:^(NSRunningApplication* application, NSError* error) {
        status->store(application && !error ? 0 : 69);
      }];
  NSDate* deadline = [NSDate dateWithTimeIntervalSinceNow:10];
  while (status->load() < 0 && deadline.timeIntervalSinceNow > 0) {
    [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode
                           beforeDate:[NSDate dateWithTimeIntervalSinceNow:0.05]];
  }
  const int code = status->load();
  if (code == 0) return {0, "Sent to Aux."};
  if (code < 0) return {75, "Aux didn't confirm in time; the link may still open."};
  return {code, "Couldn't reach Aux."};
}
}  // namespace
#endif
namespace {
// A loop over aux ask: each line is one turn on the home thread.
// A query carries one reply, so ask a second one whether this turn is at a card.
class ApprovalNotice {
 public:
  ApprovalNotice():poll_([this]{Run();}){}
  ~ApprovalNotice(){
   {std::lock_guard<std::mutex> lock(mutex_);done_=true;}
   cancelled_.store(true);wake_.notify_one();poll_.join();
  }
 private:
  void Run(){
   std::unique_lock<std::mutex> lock(mutex_);
   while(!wake_.wait_for(lock,std::chrono::seconds(2),[this]{return done_;})){
    lock.unlock();
    std::string reply;
    const int status=aux::cli::QueryBrowser({"status"},&reply,cancelled_);
    if(!status&&reply.find("\"cliTurnAwaitingApproval\":true")!=std::string::npos&&!told_){
     told_=true;
     std::cerr<<"Waiting for your approval in Aux: use the Ask Aux button at the bottom of the sidebar.\n";
    }
    lock.lock();
   }
  }
  std::mutex mutex_;
  std::condition_variable wake_;
  bool done_=false,told_=false;
  std::atomic_bool cancelled_{false};
  std::thread poll_;
};
int Turn(int argc,char* argv[]){
 ApprovalNotice notice;
 return aux::cli::ForwardTerminalReadOnlyQuery(argc,argv);
}
int Repl(const std::vector<std::string>& arguments){
 std::vector<std::string> ask{"aux","ask"};
 if(arguments.size()==3&&arguments[1]=="--profile"){ask.push_back(arguments[1]);ask.push_back(arguments[2]);}
 else if(arguments.size()!=1){std::cerr<<"Usage: aux repl [--profile <ID or unique name>]\n";return 64;}
 ask.push_back("--");
 std::string line;
 for(;;){
  std::cout<<"> "<<std::flush;
  if(!std::getline(std::cin,line)||line=="exit"||line=="quit")return 0;
  if(line.empty())continue;
  auto turn=ask;
  turn.push_back(line);
  std::vector<char*> turn_argv;
  for(auto& argument:turn)turn_argv.push_back(argument.data());
  const int status=Turn(static_cast<int>(turn.size()),turn_argv.data());
  if(status&&status!=130)std::cerr<<"aux ask failed (exit "<<status<<").\n";
 }
}
}  // namespace
int main(int argc,char* argv[]){
 @autoreleasepool {
 char executable[PATH_MAX];uint32_t length=sizeof(executable);if(_NSGetExecutablePath(executable,&length))return 78;
 char resolved[PATH_MAX];if(!realpath(executable,resolved))return 78;
 const std::string self(resolved),suffix="/apps/cli/Aux CLI.app/Contents/MacOS/aux-cli";
 if(!self.ends_with(suffix)||self.size()<=suffix.size())return 78;
 const auto root=self.substr(0,self.size()-suffix.size());
 const auto endpoint=AuxTakeNativeParentEndpointForBootstrap();
 if(endpoint!=MACH_PORT_NULL){
  mach_port_deallocate(mach_task_self(),endpoint);
  // A browser-owned Node/installation role remains unsupported regardless of
  // immutable marker contents. No marker creates an installation owner.
  if(!aux::packaged_identity::MarkerAllowedAt(root+"/bundle.json")){
   std::cerr << std::string_view("Aux packaged state identity is unsupported or unaccepted\n");return 78;
  }
  // Explicit until the real typed proxy owner, role image graph and sealed
  // Node entry are joined. Never recursively forward a browser-owned child.
  std::cerr << std::string_view("Aux CLI retained runtime join is not paired\n");return 78;
 }
 std::vector<std::string> arguments;
 if(!aux::cli::CopyNativeMainArguments(argc,argv,&arguments))return 64;
 if(arguments.empty()||arguments.front()=="--help"||arguments.front()=="-h"||arguments.front()=="help"){
  std::cout << "Usage: aux <command> [options]\n\n"
               "  open <https://URL> [--space <ID or name>] [--profile <ID or name>]\n"
               "                       Open a link in Aux.\n"
               "  list [--profile <ID or name>]      Data groups and their Spaces.\n"
               "  spaces [--profile <ID or name>]    Spaces, one row each.\n"
               "  tabs [--profile <ID or name>]      Open tabs.\n"
               "  chats [--profile <ID or name>]     Recent agent chats.\n"
               "  status                             Aux, daemon and agent state.\n"
               "  mcp                                MCP server on stdin and stdout, for agents.\n"
               "  mcp list [--profile <ID or name>]  Configured MCP servers.\n"
               "  resolve <https://URL> [--profile <ID or name> [--space <ID or name>]]\n"
               "                       Where Aux would open a link, without opening it.\n\n"
               "  ask [--profile <ID or name>] <prompt>\n"
               "                       One prompt to the agent's ongoing chat; prints the reply.\n"
               "  exec [--profile <ID or name>] [--allow <name>]... <prompt>\n"
               "                       One prompt in a chat of its own. Anything that needs\n"
               "                       approval is refused unless --allow names it.\n"
               "  repl [--profile <ID or name>]      ask, one line at a time.\n\n"
               "--profile names a data group: Spaces that share cookies, from aux list.\n"
               "open, ask and repl print text; the rest print JSON. Aux must be running.\n";
  return 0;
 }
 // Read-only queries go to the running browser over the authenticated native
 // channel. They carry argv only: no environment, stdio or directory.
 const auto& command=arguments.front();
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
 if(command=="mcp"&&arguments.size()==1){
  return aux::cli::RunMcpServer([&root](const aux::cli::OpenArguments& parsed){return DispatchOrdinaryOpen(root,parsed);});
 }
#endif
 if(command=="list"||command=="resolve"||command=="spaces"||command=="tabs"||command=="chats"||command=="status"||command=="mcp"){
  const bool help=arguments.back()=="--help"||arguments.back()=="-h";
  if(help&&(arguments.size()==2||(arguments.size()==3&&command=="mcp"&&arguments[1]=="list"))){
   if(command=="mcp")std::cout << "Usage: aux mcp            Serve MCP on stdin and stdout: open, tabs, spaces, chats, status, resolve, ask.\n"
                                  "       aux mcp list [--profile <ID or unique name>]\n";
   else if(command=="resolve")std::cout << "Usage: aux resolve <https://URL> [--profile <ID or unique name> [--space <ID or unique name>]]\n";
   else if(command=="status")std::cout << "Usage: aux status\n";
   else std::cout << "Usage: aux " << command << " [--profile <ID or unique name>]\n";
   return 0;
  }
  if(!aux::cli::ParseNativeReadOnlyQuery(arguments)){
   std::cerr << "Invalid aux " << command << " arguments; run aux " << command << " --help.\n";return 64;
  }
  const int status=aux::cli::ForwardTerminalReadOnlyQuery(argc,argv);
  // 69 without JSON means no running Aux answered this CLI's locator.
  if(status)std::cerr << "aux " << command << " failed (exit " << status << "). If no JSON was printed, open Aux and try again.\n";
  return status;
 }
 if(command=="ask"||command=="exec"){
  if(arguments.size()==2&&(arguments[1]=="--help"||arguments[1]=="-h")){
   std::cout << "Usage: aux " << command << " [--profile <ID or unique name>]"
             << (command=="exec"?" [--allow <name>]...":"") << " [--] <prompt>\n";
   if(command=="exec")std::cout << "A name is a tool's own name, or file:read, file:write, browser:<action> or network.\n"
                                   "Prints JSON with the reply and what was approved or refused; exit 77 if anything was refused.\n";
   return 0;
  }
  if(!aux::cli::ParseNativeAgentCommand(arguments)){
   std::cerr << "Invalid aux " << command << " arguments; run aux " << command << " --help.\n";return 64;
  }
  const int status=Turn(argc,argv);
  if(status)std::cerr << "aux " << command << " failed (exit " << status << "). Open Aux and try again if nothing was printed.\n";
  return status;
 }
 if(command=="repl")return Repl(arguments);
 const auto parsed=aux::cli::ParseNativeOpenArguments(arguments);
 if(parsed.status==aux::cli::OpenParseStatus::help){
  std::cout << std::string_view("Usage: aux open <https://URL> [--space <Space ID or unique name>] [--profile <native profile ID or unique name>]\n");return 0;
 }
 if(parsed.status!=aux::cli::OpenParseStatus::accepted){
  // Nothing else reads a home or starts Node.
  std::cerr << std::string_view(arguments.front()=="open"
      ? "Aux open needs one http(s) URL.\n"
      : "Unknown command. Run aux --help.\n");
  return 64;
 }
 // Native open is admitted only by the exact browser peer, its genuine native
 // startup/Profile binding and actual one-shot OS approval. Markers grant none.
#if defined(AUX_BROWSER_ONLY_NATIVE_STARTUP)
 // An OS URL receipt is ordinary external navigation only. It does not grant
 // task execution, installation ownership or privileged CLI peer admission.
 const auto outcome=DispatchOrdinaryOpen(root,parsed);
 (outcome.code?std::cerr:std::cout) << outcome.message << '\n';
 return outcome.code;
#else
 return aux::cli::ForwardTerminalInvocation(argc,argv);
#endif
 }
}
