#pragma once
#include "AuxCliOpenArguments.h"
#include <functional>
#include <string>
namespace aux::cli {
struct OpenOutcome { int code; std::string message; };
using OpenInAux = std::function<OpenOutcome(const OpenArguments&)>;
// aux mcp: serves MCP on stdin and stdout until stdin closes. `open` is what
// aux open runs; every other tool is the CLI command of the same name.
int RunMcpServer(const OpenInAux& open);
}
