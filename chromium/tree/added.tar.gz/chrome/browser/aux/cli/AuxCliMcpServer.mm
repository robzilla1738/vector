// Model Context Protocol over stdio: one JSON-RPC message per line. Each tool
// is the CLI command of the same name, built into the same argv, checked by the
// same parsers and sent on the same authenticated route, so this adds no
// authority. exec stays out: its --allow is a person's decision, and the caller
// here is a model.
#include "AuxCliMcpServer.h"
#import <Foundation/Foundation.h>
#include "AuxCliIngress.h"
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>
namespace aux::cli {
namespace {
constexpr std::array<const char*, 4> kProtocolVersions{"2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"};
constexpr int kParseError = -32700, kInvalidRequest = -32600, kMethodNotFound = -32601, kInvalidParams = -32602,
              kBusy = -32000, kNotInitialized = -32002;
constexpr size_t kCallLimit = 8;
// A short read that just closed stdin still gets its answer; an agent turn doesn't hold the server open.
constexpr auto kCloseGrace = std::chrono::seconds(2);
constexpr const char* kProfileText = "Data group ID or unique name. Omit for the frontmost window's.";
constexpr const char* kSpaceText = "Space ID or unique name.";

struct Tool {
  const char* name;
  const char* description;
  const char* input;              // The required string, or null.
  const char* input_description;
  bool profile, space, read_only;
};
constexpr std::array<Tool, 7> kTools{{
    {"open", "Open an http(s) link in Aux. Returns once Aux has the link, not when the page has loaded.",
     "url", "The http(s) URL.", true, true, false},
    {"tabs", "Open tabs in Aux, as JSON.", nullptr, nullptr, true, false, true},
    {"spaces", "Spaces in Aux, as JSON.", nullptr, nullptr, true, false, true},
    {"chats", "Recent agent chats in Aux, as JSON.", nullptr, nullptr, true, false, true},
    {"status", "Aux, daemon and agent state, as JSON.", nullptr, nullptr, false, false, true},
    {"resolve", "Where Aux would open a link, as JSON, without opening it.",
     "url", "The http(s) URL.", true, true, true},
    {"ask", "One prompt to the Aux agent's home thread; returns its reply. This can take minutes: anything "
            "that needs approval waits for the person in Aux.",
     "prompt", "The prompt, up to 8192 bytes.", true, false, false},
}};

NSDictionary* Property(const char* description) {
  return @{@"type" : @"string", @"description" : @(description)};
}
NSDictionary* Describe(const Tool& tool) {
  NSMutableDictionary* properties = [NSMutableDictionary dictionary];
  if (tool.input) properties[@(tool.input)] = Property(tool.input_description);
  if (tool.profile) properties[@"profile"] = Property(kProfileText);
  if (tool.space) properties[@"space"] = Property(kSpaceText);
  NSMutableDictionary* schema = [@{@"type" : @"object", @"properties" : properties, @"additionalProperties" : @NO} mutableCopy];
  if (tool.input) schema[@"required"] = @[ @(tool.input) ];
  return @{@"name" : @(tool.name), @"description" : @(tool.description), @"inputSchema" : schema,
           @"annotations" : @{@"readOnlyHint" : @(tool.read_only)}};
}
const Tool* FindTool(NSString* name) {
  for (const auto& tool : kTools)
    if ([name isEqualToString:@(tool.name)]) return &tool;
  return nullptr;
}
bool Takes(const Tool& tool, NSString* key) {
  return (tool.input && [key isEqualToString:@(tool.input)]) || (tool.profile && [key isEqualToString:@"profile"]) ||
         (tool.space && [key isEqualToString:@"space"]);
}
std::string Bytes(NSData* data) {
  std::string bytes(data.length, '\0');
  [data getBytes:bytes.data() length:bytes.size()];
  return bytes;
}
// One argv entry. An embedded NUL would silently cut it at the C boundary.
std::optional<std::string> ArgumentText(id value) {
  if (![value isKindOfClass:NSString.class]) return std::nullopt;
  NSData* bytes = [value dataUsingEncoding:NSUTF8StringEncoding];
  if (!bytes.length || bytes.length > kArgumentBytes) return std::nullopt;
  auto text = Bytes(bytes);
  if (text.find('\0') != std::string::npos) return std::nullopt;
  return text;
}
// The argv aux <tool> would get, accepted by the parser that command uses.
std::optional<std::vector<std::string>> CommandLine(const Tool& tool, NSDictionary* input) {
  for (NSString* key in input)
    if (!Takes(tool, key)) return std::nullopt;
  std::vector<std::string> argv{tool.name};
  for (const auto& [key, flag] : std::array<std::pair<NSString*, const char*>, 2>{{{@"profile", "--profile"}, {@"space", "--space"}}}) {
    id value = input[key];
    if (!value) continue;
    auto text = ArgumentText(value);
    if (!text) return std::nullopt;
    argv.push_back(flag);
    argv.push_back(std::move(*text));
  }
  if (tool.input) {
    auto text = ArgumentText(input[@(tool.input)]);
    if (!text) return std::nullopt;
    argv.push_back("--");
    argv.push_back(std::move(*text));
  }
  const bool accepted = ParseNativeReadOnlyQuery(argv) || ParseNativeAgentCommand(argv) ||
                        ParseNativeOpenArguments(argv).status == OpenParseStatus::accepted;
  if (!accepted) return std::nullopt;
  return argv;
}
NSDictionary* ToolResult(NSString* text, bool is_error) {
  return @{@"content" : @[ @{@"type" : @"text", @"text" : text} ], @"isError" : @(is_error)};
}
NSDictionary* Success(id identifier, id result) {
  return @{@"jsonrpc" : @"2.0", @"id" : identifier, @"result" : result};
}
NSDictionary* Failure(id identifier, int code, NSString* message) {
  return @{@"jsonrpc" : @"2.0", @"id" : identifier ?: NSNull.null, @"error" : @{@"code" : @(code), @"message" : message}};
}
bool ValidIdentifier(id identifier) {
  if ([identifier isKindOfClass:NSString.class]) return true;
  return [identifier isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)identifier) != CFBooleanGetTypeID();
}
// JSON keeps 1 and "1" distinct, as the protocol does.
std::string CallKey(id identifier) {
  return Bytes([NSJSONSerialization dataWithJSONObject:identifier options:NSJSONWritingFragmentsAllowed error:nil]);
}
class Server final {
 public:
  explicit Server(const OpenInAux& open) : open_(open) {}
  int Run() {
    std::string line;
    while (std::getline(std::cin, line)) {
      if (line.ends_with('\r')) line.pop_back();
      if (line.empty()) continue;
      @autoreleasepool {
        Handle(line);
      }
    }
    std::unique_lock lock(mutex_);
    idle_.wait_for(lock, kCloseGrace, [this] { return calls_.empty(); });
    for (auto& [key, cancelled] : calls_) cancelled->store(true);
    idle_.wait(lock, [this] { return calls_.empty(); });
    return 0;
  }

 private:
  void Send(NSDictionary* message) {
    NSData* json = [NSJSONSerialization dataWithJSONObject:message options:NSJSONWritingWithoutEscapingSlashes error:nil];
    std::lock_guard lock(output_);
    std::cout << Bytes(json) << '\n' << std::flush;
  }
  void Handle(const std::string& line) {
    NSData* bytes = [NSData dataWithBytes:line.data() length:line.size()];
    id message = [NSJSONSerialization JSONObjectWithData:bytes options:0 error:nil];
    if (!message) {
      Send(Failure(nil, kParseError, @"Parse error"));
      return;
    }
    if (![message isKindOfClass:NSDictionary.class]) {
      Send(Failure(nil, kInvalidRequest, @"Expected one JSON-RPC object"));
      return;
    }
    id identifier = message[@"id"];
    id method = message[@"method"];
    if (identifier && !ValidIdentifier(identifier)) {
      Send(Failure(nil, kInvalidRequest, @"id must be a string or number"));
      return;
    }
    const bool is_response = !method && identifier && (message[@"result"] || message[@"error"]);
    if (is_response) return;
    id params = message[@"params"];
    if (![message[@"jsonrpc"] isEqual:@"2.0"] || ![method isKindOfClass:NSString.class]) {
      Send(Failure(identifier, kInvalidRequest, @"Not a JSON-RPC 2.0 request"));
      return;
    }
    if (params && ![params isKindOfClass:NSDictionary.class]) {
      if (identifier) Send(Failure(identifier, kInvalidParams, @"params must be an object"));
      return;
    }
    if (!identifier) {
      if ([method isEqualToString:@"notifications/cancelled"]) Cancel(params[@"requestId"]);
      return;
    }
    Dispatch(identifier, method, params);
  }
  void Dispatch(id identifier, NSString* method, NSDictionary* params) {
    if ([method isEqualToString:@"ping"]) {
      Send(Success(identifier, @{}));
    } else if ([method isEqualToString:@"initialize"]) {
      Initialize(identifier, params);
    } else if (!initialized_) {
      Send(Failure(identifier, kNotInitialized, @"Send initialize first"));
    } else if ([method isEqualToString:@"tools/list"]) {
      NSMutableArray* tools = [NSMutableArray array];
      for (const auto& tool : kTools) [tools addObject:Describe(tool)];
      Send(Success(identifier, @{@"tools" : tools}));
    } else if ([method isEqualToString:@"tools/call"]) {
      Call(identifier, params);
    } else {
      Send(Failure(identifier, kMethodNotFound, @"Method not found"));
    }
  }
  void Initialize(id identifier, NSDictionary* params) {
    NSString* requested = params[@"protocolVersion"];
    if (![requested isKindOfClass:NSString.class]) {
      Send(Failure(identifier, kInvalidParams, @"protocolVersion must be a string"));
      return;
    }
    NSString* version = @(kProtocolVersions.front());
    for (const char* supported : kProtocolVersions)
      if ([requested isEqualToString:@(supported)]) version = requested;
    initialized_ = true;
    NSString* aux_version = [NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"] ?: @"0";
    Send(Success(identifier, @{
      @"protocolVersion" : version,
      @"capabilities" : @{@"tools" : @{}},
      @"serverInfo" : @{@"name" : @"aux", @"version" : aux_version},
      @"instructions" : @"Tools for the running Aux browser. Aux must be open.",
    }));
  }
  void Cancel(id identifier) {
    if (!ValidIdentifier(identifier)) return;
    std::lock_guard lock(mutex_);
    if (const auto call = calls_.find(CallKey(identifier)); call != calls_.end()) call->second->store(true);
  }
  void Call(id identifier, NSDictionary* params) {
    NSString* name = params[@"name"];
    const Tool* tool = [name isKindOfClass:NSString.class] ? FindTool(name) : nullptr;
    NSDictionary* input = params[@"arguments"] ?: @{};
    if (!tool || ![input isKindOfClass:NSDictionary.class]) {
      Send(Failure(identifier, kInvalidParams, tool ? @"arguments must be an object" : @"Unknown tool"));
      return;
    }
    auto argv = CommandLine(*tool, input);
    if (!argv) {
      Send(Success(identifier, ToolResult(@"Invalid arguments; see this tool's input schema.", true)));
      return;
    }
    const auto key = CallKey(identifier);
    auto cancelled = std::make_shared<std::atomic_bool>(false);
    {
      std::lock_guard lock(mutex_);
      if (calls_.contains(key)) {
        Send(Failure(identifier, kInvalidRequest, @"id is already in use"));
        return;
      }
      if (calls_.size() >= kCallLimit) {
        Send(Failure(identifier, kBusy, @"Too many calls in flight"));
        return;
      }
      calls_.emplace(key, cancelled);
    }
    // A worker per call: ask can run for minutes, and ping and cancellation must still answer.
    std::thread([this, identifier, tool, argv = std::move(*argv), cancelled, key] {
      @autoreleasepool {
        NSDictionary* result = Execute(*tool, argv, *cancelled);
        if (!cancelled->load()) Send(Success(identifier, result));
      }
      std::lock_guard lock(mutex_);
      calls_.erase(key);
      idle_.notify_all();
    }).detach();
  }
  NSDictionary* Execute(const Tool& tool, const std::vector<std::string>& argv, const std::atomic_bool& cancelled) {
    if (std::string_view(tool.name) == "open") {
      const auto outcome = open_(ParseNativeOpenArguments(argv));
      return ToolResult(@(outcome.message.c_str()), outcome.code != 0);
    }
    std::string reply;
    const int code = QueryBrowser(argv, &reply, cancelled);
    if (reply.empty()) return ToolResult(NoReply(tool, code), true);
    NSString* text = [[NSString alloc] initWithBytes:reply.data() length:reply.size() encoding:NSUTF8StringEncoding];
    return ToolResult(text ?: @"Aux sent a reply that isn't UTF-8.", code != 0);
  }
  static NSString* NoReply(const Tool& tool, int code) {
    if (code == 69) return @"Aux isn't running. Open Aux and try again.";
    return [NSString stringWithFormat:@"aux %s failed (exit %d).", tool.name, code];
  }
  const OpenInAux open_;
  bool initialized_ = false;  // Stdin thread only.
  std::mutex output_, mutex_;
  std::condition_variable idle_;
  std::map<std::string, std::shared_ptr<std::atomic_bool>> calls_;
};
}  // namespace
int RunMcpServer(const OpenInAux& open) {
  Server server(open);
  return server.Run();
}
}
