// Copyright 2026 The Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/aux/organization/space_directory.h"

#include <algorithm>
#include <utility>

#include "base/no_destructor.h"
#include "base/values.h"
#include "chrome/browser/aux/organization/organization_model.h"
#include "chrome/browser/browser_process.h"
#include "chrome/browser/profiles/profile_attributes_storage.h"
#include "chrome/browser/profiles/profile_manager.h"
#include "components/prefs/pref_registry_simple.h"
#include "components/prefs/pref_service.h"
#include "components/prefs/scoped_user_pref_update.h"

namespace aux::organization {
namespace {

base::RepeatingClosureList& Observers() {
  static base::NoDestructor<base::RepeatingClosureList> observers;
  return *observers;
}

std::vector<DirectorySpace> ReadAll() {
  std::vector<DirectorySpace> spaces;
  auto* local_state = g_browser_process ? g_browser_process->local_state() : nullptr;
  if (!local_state) return spaces;
  for (const auto& value : local_state->GetList(kSpaceDirectoryPref)) {
    const auto* dict = value.GetIfDict();
    const auto* group = dict ? dict->FindString("group") : nullptr;
    const auto* id = dict ? dict->FindString("id") : nullptr;
    if (!group || !id || group->empty() || id->empty()) continue;
    const auto* name = dict->FindString("name");
    const auto* icon = dict->FindString("icon");
    spaces.push_back({*group, *id, name ? *name : std::string(), icon ? *icon : std::string()});
  }
  return spaces;
}

void Write(const std::vector<DirectorySpace>& spaces) {
  auto* local_state = g_browser_process ? g_browser_process->local_state() : nullptr;
  if (!local_state || ReadAll() == spaces) return;
  base::ListValue list;
  for (const auto& space : spaces)
    list.Append(base::DictValue().Set("group", space.group).Set("id", space.id)
                    .Set("name", space.name).Set("icon", space.icon));
  local_state->SetList(kSpaceDirectoryPref, std::move(list));
  Observers().Notify();
}

}  // namespace

void RegisterSpaceDirectoryPrefs(PrefRegistrySimple* registry) {
  registry->RegisterListPref(kSpaceDirectoryPref);
}

std::vector<DirectorySpace> ReadSpaceDirectory() {
  auto spaces = ReadAll();
  // A group whose profile is gone takes its Spaces with it.
  auto* manager = g_browser_process ? g_browser_process->profile_manager() : nullptr;
  if (!manager) return spaces;
  auto& storage = manager->GetProfileAttributesStorage();
  std::erase_if(spaces, [&](const DirectorySpace& space) {
    return !storage.GetProfileAttributesWithPath(GroupPath(space.group));
  });
  return spaces;
}

void SyncSpaceDirectory(const base::FilePath& profile_path, const Snapshot& snapshot) {
  const std::string group = GroupOf(profile_path);
  auto spaces = ReadAll();
  // Renames and removals in place, so the user's order holds.
  std::erase_if(spaces, [&](const DirectorySpace& space) {
    return space.group == group && !snapshot.spaces.contains(space.id);
  });
  for (auto& space : spaces) {
    if (space.group != group) continue;
    const auto& source = snapshot.spaces.at(space.id);
    space.name = source.name;
    space.icon = source.icon;
  }
  // New Spaces join after the last one of their group, in the group's order.
  std::vector<const Space*> fresh;
  for (const auto& [id, space] : snapshot.spaces) {
    if (std::ranges::none_of(spaces, [&](const DirectorySpace& known) {
          return known.group == group && known.id == id;
        }))
      fresh.push_back(&space);
  }
  std::ranges::sort(fresh, {}, &Space::order);
  auto at = std::find_if(spaces.rbegin(), spaces.rend(),
                         [&](const DirectorySpace& space) { return space.group == group; }).base();
  for (const auto* space : fresh)
    at = std::next(spaces.insert(at, {group, space->id, space->name, space->icon}));
  Write(spaces);
}

void MoveDirectorySpace(const std::string& group, const std::string& id, size_t index) {
  auto spaces = ReadAll();
  const auto found = std::ranges::find_if(spaces, [&](const DirectorySpace& space) {
    return space.group == group && space.id == id;
  });
  if (found == spaces.end()) return;
  const DirectorySpace moved = *found;
  spaces.erase(found);
  spaces.insert(spaces.begin() + std::min(index, spaces.size()), moved);
  Write(spaces);
}

base::CallbackListSubscription ObserveSpaceDirectory(base::RepeatingClosure callback) {
  return Observers().Add(std::move(callback));
}

std::string GroupOf(const base::FilePath& profile_path) {
  return profile_path.BaseName().AsUTF8Unsafe();
}

bool IsIsolatedGroup(const std::string& group) {
  return group != kDefaultGroup;
}

base::FilePath GroupPath(const std::string& group) {
  auto* manager = g_browser_process ? g_browser_process->profile_manager() : nullptr;
  return manager ? manager->user_data_dir().AppendASCII(group) : base::FilePath();
}

}  // namespace aux::organization
