// Copyright 2026 The Aux Authors. BSD-style license: see //LICENSE.
#ifndef CHROME_BROWSER_AUX_ORGANIZATION_SPACE_DIRECTORY_H_
#define CHROME_BROWSER_AUX_ORGANIZATION_SPACE_DIRECTORY_H_

#include <string>
#include <vector>

#include "base/callback_list.h"
#include "base/files/file_path.h"

class PrefRegistrySimple;

namespace aux::organization {
struct Snapshot;

// Spaces replace profiles: each profile is a hidden data group (cookies, site
// data, history, extensions), and every Space belongs to one. The directory is
// the browser-wide list of every Space in every group, in the user's order;
// each group's own model still holds its Spaces' tabs.
struct DirectorySpace {
  // The data group: the profile directory's base name.
  std::string group;
  std::string id;
  std::string name;
  std::string icon;
  bool operator==(const DirectorySpace&) const = default;
};

inline constexpr char kSpaceDirectoryPref[] = "aux.space_directory";
// The group every Space shares unless it was created isolated.
inline constexpr char kDefaultGroup[] = "Default";

void RegisterSpaceDirectoryPrefs(PrefRegistrySimple* registry);

// Every Space whose group still exists, in order.
std::vector<DirectorySpace> ReadSpaceDirectory();
// Brings one group's entries in line with its model: renames and icons
// follow, removed Spaces leave, and new ones join after that group's last.
void SyncSpaceDirectory(const base::FilePath& profile_path, const Snapshot& snapshot);
// Puts a Space at `index` in the browser-wide order.
void MoveDirectorySpace(const std::string& group, const std::string& id, size_t index);
base::CallbackListSubscription ObserveSpaceDirectory(base::RepeatingClosure callback);

// The group of a profile, and whether it is one an isolated Space created.
std::string GroupOf(const base::FilePath& profile_path);
bool IsIsolatedGroup(const std::string& group);
base::FilePath GroupPath(const std::string& group);

}  // namespace aux::organization

#endif  // CHROME_BROWSER_AUX_ORGANIZATION_SPACE_DIRECTORY_H_
