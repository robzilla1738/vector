# Aux Vault request-scoped WebAuthn adapter

Original Aux provider selected at Chromium155's validated RP continuation, after
security context, permissions policy, ancestor, RP and TLS checks. It does not
attach webAuthenticationProxy globally and does not replace renderer credential
APIs. A native tab-modal chooser identifies the actual requesting origin. Other
providers resume the existing request delegate and normal discovery flow.

Only modal, same-origin, non-payment, non-remote, nonvirtual calls offer this
provider. Conditional/ambient/immediate mediation remains with existing
providers. Aux supports P-256/ES256, none attestation, discoverable credentials
and credProps; unsupported extensions/attestation fail explicitly in the Vault
service. Native completion uses Chromium's own strict response parser, verifies
exact client data, RP hash, ID, UP/UV flags, no backup flags and credential
allow/exclude lists. It restores the requesting WebContents' focus, rechecks
lifetime, and preserves Chromium's final focus check.

`BeginCreate/BeginGet` retain a WeakDocumentPtr, actual Profile pointer, caller
and top origins, and a random request UUID. Content owns a ScopedClosureRunner
which abandons this exact request on abort/teardown. Requests expire in two
minutes and complete at most once. Private Vault API `getRequest` returns an
installation-signed envelope only while the profile's actual disk account gate
is configured, onboarded and unlocked. It signs `Aux Passkey Request v1\n` plus
the exact raw JSON; this domain cannot serve as a daemon authentication response.
The envelope includes account, profile, mode, native Profile lifetime nonce,
frame process/routing identity, RP, origins, native clientDataJSON and options.
`complete` rereads the profile gate, verifies the same bound account and exact
live document, then consumes the callback. `reject` cancels it. These private
functions have a Vault-only extension allowlist and native ID check.

The consent popup uses `index.html#/passkeys/<UUID>` in the same actual Profile.
Normal mode stores encrypted credentials through the dedicated Vault collection;
private mode uses RAM keys bound to the signed lifetime nonce. A ProfileObserver
abandons pending callbacks and sends authenticated Chromium-only retirement for
the exact private nonce when the Profile is destroyed. The cleanup body contains
only account/profile/random session identity; it uses the live local daemon
credential and validated AUX_PORT loopback endpoint, with a five-second bound.
Shutdown also destroys the daemon RAM state. Vault worker cleanup and pruning
older signed epochs provide additional cleanup without adopting a reused Profile
pointer or numeric frame ID.

Compilation target is enabled `out/AuxAside`, with `enable_aux_browser=true` and
`enable_aux_shell=false`, under `/tmp/aux-build.lock`. Six focused native objects
cover broker, cleanup, private API, Chrome delegate, public delegate and content
request continuation. No owner Profile, Keychain or RP credentials are used.
Full linked disposable-profile registration/assertion observation is a separate
integration acceptance step; compilation does not establish that evidence.

Sources: approved docs/spec/daemon/services.md Vault behavior and
native/apis-core.md A0 private capability boundary; public WebAuthn3 and upstream
Chromium155 authenticator_common_impl, web_authentication_delegate,
client_data_json and value_conversions interfaces. No reference artifacts used.
