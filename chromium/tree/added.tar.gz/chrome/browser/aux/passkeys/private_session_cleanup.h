// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_AUX_PASSKEYS_PRIVATE_SESSION_CLEANUP_H_
#define CHROME_BROWSER_AUX_PASSKEYS_PRIVATE_SESSION_CLEANUP_H_
#include <string>
namespace aux::passkeys {
void RetirePrivateSession(int account_id,
                          std::string profile_id,
                          std::string profile_session);
}
#endif
