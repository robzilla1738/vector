// Copyright 2026 Aux Authors. All rights reserved.
#ifndef CHROME_BROWSER_AUX_PASSKEYS_REQUEST_BROKER_H_
#define CHROME_BROWSER_AUX_PASSKEYS_REQUEST_BROKER_H_

#include <optional>
#include <string>

#include "base/functional/callback.h"
#include "base/values.h"
#include "content/public/browser/web_authentication_request_proxy.h"
#include "third_party/blink/public/mojom/webauthn/authenticator.mojom.h"
#include "url/origin.h"

class Profile;
namespace content {
class RenderFrameHost;
}
namespace aux::passkeys {
// Invoke only after content's RP, TLS, permissions-policy and ancestor checks.
// The dialog preserves Chromium providers through the Other providers action.
base::OnceClosure ChooseProvider(
    content::RenderFrameHost* frame,
    base::OnceCallback<void(bool use_aux)> callback);
using CreateCallback = content::WebAuthenticationRequestProxy::CreateCallback;
using GetCallback = content::WebAuthenticationRequestProxy::GetCallback;
// Selected requests only: no global proxy is installed. Returned id belongs to
// this exact document and Profile. The caller cancels it on WebAuthn
// cancellation.
std::string BeginCreate(
    content::RenderFrameHost* frame,
    const url::Origin& caller,
    const blink::mojom::PublicKeyCredentialCreationOptionsPtr& options,
    CreateCallback callback);
std::string BeginGet(
    content::RenderFrameHost* frame,
    const url::Origin& caller,
    const blink::mojom::PublicKeyCredentialRequestOptionsPtr& options,
    GetCallback callback);
void Cancel(const std::string& id);
// Caller-owned cancellation: discard the callback; content completes its own
// error.
void Abandon(const std::string& id);
// Private Vault component only. Every call rechecks document/profile identity;
// signed request production additionally reads the current disk security gate.
void ReadRequest(
    Profile* profile,
    const std::string& id,
    base::OnceCallback<void(std::optional<base::DictValue>)> callback);
void Complete(Profile* profile,
              const std::string& id,
              base::Value response,
              base::OnceCallback<void(std::optional<std::string>)> callback);
bool Reject(Profile* profile, const std::string& id);
}  // namespace aux::passkeys
#endif
