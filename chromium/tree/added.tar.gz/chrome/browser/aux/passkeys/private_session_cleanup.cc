// Copyright 2026 Aux Authors. All rights reserved.
#include "chrome/browser/aux/passkeys/private_session_cleanup.h"

#include "base/environment.h"
#include "base/functional/bind.h"
#include "base/json/json_writer.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/time.h"
#include "base/values.h"
#include "chrome/browser/aux/browser_platform.h"
#include "chrome/browser/browser_process.h"
#include "net/traffic_annotation/network_traffic_annotation.h"
#include "services/network/public/cpp/resource_request.h"
#include "services/network/public/cpp/simple_url_loader.h"
#include "services/network/public/mojom/fetch_api.mojom.h"
namespace aux::passkeys {
void RetirePrivateSession(int account_id,
                          std::string profile_id,
                          std::string session) {
  if (!g_browser_process) {
    return;
  }
  auto factory = g_browser_process->shared_url_loader_factory();
  const auto auth = BrowserPlatform::Get().authorization();
  if (!factory || auth.empty()) {
    return;
  }
  unsigned port = 21520;
  if (auto text = base::Environment::Create()->GetVar("AUX_PORT");
      text &&
      (!base::StringToUint(*text, &port) || port == 0 || port > 65535)) {
    return;
  }
  auto request = std::make_unique<network::ResourceRequest>();
  request->url = GURL("http://127.0.0.1:" + base::NumberToString(port) +
                      "/trpc/passkeys.retirePrivateSession");
  request->method = "POST";
  request->credentials_mode = network::mojom::CredentialsMode::kOmit;
  request->headers.SetHeader("Authorization", auth);
  constexpr auto annotation =
      net::DefineNetworkTrafficAnnotation("aux_private_passkey_retirement", R"(
        semantics {
          sender: "Aux Vault native passkey lifecycle"
          description: "Retires memory-only passkeys for the exact closed private Profile instance."
          trigger: "An incognito browser Profile is destroyed."
          data: "Local account and profile identifiers and a random private-session identifier; no credentials."
          destination: LOCAL
        }
        policy { cookies_allowed: NO setting: "Local Aux Vault private-session lifecycle." policy_exception_justification: "No external network destination." }
      )");
  auto loader =
      network::SimpleURLLoader::Create(std::move(request), annotation);
  loader->SetTimeoutDuration(base::Seconds(5));
  base::DictValue body;
  body.Set("accountId", account_id);
  body.Set("profileId", profile_id);
  body.Set("browserMode", "incognito");
  body.Set("profileSession", session);
  loader->AttachStringForUpload(base::WriteJson(body).value(),
                                "application/json");
  auto* raw = loader.get();
  raw->DownloadToString(
      factory.get(),
      base::BindOnce([](std::unique_ptr<network::SimpleURLLoader> owner,
                        std::optional<std::string> response) {},
                     std::move(loader)),
      4096);
}
}  // namespace aux::passkeys
