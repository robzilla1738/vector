// Copyright 2026 Aux Authors. All rights reserved.
// Supplied startup separates component readiness from daemon authentication.
#include "chrome/browser/aux/browser_platform.h"

#include "base/command_line.h"
#include "base/environment.h"
#include "base/functional/bind.h"
#include "base/logging.h"
#include "base/run_loop.h"
#include "base/strings/string_number_conversions.h"
#include "base/task/thread_pool.h"
#include "base/task/sequenced_task_runner.h"
#include "chrome/browser/aux/installation_auth.h"
#include "AuxSelectedStateHome.h"
namespace aux {
BrowserPlatform::BrowserPlatform() = default;
BrowserPlatform::~BrowserPlatform() = default;
BrowserPlatform& BrowserPlatform::Get() {
  static base::NoDestructor<BrowserPlatform> instance;
  return *instance;
}
bool BrowserPlatform::Start(
    scoped_refptr<network::SharedURLLoaderFactory> factory) {
  if (direct_daemon_admission_closed_) return false;
  if (supervisor_) {
    return components_.size() == 1;
  }
  auto paths = BundlePaths::FromBrowserExecutable();
  if (!paths) {
    return false;
  }
  auto selected = peer::ReadNativeSelectedStateHome();
  if (selected.route != peer::SelectedStateHomeRoute::unselected &&
      selected.route != peer::SelectedStateHomeRoute::current) return false;
  auto home = StateHome();
  if (home.empty()) {
    return false;
  }
  base::RunLoop components_loop;
  base::ThreadPool::PostTaskAndReplyWithResult(
      FROM_HERE, {base::MayBlock()},
      base::BindOnce(&ReadBundledComponents, *paths),
      base::BindOnce(
          [](BrowserPlatform* self, base::OnceClosure quit,
             std::optional<std::vector<ComponentManifest>> components) {
            if (components) {
              self->components_ = std::move(*components);
            }
            std::move(quit).Run();
          },
          base::Unretained(this), components_loop.QuitClosure()));
  components_loop.Run();
  // A migration quiesce may run while the nested startup loop is waiting.
  if (direct_daemon_admission_closed_) return false;
  if (components_.size() != 1) {
    LOG(ERROR) << "Aux bundled extension resources are missing or invalid";
    return false;
  }
  uint16_t port = 21520;
  auto env = base::Environment::Create();
  if (auto text = env->GetVar("AUX_PORT");
      selected.route == peer::SelectedStateHomeRoute::unselected && text) {
    unsigned number = 0;
    if (!base::StringToUint(*text, &number) || number == 0 || number > 65535) {
      return false;
    }
    port = number;
  }
  // The native route already owns the spawned daemon. Its exact selected
  // owner supplies home/PID; Start polls it and can never issue another spawn.
  if (selected.route == peer::SelectedStateHomeRoute::current) {
    supervisor_ = DaemonSupervisor::AdoptInstalledNativeChild(
        *paths, port, std::move(factory),
        base::BindRepeating(&BrowserPlatform::DidChangeDaemonState, weak_.GetWeakPtr()));
    if (!supervisor_) return false;
  } else {
    // A selected route may have installed while the component loop waited.
    if (peer::ReadNativeSelectedStateHome().route != peer::SelectedStateHomeRoute::unselected) return false;
    supervisor_ = std::make_unique<DaemonSupervisor>(
        *paths, home, port, std::move(factory),
        base::BindRepeating(&BrowserPlatform::DidChangeDaemonState, weak_.GetWeakPtr()),
        base::CommandLine::ForCurrentProcess()->HasSwitch("aux-development-runtime"));
  }
  supervisor_->Start();
  return true;
}
void BrowserPlatform::RequestDaemonAuthorization(
    bool force, DaemonAuthorizationCallback callback) {
  if (direct_daemon_admission_closed_ || !supervisor_) {
    base::SequencedTaskRunner::GetCurrentDefault()->PostTask(
        FROM_HERE, base::BindOnce(std::move(callback), std::nullopt));
    return;
  }
  supervisor_->RequestAuthorization(force, std::move(callback));
}
base::CallbackListSubscription BrowserPlatform::ObserveDaemonAuthorization(
    base::RepeatingClosure callback) {
  return authorization_observers_.Add(std::move(callback));
}
base::CallbackListSubscription BrowserPlatform::ObserveDaemonLost(
    base::RepeatingClosure callback) {
  return daemon_lost_observers_.Add(std::move(callback));
}
base::CallbackListSubscription BrowserPlatform::ObserveDaemonState(
    base::RepeatingClosure callback) {
  return daemon_state_observers_.Add(std::move(callback));
}
void BrowserPlatform::RetryDaemon() {
  if (supervisor_ && !direct_daemon_admission_closed_) supervisor_->Start();
}
void BrowserPlatform::DidChangeDaemonState(DaemonSupervisor::State state,
                                          std::string error) {
  daemon_state_observers_.Notify();
  if (state == DaemonSupervisor::State::kFailed) {
    LOG(ERROR) << error;
    if (daemon_was_ready_) {
      daemon_was_ready_ = false;
      daemon_lost_observers_.Notify();
    }
  }
  if (state == DaemonSupervisor::State::kReady) daemon_was_ready_ = true;
  const bool authorized = state == DaemonSupervisor::State::kReady &&
      authorization().starts_with("AuxDaemonSessionToken ") &&
      authorization().size() > sizeof("AuxDaemonSessionToken ") - 1;
  const bool became_authorized = authorized && !authorization_was_available_;
  authorization_was_available_ = authorized;
  if (became_authorized) authorization_observers_.Notify();
  if (state != DaemonSupervisor::State::kReady || public_key_ || loading_key_) {
    return;
  }
  loading_key_ = true;
  base::ThreadPool::PostTaskAndReplyWithResult(
      FROM_HERE, {base::MayBlock()},
      base::BindOnce(&LoadInstallationPublicKey, StateHome()),
      base::BindOnce(
          [](base::WeakPtr<BrowserPlatform> self,
             std::optional<crypto::keypair::PublicKey> key) {
            if (self) {
              self->loading_key_ = false;
              self->public_key_ = std::move(key);
              if (self->public_key_) {
                self->cdp_authority_observers_.Notify();
              }
            }
          }, weak_.GetWeakPtr()));
}
void BrowserPlatform::WaitForStartupExtensions(
    base::RepeatingCallback<bool()> extensions_ready) {
  if (startup_state_ == StartupState::kDone || extensions_ready.Run()) {
    startup_state_ = StartupState::kDone;
    return;
  }
  base::RunLoop loop;
  startup_waiters_.push_back(loop.QuitClosure());
  if (startup_state_ == StartupState::kNotStarted) {
    startup_state_ = StartupState::kWaiting;
    startup_extensions_ready_ = std::move(extensions_ready);
    // The Agent extension registers in well under a second. Should it not,
    // the browser opens anyway; the extension's pages catch up when it does.
    startup_deadline_ = base::TimeTicks::Now() + base::Seconds(5);
    startup_timer_.Start(FROM_HERE, base::Milliseconds(50), this,
                         &BrowserPlatform::CheckStartupReadiness);
    CheckStartupReadiness();
  }
  loop.Run();
}
void BrowserPlatform::CheckStartupReadiness() {
  if (startup_state_ != StartupState::kWaiting) {
    return;
  }
  const bool extensions_ready = startup_extensions_ready_.Run();
  if (!extensions_ready && base::TimeTicks::Now() < startup_deadline_) {
    return;
  }
  if (!extensions_ready) {
    LOG(WARNING) << "Aux Agent extension not ready yet; opening the browser anyway";
  }
  startup_state_ = StartupState::kDone;
  startup_timer_.Stop();
  startup_extensions_ready_.Reset();
  auto waiters = std::move(startup_waiters_);
  for (auto& waiter : waiters) {
    std::move(waiter).Run();
  }
}

void BrowserPlatform::QuiesceDirectDaemonForMigration(
    DirectDaemonQuiesceCallback done) {
  direct_daemon_admission_closed_ = true;
  if (supervisor_) {
    supervisor_->QuiesceDirectDaemonForMigration(std::move(done));
    return;
  }
  DirectDaemonQuiesceResult result;
  result.outcome = DirectDaemonQuiesceResult::Outcome::kNoOwnedProcess;
  base::SequencedTaskRunner::GetCurrentDefault()->PostTask(
      FROM_HERE, base::BindOnce(std::move(done), result));
}
void BrowserPlatform::QuiesceOwnedDirectHelpersForMigration(
    OwnedDirectHelperQuiesceCallback done) {
  // Starts asynchronous daemon drain through the existing scoped API. It does
  // not wait for unrelated work.
  owned_helper_quiesce_.CloseRequested();
  direct_daemon_admission_closed_ = true;
  if (InspectOwnedDirectHelperQuiesce().direct_daemon) {
    base::SequencedTaskRunner::GetCurrentDefault()->PostTask(
        FROM_HERE, base::BindOnce(std::move(done),
                                InspectOwnedDirectHelperQuiesce()));
    return;
  }
  QuiesceDirectDaemonForMigration(base::BindOnce(
      [](base::WeakPtr<BrowserPlatform> self,
         OwnedDirectHelperQuiesceCallback done,
         DirectDaemonQuiesceResult direct) {
        if (!self) return;  // Lost completion remains pending; never success.
        self->owned_helper_quiesce_.ObserveDirectResult(direct);
        std::move(done).Run(self->InspectOwnedDirectHelperQuiesce());
      }, weak_.GetWeakPtr(), std::move(done)));
}
OwnedDirectHelperQuiesceObservation
BrowserPlatform::InspectOwnedDirectHelperQuiesce() const {
  return owned_helper_quiesce_.Inspect();
}
void BrowserPlatform::Shutdown() {
  direct_daemon_admission_closed_ = true;
  weak_.InvalidateWeakPtrs();
  startup_timer_.Stop();
  startup_extensions_ready_.Reset();
  startup_state_ = StartupState::kDone;
  auto waiters = std::move(startup_waiters_);
  for (auto& waiter : waiters) {
    std::move(waiter).Run();
  }
  loading_key_ = false;
  if (!supervisor_) {
    return;
  }
  base::RunLoop loop;
  supervisor_->Shutdown(loop.QuitClosure());
  loop.Run();
  // Never discard the owned handle after an unverified drain.
  if (supervisor_->state() != DaemonSupervisor::State::kStopped) return;
  supervisor_.reset();
  components_.clear();
  public_key_.reset();
}
bool BrowserPlatform::RegisterProfileComponents(
    base::RepeatingCallback<std::string(base::DictValue, const base::FilePath&)>
        installer) {
  if (components_.size() != 1) {
    return false;
  }
  std::vector<ComponentManifest> copy;
  for (const auto& component : components_) {
    copy.push_back(
        {component.id, component.directory, component.manifest.Clone()});
  }
  return RegisterBundledComponents(std::move(copy), std::move(installer));
}
base::CallbackListSubscription BrowserPlatform::ObserveBrowserCdpAuthority(
    base::RepeatingClosure callback) {
  return cdp_authority_observers_.Add(std::move(callback));
}
CdpRequestFilter BrowserPlatform::CreateBrowserCdpFilter(uint16_t port) const {
  if (!public_key_) {
    return {};
  }
  return CreateCdpRequestFilter(std::make_shared<CdpAuthority>(
      *public_key_, port,
      std::set<std::string>{
          "chrome-extension://" + std::string(kAgentExtensionId),
          "devtools://devtools"}));
}
const std::string& BrowserPlatform::authorization() const {
  static const base::NoDestructor<std::string> empty;
  return supervisor_ ? supervisor_->authorization() : *empty;
}
}  // namespace aux
