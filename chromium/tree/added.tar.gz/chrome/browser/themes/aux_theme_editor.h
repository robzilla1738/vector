// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CHROME_BROWSER_THEMES_AUX_THEME_EDITOR_H_
#define CHROME_BROWSER_THEMES_AUX_THEME_EDITOR_H_

#include <optional>
#include <string_view>
#include <vector>

#include "base/values.h"
#include "ui/color/color_provider_key.h"

class Profile;
namespace ui { class NativeTheme; class ColorProvider; }

namespace aux_theme {
inline constexpr char kThemeTokensPref[] = "aux.theme.tokens";
inline constexpr char kThemePresetsPref[] = "aux.theme.presets";
// Space ID -> tokens. A Space without an entry follows the profile theme.
inline constexpr char kSpaceThemesPref[] = "aux.theme.spaces";

// All entry points are UI-sequence only. The extension wrapper derives owner
// from the actual document + window and calls Cancel before that owner closes,
// navigates or switches profile. Never accept an owner supplied by JavaScript.
// No operation resolves an original profile or grants profile/write authority.
// Callers must first pass the existing Aux profile admission/write boundary.
base::DictValue GetState(Profile* profile);
base::DictValue Preview(Profile* profile, std::string_view owner,
                        std::string_view revision, const base::DictValue& tokens);
base::DictValue Apply(Profile* profile, std::string_view owner,
                      std::string_view revision, const base::DictValue& tokens);
base::DictValue Cancel(Profile* profile, std::string_view owner);
base::DictValue Reset(Profile* profile, std::string_view owner,
                      std::string_view revision);
base::DictValue SavePreset(Profile* profile, std::string_view owner,
                           std::string_view revision, std::string_view name,
                           const base::DictValue& tokens);
base::DictValue DeletePreset(Profile* profile, std::string_view owner,
                             std::string_view revision, std::string_view id);
// Import uses Preview/SavePreset with the parsed export envelope's tokens.
// The wrapper bounds JSON to 4 KiB and validates envelope format/version first.
base::DictValue ExportPreset(Profile* profile, const base::DictValue& tokens);

// Native theme picker. These are trusted browser UI entry points: the picker
// is drawn by the browser, so there is no owner/revision handshake. An empty
// `space_id` is the profile theme, which Spaces without their own follow.
bool IsAvailable(Profile* profile);
// The tokens this scope shows now: the Space's own, else the profile's.
base::DictValue GetTokens(Profile* profile, std::string_view space_id);
bool HasSpaceTheme(Profile* profile, std::string_view space_id);
// Shows `tokens` in every window on `space_id` (or the profile) until
// EndPreview. Returns false when the tokens are invalid.
bool PreviewTokens(Profile* profile, std::string_view space_id,
                   const base::DictValue& tokens);
void EndPreview(Profile* profile);
// Saves the scope's tokens. For a Space, nullopt removes its own theme so it
// follows the profile again; for the profile, nullopt resets to the default.
bool SaveTokens(Profile* profile, std::string_view space_id,
                std::optional<base::DictValue> tokens);
// The first color a Space shows (its own, else the profile's), for its icon.
std::optional<SkColor> SpaceColor(Profile* profile, std::string_view space_id);

// A gradient or grain the flat frame color cannot express. Colors are already
// blended over the window base at the theme's intensity.
struct Backdrop {
  std::vector<SkColor> colors;
  float grain = 0;
};
std::optional<Backdrop> GetBackdrop(Profile* profile, std::string_view space_id,
                                    bool dark);

// The one shade a themed window shows everywhere (frame, toolbar, bubbles,
// menus, Aux's pages) in the window's mode, held to 7:1 against that mode's
// text. nullopt: the scope has no theme color.
std::optional<SkColor> GetThemeColor(Profile* profile, std::string_view space_id,
                                     bool dark);

// Actual native consumers. An unconfigured profile returns the original key,
// opacity and blur radius exactly. Private/policy/accessibility modes win.
// A window passes its active Space; other callers get the profile theme.
ui::ColorProviderKey DecorateColorProviderKey(
    const Profile* profile, ui::ColorProviderKey key,
    std::string_view space_id = {});
float MaterialOpacity(Profile* profile, const ui::NativeTheme* native_theme,
                      float original);
float MaterialBlurRadius(Profile* profile, const ui::NativeTheme* native_theme,
                         float original);
bool HasBackgroundOverride(Profile* profile, std::string_view space_id = {});
// Opt-in companion for recovered sidebar colors. Without our immutable
// supplier the exact supplied foreground is returned, including its alpha.
SkColor SidebarForeground(const ui::ColorProviderKey& key,
                          const ui::ColorProvider* provider, SkColor original);
void NotifyProfileThemeChanged(Profile* profile);
}  // namespace aux_theme
#endif  // CHROME_BROWSER_THEMES_AUX_THEME_EDITOR_H_
