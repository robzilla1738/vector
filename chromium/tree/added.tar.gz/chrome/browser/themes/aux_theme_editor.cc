// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <map>
#include "chrome/browser/themes/aux_theme_editor.h"

#include <algorithm>
#include <cmath>
#include <initializer_list>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "base/check.h"
#include "base/functional/bind.h"
#include "base/memory/weak_ptr.h"
#include "base/sequence_checker.h"
#include "base/strings/string_util.h"
#include "base/strings/stringprintf.h"
#include "base/supports_user_data.h"
#include "base/timer/timer.h"
#include "base/types/expected.h"
#include "base/uuid.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/common/pref_names.h"
#include "chrome/browser/themes/theme_service.h"
#include "chrome/browser/themes/theme_service_factory.h"
#include "chrome/browser/ui/color/chrome_color_id.h"
#include "components/prefs/pref_change_registrar.h"
#include "components/prefs/pref_service.h"
#include "components/prefs/scoped_user_pref_update.h"
#include "ui/color/color_id.h"
#include "ui/color/color_mixer.h"
#include "ui/color/color_provider.h"
#include "ui/color/color_recipe.h"
#include "ui/gfx/color_utils.h"
#include "ui/native_theme/native_theme.h"

namespace aux_theme {
namespace {
constexpr size_t kMaxPresets = 12;
constexpr char kNativeOwner[] = "aux-native-picker";
const char kEditorDataKey[] = "aux.kEditorDataKey";
// Private negative display-property ID, outside native ThemeProperties IDs.
// Existing suppliers return false for unknown properties; only our immutable
// supplier advertises custom backdrop contrast to the recovered sidebar.
constexpr int kAuxBackdropContrastProperty = -0x415558;

base::DictValue Failure(std::string_view error) {
  return base::DictValue().Set("success", false).Set("error", std::string(error));
}

std::optional<SkColor> ParseColor(std::string_view text) {
  if (text.size() != 7 || text[0] != '#')
    return std::nullopt;
  uint32_t rgb = 0;
  for (char c : text.substr(1)) {
    if (!base::IsHexDigit(c))
      return std::nullopt;
    rgb = (rgb << 4) | base::HexDigitToInt(c);
  }
  return SK_ColorBLACK | rgb;
}

base::expected<base::DictValue, std::string> Validate(
    const base::DictValue& input) {
  if (input.empty())
    return base::DictValue().Set("version", 1);
  if (input.FindInt("version") != 1)
    return base::unexpected("Unsupported theme version.");
  base::DictValue result;
  result.Set("version", 1);
  for (const auto [key, value] : input) {
    if (key == "version")
      continue;
    if (key == "accent" || key == "background" || key == "tint") {
      if (!value.is_string() || !ParseColor(value.GetString()))
        return base::unexpected("Colors must be #RRGGBB.");
      result.Set(key, base::ToUpperASCII(value.GetString()));
    } else if (key == "scheme") {
      if (!value.is_string() || (value.GetString() != "system" &&
          value.GetString() != "light" && value.GetString() != "dark"))
        return base::unexpected("Choose system, light or dark.");
      result.Set(key, value.Clone());
    } else if (key == "material") {
      if (!value.is_string() || (value.GetString() != "default" &&
          value.GetString() != "clear" && value.GetString() != "soft" &&
          value.GetString() != "opaque"))
        return base::unexpected("Unknown material.");
      if (value.GetString() != "default")
        result.Set(key, value.Clone());
    } else if (key == "tintStrength" || key == "grain") {
      // The Settings dialog stays within 0.4; Arc's intensity runs to full.
      if ((!value.is_double() && !value.is_int()) ||
          !std::isfinite(value.GetDouble()) || value.GetDouble() < 0 ||
          value.GetDouble() > 1)
        return base::unexpected("Strength and grain must be between 0 and 1.");
      result.Set(key, value.GetDouble());
    } else if (key == "colors") {
      // A gradient of two or three colors; the first is also `tint`.
      if (!value.is_list() || value.GetList().size() < 2 ||
          value.GetList().size() > 3)
        return base::unexpected("A gradient has two or three colors.");
      base::ListValue colors;
      for (const auto& color : value.GetList()) {
        if (!color.is_string() || !ParseColor(color.GetString()))
          return base::unexpected("Colors must be #RRGGBB.");
        colors.Append(base::ToUpperASCII(color.GetString()));
      }
      result.Set(key, std::move(colors));
    } else {
      return base::unexpected("Unknown theme field.");
    }
  }
  if (result.contains("tint") != result.contains("tintStrength"))
    return base::unexpected("Tint color and strength must be supplied together.");
  // A gradient starts at the tint. The Settings dialog edits only the tint and
  // keeps other fields, so a tint changed there replaces the gradient.
  if (result.contains("colors") &&
      (!result.FindString("tint") ||
       result.FindList("colors")->front().GetString() != *result.FindString("tint")))
    result.Remove("colors");
  return result;
}

// The window base the tint is laid over, as the mixer below computes it.
SkColor BaseColor(const base::DictValue& tokens, bool dark) {
  const auto* background = tokens.FindString("background");
  return background ? *ParseColor(*background)
                    : (dark ? 0xff171717u : SK_ColorWHITE);
}

// `tint` laid over a page or bubble `base` at `share` of the theme strength,
// eased back until that surface's own text (near white on dark, near black on
// light) keeps 7:1 contrast, so any theme stays comfortable to read.
SkColor ReadableTint(SkColor tint, SkColor base, double share, bool dark) {
  // The text actually drawn on it: GetColorWithMaxContrast's dark (Grey 900)
  // or light (white) color.
  const SkColor text = dark ? SK_ColorWHITE : 0xff202124u;
  for (double alpha = std::clamp(share, 0.0, 1.0); alpha > 0; alpha -= 0.03) {
    const SkColor color =
        color_utils::AlphaBlend(tint, base, static_cast<SkAlpha>(alpha * 255));
    if (color_utils::GetContrastRatio(text, color) >= 7.0f)
      return color;
  }
  // A chosen background is held to the same rule: eased toward the mode's
  // own base until its text reads.
  const SkColor mode_base = dark ? 0xff171717u : SK_ColorWHITE;
  for (double alpha = 1.0; alpha > 0; alpha -= 0.05) {
    const SkColor color =
        color_utils::AlphaBlend(base, mode_base, static_cast<SkAlpha>(alpha * 255));
    if (color_utils::GetContrastRatio(text, color) >= 7.0f)
      return color;
  }
  return mode_base;
}

// The one color a themed window shows on every surface: the frame, toolbar,
// bubbles, menus and Aux's pages. Readable for the mode's own text.
SkColor ThemeColor(const base::DictValue& tokens, bool dark);

// The flat frame color: a gradient's colors averaged, so text contrast and
// the native window color suit the whole gradient.
std::optional<SkColor> TintColor(const base::DictValue& tokens) {
  const auto* tint = tokens.FindString("tint");
  if (!tint)
    return std::nullopt;
  const auto* colors = tokens.FindList("colors");
  if (!colors)
    return ParseColor(*tint);
  int r = 0, g = 0, b = 0;
  for (const auto& value : *colors) {
    const SkColor color = *ParseColor(value.GetString());
    r += SkColorGetR(color);
    g += SkColorGetG(color);
    b += SkColorGetB(color);
  }
  const int n = static_cast<int>(colors->size());
  return SkColorSetRGB(r / n, g / n, b / n);
}

SkColor ThemeColor(const base::DictValue& tokens, bool dark) {
  const SkColor base = BaseColor(tokens, dark);
  const auto tint = TintColor(tokens);
  return tint ? ReadableTint(*tint, base,
                             tokens.FindDouble("tintStrength").value_or(0), dark)
              : base;
}

bool Available(Profile* profile) {
  return profile && !profile->IsOffTheRecord() && profile->IsRegularProfile() &&
      profile->GetPrefs()->FindPreference(kThemeTokensPref) &&
      profile->GetPrefs()->FindPreference(kThemePresetsPref) &&
      profile->GetPrefs()->FindPreference(kSpaceThemesPref) &&
      !profile->GetPrefs()->IsManagedPreference(kThemeTokensPref) &&
      !profile->GetPrefs()->IsManagedPreference(kThemePresetsPref) &&
      !ThemeServiceFactory::GetForProfile(profile)->UsingPolicyTheme();
}

// This immutable ref-counted supplier makes the complete effective theme part
// of Chromium's existing ColorProvider cache key. No mutable global profile
// lookup is hidden in a mixer, and old providers cannot acquire new tokens.
class ThemeSupplier final : public ui::ColorProviderKey::ThemeInitializerSupplier {
 public:
  ThemeSupplier(scoped_refptr<ThemeInitializerSupplier> underlying,
                const base::DictValue& tokens)
      : ThemeInitializerSupplier(underlying ? underlying->get_theme_type()
                                           : ThemeType::kAutogenerated),
        underlying_(std::move(underlying)), tokens_(tokens.Clone()) {}
  bool Matches(const scoped_refptr<ThemeInitializerSupplier>& underlying,
               const base::DictValue& tokens) const {
    return underlying_ == underlying && tokens_ == tokens;
  }
  bool GetColor(int id, SkColor* color) const override {
    return underlying_ && underlying_->GetColor(id, color);
  }
  bool GetTint(int id, color_utils::HSL* hsl) const override {
    return underlying_ && underlying_->GetTint(id, hsl);
  }
  bool GetDisplayProperty(int id, int* value) const override {
    if (id == kAuxBackdropContrastProperty &&
        (tokens_.contains("background") || tokens_.contains("tint"))) {
      *value = 1;
      return true;
    }
    return underlying_ && underlying_->GetDisplayProperty(id, value);
  }
  bool HasCustomImage(int id) const override {
    return underlying_ && underlying_->HasCustomImage(id);
  }
  void AddColorMixers(ui::ColorProvider* provider,
                     const ui::ColorProviderKey& key) const override {
    if (underlying_)
      underlying_->AddColorMixers(provider, key);
    auto& mixer = provider->AddMixer();
    const bool dark = key.color_mode == ui::ColorProviderKey::ColorMode::kDark;
    const auto* background = tokens_.FindString("background");
    const auto tint = TintColor(tokens_);
    if (background || tint) {
      // One shade everywhere, as Robert asked: the sidebar, gutter, toolbar,
      // bubbles and pages are all this color; only lines and fills step off it.
      const SkColor toolbar = ThemeColor(tokens_, dark);
      const SkColor frame = toolbar;
      const SkColor text = color_utils::GetColorWithMaxContrast(toolbar);
      const SkColor frame_text = text;
      mixer[kColorToolbar] = {toolbar};
      mixer[kColorToolbarBackgroundSubtleEmphasis] = {toolbar};
      mixer[kColorToolbarBackgroundSubtleEmphasisHovered] = {toolbar};
      mixer[kColorLocationBarBackground] = {toolbar};
      mixer[kColorLocationBarBackgroundHovered] = {toolbar};
      mixer[kColorOmniboxText] = {text};
      mixer[kColorOmniboxTextDimmed] = {SkColorSetA(text, 178)};
      mixer[kColorToolbarText] = {text};
      mixer[kColorToolbarTextDefault] = {text};
      mixer[kColorToolbarButtonText] = {text};
      mixer[kColorToolbarButtonIcon] = {text};
      mixer[kColorToolbarButtonIconDefault] = {text};
      mixer[kColorToolbarButtonIconHovered] = {text};
      mixer[kColorToolbarButtonIconPressed] = {text};
      mixer[kColorToolbarButtonIconDisabled] = {SkColorSetA(text, 97)};
      mixer[kColorToolbarButtonIconInactive] = {SkColorSetA(text, 150)};
      mixer[kColorBookmarkBarForeground] = {text};
      mixer[kColorBookmarkButtonIcon] = {text};
      mixer[ui::kColorFrameActive] = {frame};
      mixer[ui::kColorFrameInactive] = {frame};
      mixer[kColorFrameCaptionActive] = {frame_text};
      mixer[kColorFrameCaptionInactive] = {frame_text};
      mixer[kColorSidePanelBackground] = {frame};
      mixer[kColorTabBackgroundActiveFrameActive] = {toolbar};
      mixer[kColorTabBackgroundActiveFrameInactive] = {toolbar};
      mixer[kColorTabBackgroundInactiveFrameActive] = {frame};
      mixer[kColorTabBackgroundInactiveFrameInactive] = {frame};
      mixer[kColorTabForegroundActiveFrameActive] = {text};
      mixer[kColorTabForegroundActiveFrameInactive] = {text};
      mixer[kColorTabForegroundInactiveFrameActive] = {frame_text};
      mixer[kColorTabForegroundInactiveFrameInactive] = {frame_text};
      // Keyboard focus remains visible even with a very pale/dark custom tint.
      mixer[ui::kColorFocusableBorderFocused] = {text};
    }
    // Bubbles, dropdowns, menus and dialogs over this window are the same
    // shade; their borders and every divider are its readable ink, faint, so
    // lines carry the hue and never vanish into it.
    if (background || tint) {
      const SkColor surface = ThemeColor(tokens_, dark);
      // Chromium's own surfaces too (the URL dropdown, hover cards, the find
      // bar, page info), so none of them shows a palette derived from the accent.
      for (ui::ColorId id : std::initializer_list<ui::ColorId>{ui::kColorSysSurface,
                             ui::kColorSysSurface1, ui::kColorSysSurface2,
                             ui::kColorSysSurface3, ui::kColorSysSurface4,
                             ui::kColorSysSurface5, ui::kColorSysBase,
                             ui::kColorSysBaseContainer, ui::kColorSysBaseContainerElevated,
                             ui::kColorBubbleBackground,
                             ui::kColorBubbleFooterBackground,
                             ui::kColorDialogBackground, ui::kColorMenuBackground,
                             kColorSidePanelBackground, kColorOmniboxResultsBackground,
                             kColorFindBarBackground, kColorTabHoverCardBackground})
        mixer[id] = {surface};
      mixer[kColorOmniboxResultsBackgroundHovered] = {
          color_utils::AlphaBlend(color_utils::GetColorWithMaxContrast(surface), surface,
                                  static_cast<SkAlpha>(0.12 * 255))};
      const SkColor ink = color_utils::GetColorWithMaxContrast(surface);
      for (ui::ColorId id : std::initializer_list<ui::ColorId>{ui::kColorSeparator, ui::kColorSysDivider,
                             ui::kColorMenuSeparator, ui::kColorSysTonalOutline,
                             ui::kColorSysNeutralOutline, kColorToolbarSeparator,
                             kColorToolbarSeparatorDefault,
                             kColorToolbarContentAreaSeparator,
                             kColorSidePanelContentAreaSeparator})
        mixer[id] = {SkColorSetA(ink, 0x29)};
      // In a split the pane you're working in is plain to see; the others
      // keep the faint line.
      mixer[kColorMultiContentsViewActiveContentOutline] = {SkColorSetA(ink, 0x80)};
      mixer[kColorMultiContentsViewInactiveContentOutline] = {SkColorSetA(ink, 0x1a)};
      mixer[ui::kColorBubbleBorder] = {SkColorSetA(ink, 0x33)};
    }
    if (const auto* accent = tokens_.FindString("accent"))
      mixer[ui::kColorAccent] = {*ParseColor(*accent)};
  }
 private:
  ~ThemeSupplier() override = default;
  const scoped_refptr<ThemeInitializerSupplier> underlying_;
  const base::DictValue tokens_;
};

class Editor final : public base::SupportsUserData::Data {
 public:
  explicit Editor(Profile* profile) : profile_(profile->GetWeakPtr()) {
    registrar_.Init(profile_->GetPrefs());
    for (const char* pref : {kThemeTokensPref, kThemePresetsPref,
                             kSpaceThemesPref, prefs::kBrowserColorScheme}) {
      registrar_.Add(pref, base::BindRepeating(&Editor::ExternalChange,
                                              base::Unretained(this)));
    }
    for (const char* pref : {prefs::kUserColor, prefs::kCurrentThemeID}) {
      registrar_.Add(pref, base::BindRepeating(&Editor::ExternalAccentChange,
                                              base::Unretained(this)));
    }
  }
  ~Editor() override = default;
  base::WeakPtr<Editor> GetWeakPtr() { return weak_factory_.GetWeakPtr(); }
  // Painting asks for the backdrop on every frame; it only changes when the
  // theme does, so it's computed once per Space and mode until then.
  std::optional<Backdrop>* CachedBackdrop(std::string_view space, bool dark) {
    const auto found = backdrops_.find({std::string(space), dark});
    return found == backdrops_.end() ? nullptr : &found->second;
  }
  void CacheBackdrop(std::string_view space, bool dark, std::optional<Backdrop> backdrop) {
    backdrops_[{std::string(space), dark}] = std::move(backdrop);
  }
  void InvalidateBackdrops() { backdrops_.clear(); }
  Profile* profile() const { return profile_.get(); }
  base::DictValue Saved() const {
    auto valid = Validate(profile_->GetPrefs()->GetDict(kThemeTokensPref));
    auto result = valid.has_value() ? std::move(*valid)
                                   : base::DictValue().Set("version", 1);
    // Existing Appearance controls and installed themes remain authoritative.
    // Do not replay old Aux scheme/accent copies over later native changes.
    auto* theme = ThemeServiceFactory::GetForProfile(profile_.get());
    if (result.contains("scheme")) {
      const auto scheme = theme->GetBrowserColorScheme();
      result.Set("scheme", scheme == ThemeService::BrowserColorScheme::kDark
          ? "dark" : scheme == ThemeService::BrowserColorScheme::kLight
          ? "light" : "system");
    }
    // Accent is a scoped ColorProvider overlay, never a destructive native
    // ThemeService user-color write. Removing it exposes the actual current
    // profile theme, including an installed extension theme, after restart.
    return result;
  }
  std::optional<base::DictValue> SpaceSaved(std::string_view space) const {
    if (space.empty())
      return std::nullopt;
    const auto* saved =
        profile_->GetPrefs()->GetDict(kSpaceThemesPref).FindDict(space);
    if (!saved)
      return std::nullopt;
    auto valid = Validate(*saved);
    return valid.has_value() ? std::make_optional(std::move(*valid))
                             : std::nullopt;
  }
  // A Space shows its own preview or theme; without one, the profile's.
  base::DictValue Effective(std::string_view space = {}) const {
    if (!space.empty()) {
      if (preview_ && preview_scope_ == space)
        return preview_->Clone();
      if (auto saved = SpaceSaved(space))
        return std::move(*saved);
    }
    return preview_ && preview_scope_.empty() ? preview_->Clone() : Saved();
  }
  base::ListValue Presets() const {
    base::ListValue result;
    for (const auto& value : profile_->GetPrefs()->GetList(kThemePresetsPref)) {
      if (!value.is_dict() || result.size() >= kMaxPresets)
        continue;
      const auto& preset = value.GetDict();
      const auto* name = preset.FindString("name");
      const auto* id = preset.FindString("id");
      const auto* tokens = preset.FindDict("tokens");
      if (!name || name->empty() || name->size() > 64 || !id ||
          !base::Uuid::ParseLowercase(*id).is_valid() || !tokens)
        continue;
      auto valid = Validate(*tokens);
      if (valid.has_value()) {
        result.Append(base::DictValue().Set("id", *id).Set("name", *name)
                          .Set("tokens", std::move(*valid)));
      }
    }
    return result;
  }
  base::DictValue State() const {
    DCHECK_CALLED_ON_VALID_SEQUENCE(sequence_);
    auto* theme = ThemeServiceFactory::GetForProfile(profile_.get());
    return base::DictValue().Set("success", true).Set("revision", revision_)
        .Set("tokens", Saved()).Set("effectiveTokens", Effective())
        .Set("presets", Presets()).Set("previewing", preview_.has_value())
        .Set("nativeScheme", static_cast<int>(theme->GetBrowserColorScheme()))
        .Set("reducedTransparency", ui::NativeTheme::GetInstanceForNativeUi()
                                        ->prefers_reduced_transparency())
        .Set("highContrast", ui::NativeTheme::GetInstanceForNativeUi()
            ->preferred_contrast() == ui::NativeTheme::PreferredContrast::kMore);
  }
  bool Matches(std::string_view owner, std::string_view revision) const {
    DCHECK_CALLED_ON_VALID_SEQUENCE(sequence_);
    return !writing_ && !owner.empty() && owner.size() <= 256 && revision == revision_ &&
        (owner_.empty() || owner_ == owner);
  }
  void SetPreview(std::string_view owner, base::DictValue tokens) {
    DCHECK_CALLED_ON_VALID_SEQUENCE(sequence_);
    owner_ = owner;
    preview_scope_.clear();
    preview_ = std::move(tokens);
    timer_.Start(FROM_HERE, base::Minutes(2),
                 base::BindOnce(&Editor::Expire, base::Unretained(this)));
    if (profile_)
      NotifyProfileThemeChanged(profile_.get());
  }
  // The native picker ends its own preview when it closes, so no expiry.
  void SetNativePreview(std::string_view scope, base::DictValue tokens) {
    DCHECK_CALLED_ON_VALID_SEQUENCE(sequence_);
    timer_.Stop();
    owner_ = kNativeOwner;
    preview_scope_ = scope;
    preview_ = std::move(tokens);
    if (profile_)
      NotifyProfileThemeChanged(profile_.get());
  }
  bool NativePreviewing() const { return preview_ && owner_ == kNativeOwner; }
  void ClearPreview() {
    owner_.clear();
    preview_scope_.clear();
    preview_.reset();
    timer_.Stop();
  }
  void WriteSpace(std::string_view space, std::optional<base::DictValue> tokens) {
    const auto alive = weak_factory_.GetWeakPtr();
    ClearPreview();
    writing_ = true;
    {
      ScopedDictPrefUpdate update(profile_->GetPrefs(), kSpaceThemesPref);
      if (tokens)
        update->Set(space, std::move(*tokens));
      else
        update->Remove(space);
    }
    if (!alive)
      return;
    writing_ = false;
    Changed();
  }
  void Expire() {
    ClearPreview();
    if (profile_)
      NotifyProfileThemeChanged(profile_.get());
  }
  bool Owns(std::string_view owner) const { return owner_ == owner; }
  void WriteTokens(base::DictValue tokens, bool reset = false) {
    const auto alive = weak_factory_.GetWeakPtr();
    ClearPreview();
    writing_ = true;
    auto* theme = ThemeServiceFactory::GetForProfile(profile_.get());
    if (reset) {
      // Reset clears Aux's own theme only; an installed Chromium or extension
      // theme the person chose stays.
      theme->SetBrowserColorScheme(ThemeService::BrowserColorScheme::kSystem);
    } else {
      if (const auto* scheme = tokens.FindString("scheme")) {
        theme->SetBrowserColorScheme(*scheme == "dark"
            ? ThemeService::BrowserColorScheme::kDark : *scheme == "light"
            ? ThemeService::BrowserColorScheme::kLight
            : ThemeService::BrowserColorScheme::kSystem);
      }
      // Keep the underlying profile theme intact. DecorateColorProviderKey
      // applies this optional accent for preview and committed tokens alike.
    }
    if (!alive || !profile_)
      return;
    if (!Available(profile_.get())) {
      writing_ = false;
      return;
    }
    profile_->GetPrefs()->SetDict(kThemeTokensPref, std::move(tokens));
    if (!alive)
      return;
    writing_ = false;
    Changed();
  }
  void WritePresets(base::ListValue presets) {
    const auto alive = weak_factory_.GetWeakPtr();
    writing_ = true;
    profile_->GetPrefs()->SetList(kThemePresetsPref, std::move(presets));
    if (!alive)
      return;
    writing_ = false;
    revision_ = base::Uuid::GenerateRandomV4().AsLowercaseString();
  }
  scoped_refptr<ThemeSupplier> Supplier(
      scoped_refptr<ui::ColorProviderKey::ThemeInitializerSupplier> underlying,
      const base::DictValue& tokens) {
    // This editor belongs to a profile, not one window. An installed web app
    // and a normal browser may use distinct native theme suppliers; retain
    // both immutable wrappers so alternating key lookups keep stable identity.
    // The small LRU also bounds retained preview tokens and underlying themes.
    constexpr size_t kMaxCachedSuppliers = 16;
    for (size_t i = 0; i < suppliers_.size(); ++i) {
      if (suppliers_[i]->Matches(underlying, tokens)) {
        auto supplier = suppliers_[i];
        suppliers_.erase(suppliers_.begin() + i);
        suppliers_.push_back(supplier);
        return supplier;
      }
    }
    auto supplier = base::MakeRefCounted<ThemeSupplier>(std::move(underlying), tokens);
    if (suppliers_.size() == kMaxCachedSuppliers)
      suppliers_.erase(suppliers_.begin());
    suppliers_.push_back(supplier);
    return supplier;
  }
 private:
  void Changed() {
    revision_ = base::Uuid::GenerateRandomV4().AsLowercaseString();
    if (profile_)
      NotifyProfileThemeChanged(profile_.get());
  }
  void ExternalChange() {
    InvalidateBackdrops();
    if (writing_)
      return;
    ClearPreview();
    Changed();
  }
  void ExternalAccentChange() {
    InvalidateBackdrops();
    if (writing_)
      return;
    // A later choice through Chromium's existing Appearance/theme controls
    // takes precedence. Retire only our accent override, preserving unrelated
    // Aux background/material tokens and every native theme preference.
    auto tokens = profile_->GetPrefs()->GetDict(kThemeTokensPref).Clone();
    if (tokens.Remove("accent")) {
      const auto alive = weak_factory_.GetWeakPtr();
      writing_ = true;
      profile_->GetPrefs()->SetDict(kThemeTokensPref, std::move(tokens));
      if (!alive)
        return;
      writing_ = false;
    }
    ExternalChange();
  }
  const base::WeakPtr<Profile> profile_;
  std::string revision_ = base::Uuid::GenerateRandomV4().AsLowercaseString();
  std::string owner_;
  // Empty: the profile theme. Otherwise the one Space being previewed.
  std::string preview_scope_;
  std::optional<base::DictValue> preview_;
  base::OneShotTimer timer_;
  bool writing_ = false;
  std::vector<scoped_refptr<ThemeSupplier>> suppliers_;
  PrefChangeRegistrar registrar_;
  SEQUENCE_CHECKER(sequence_);
  std::map<std::pair<std::string, bool>, std::optional<Backdrop>> backdrops_;
  base::WeakPtrFactory<Editor> weak_factory_{this};
};

base::DictValue StateAfterChange(const base::WeakPtr<Editor>& editor) {
  if (!editor || !editor->profile())
    return Failure("The theme editor's profile closed before completion.");
  if (!Available(editor->profile()))
    return Failure("Theme editing is no longer available in this profile.");
  return editor->State();
}

Editor& GetEditor(Profile* profile) {
  auto* editor = static_cast<Editor*>(profile->GetUserData(&kEditorDataKey));
  if (!editor) {
    auto data = std::make_unique<Editor>(profile);
    editor = data.get();
    profile->SetUserData(&kEditorDataKey, std::move(data));
  }
  return *editor;
}

std::string Material(Profile* profile, const ui::NativeTheme* native_theme) {
  if (!Available(profile) || !native_theme)
    return "default";
  if (native_theme->preferred_contrast() == ui::NativeTheme::PreferredContrast::kMore ||
      native_theme->prefers_reduced_transparency())
    return "opaque";
  const auto tokens = GetEditor(profile).Effective();
  const auto* material = tokens.FindString("material");
  return material ? *material : "default";
}
}  // namespace

base::DictValue GetState(Profile* profile) {
  return Available(profile) ? GetEditor(profile).State()
                            : Failure("Theme editing is unavailable in this profile.");
}

base::DictValue Preview(Profile* profile, std::string_view owner,
                        std::string_view revision, const base::DictValue& tokens) {
  if (!Available(profile))
    return Failure("Theme editing is unavailable in this profile.");
  auto& editor = GetEditor(profile);
  if (!editor.Matches(owner, revision))
    return Failure("Theme changed or another window is previewing. Reopen the editor.");
  auto valid = Validate(tokens);
  if (!valid.has_value())
    return Failure(valid.error());
  const auto alive = editor.GetWeakPtr();
  editor.SetPreview(owner, std::move(*valid));
  return StateAfterChange(alive);
}

base::DictValue Apply(Profile* profile, std::string_view owner,
                      std::string_view revision, const base::DictValue& tokens) {
  if (!Available(profile))
    return Failure("Theme editing is unavailable in this profile.");
  auto& editor = GetEditor(profile);
  if (!editor.Matches(owner, revision))
    return Failure("Theme changed or another window is previewing. Reopen the editor.");
  auto valid = Validate(tokens);
  if (!valid.has_value())
    return Failure(valid.error());
  const auto alive = editor.GetWeakPtr();
  editor.WriteTokens(std::move(*valid));
  return StateAfterChange(alive);
}

base::DictValue Cancel(Profile* profile, std::string_view owner) {
  if (!profile)
    return Failure("Theme editing is unavailable in this profile.");
  // Revocation is not a preference write. Policy/accessibility/profile changes
  // must not leave an old preview waiting to resurrect when editing returns.
  auto* editor = static_cast<Editor*>(profile->GetUserData(&kEditorDataKey));
  if (!editor)
    return GetState(profile);
  const auto alive = editor->GetWeakPtr();
  if (!owner.empty() && editor->Owns(owner))
    editor->Expire();
  return StateAfterChange(alive);
}

base::DictValue Reset(Profile* profile, std::string_view owner,
                      std::string_view revision) {
  if (!Available(profile))
    return Failure("Theme editing is unavailable in this profile.");
  auto& editor = GetEditor(profile);
  if (!editor.Matches(owner, revision))
    return Failure("Theme changed or another window is previewing. Reopen the editor.");
  const auto alive = editor.GetWeakPtr();
  editor.WriteTokens(base::DictValue().Set("version", 1), true);
  return StateAfterChange(alive);
}

base::DictValue SavePreset(Profile* profile, std::string_view owner,
                           std::string_view revision, std::string_view name,
                           const base::DictValue& tokens) {
  if (!Available(profile))
    return Failure("Theme editing is unavailable in this profile.");
  auto& editor = GetEditor(profile);
  if (!editor.Matches(owner, revision))
    return Failure("Theme changed or another window is previewing. Reopen the editor.");
  std::string trimmed;
  base::TrimWhitespaceASCII(name, base::TRIM_ALL, &trimmed);
  if (trimmed.empty() || trimmed.size() > 64 ||
      std::ranges::any_of(trimmed, [](unsigned char c) { return c < 32; }))
    return Failure("Preset name must contain 1–64 bytes with no control characters.");
  auto valid = Validate(tokens);
  if (!valid.has_value())
    return Failure(valid.error());
  auto presets = editor.Presets();
  if (presets.size() >= kMaxPresets)
    return Failure("Remove a preset before adding another (maximum 12).");
  presets.Append(base::DictValue()
      .Set("id", base::Uuid::GenerateRandomV4().AsLowercaseString())
      .Set("name", trimmed).Set("tokens", std::move(*valid)));
  const auto alive = editor.GetWeakPtr();
  editor.WritePresets(std::move(presets));
  return StateAfterChange(alive);
}

base::DictValue DeletePreset(Profile* profile, std::string_view owner,
                             std::string_view revision, std::string_view id) {
  if (!Available(profile))
    return Failure("Theme editing is unavailable in this profile.");
  auto& editor = GetEditor(profile);
  if (!editor.Matches(owner, revision))
    return Failure("Theme changed or another window is previewing. Reopen the editor.");
  auto presets = editor.Presets();
  presets.EraseIf([id](const base::Value& value) {
    const auto* saved = value.GetDict().FindString("id");
    return saved && *saved == id;
  });
  const auto alive = editor.GetWeakPtr();
  editor.WritePresets(std::move(presets));
  return StateAfterChange(alive);
}

base::DictValue ExportPreset(Profile* profile, const base::DictValue& tokens) {
  if (!Available(profile))
    return Failure("Theme editing is unavailable in this profile.");
  auto valid = Validate(tokens);
  if (!valid.has_value())
    return Failure(valid.error());
  return base::DictValue().Set("success", true).Set("preset",
      base::DictValue().Set("format", "aux-theme").Set("version", 1)
          .Set("tokens", std::move(*valid)));
}

bool IsAvailable(Profile* profile) {
  return Available(profile);
}

base::DictValue GetTokens(Profile* profile, std::string_view space_id) {
  if (!Available(profile))
    return base::DictValue().Set("version", 1);
  auto& editor = GetEditor(profile);
  if (auto saved = editor.SpaceSaved(space_id))
    return std::move(*saved);
  return editor.Saved();
}

bool HasSpaceTheme(Profile* profile, std::string_view space_id) {
  return Available(profile) && GetEditor(profile).SpaceSaved(space_id);
}

bool PreviewTokens(Profile* profile, std::string_view space_id,
                   const base::DictValue& tokens) {
  if (!Available(profile))
    return false;
  auto valid = Validate(tokens);
  if (!valid.has_value())
    return false;
  GetEditor(profile).SetNativePreview(space_id, std::move(*valid));
  return true;
}

void EndPreview(Profile* profile) {
  auto* editor = profile ? static_cast<Editor*>(profile->GetUserData(&kEditorDataKey))
                         : nullptr;
  if (editor && editor->NativePreviewing())
    editor->Expire();
}

bool SaveTokens(Profile* profile, std::string_view space_id,
                std::optional<base::DictValue> tokens) {
  if (!Available(profile))
    return false;
  if (tokens) {
    auto valid = Validate(*tokens);
    if (!valid.has_value())
      return false;
    tokens = std::move(*valid);
  }
  auto& editor = GetEditor(profile);
  if (!space_id.empty())
    editor.WriteSpace(space_id, std::move(tokens));
  else if (tokens)
    editor.WriteTokens(std::move(*tokens));
  else
    editor.WriteTokens(base::DictValue().Set("version", 1), /*reset=*/true);
  return true;
}

std::optional<SkColor> SpaceColor(Profile* profile, std::string_view space_id) {
  if (!Available(profile))
    return std::nullopt;
  const auto tokens = GetEditor(profile).Effective(space_id);
  const auto* tint = tokens.FindString("tint");
  if (!tint || tokens.FindDouble("tintStrength").value_or(0) <= 0)
    return std::nullopt;
  return ParseColor(*tint);
}

std::optional<Backdrop> ComputeBackdrop(const base::DictValue& tokens, bool dark);

std::optional<Backdrop> GetBackdrop(Profile* profile, std::string_view space_id,
                                    bool dark) {
  if (!Available(profile))
    return std::nullopt;
  auto& editor = GetEditor(profile);
  if (auto* cached = editor.CachedBackdrop(space_id, dark)) return *cached;
  auto backdrop = ComputeBackdrop(editor.Effective(space_id), dark);
  editor.CacheBackdrop(space_id, dark, backdrop);
  return backdrop;
}

std::optional<Backdrop> ComputeBackdrop(const base::DictValue& tokens, bool dark) {
  Backdrop backdrop;
  backdrop.grain = static_cast<float>(tokens.FindDouble("grain").value_or(0));
  const SkColor base = BaseColor(tokens, dark);
  const double strength = tokens.FindDouble("tintStrength").value_or(0);
  if (const auto* colors = tokens.FindList("colors")) {
    // Each stop is held to the same contrast as the flat theme color.
    for (const auto& color : *colors)
      backdrop.colors.push_back(
          ReadableTint(*ParseColor(color.GetString()), base, strength, dark));
  }
  if (backdrop.colors.empty() && backdrop.grain <= 0)
    return std::nullopt;
  return backdrop;
}

std::optional<SkColor> GetThemeColor(Profile* profile, std::string_view space_id,
                                     bool dark) {
  if (!Available(profile))
    return std::nullopt;
  const auto tokens = GetEditor(profile).Effective(space_id);
  if (!tokens.contains("tint") && !tokens.contains("background"))
    return std::nullopt;
  return ThemeColor(tokens, dark);
}

ui::ColorProviderKey DecorateColorProviderKey(
    const Profile* profile, ui::ColorProviderKey key,
    std::string_view space_id) {
  auto* mutable_profile = const_cast<Profile*>(profile);
  if (!Available(mutable_profile) ||
      key.contrast_mode != ui::ColorProviderKey::ContrastMode::kNormal ||
      key.forced_colors != ui::ColorProviderKey::ForcedColors::kNone)
    return key;
  auto& editor = GetEditor(mutable_profile);
  const auto tokens = editor.Effective(space_id);
  if (const auto* scheme = tokens.FindString("scheme")) {
    key.color_mode = *scheme == "system"
        ? ui::NativeTheme::GetInstanceForNativeUi()->GetColorProviderKey(nullptr).color_mode
        : *scheme == "dark" ? ui::ColorProviderKey::ColorMode::kDark
                             : ui::ColorProviderKey::ColorMode::kLight;
  }
  if (const auto* accent = tokens.FindString("accent")) {
    key.user_color = ParseColor(*accent);
    key.user_color_source = ui::ColorProviderKey::UserColorSource::kAccent;
  }
  if (tokens.contains("accent") || tokens.contains("background") || tokens.contains("tint"))
    key.custom_theme = editor.Supplier(key.custom_theme, tokens);
  return key;
}

float MaterialOpacity(Profile* profile, const ui::NativeTheme* native_theme,
                      float original) {
  // Never turn an opaque native surface into glass or change invisible cutouts.
  if (original <= 0 || original >= 1)
    return original;
  const std::string material = Material(profile, native_theme);
  if (material == "opaque") return 1;
  if (material == "clear") return std::clamp(original * 0.75f, 0.1f, 1.0f);
  if (material == "soft") return std::clamp(original * 1.2f, 0.1f, 1.0f);
  return original;
}

float MaterialBlurRadius(Profile* profile, const ui::NativeTheme* native_theme,
                         float original) {
  const std::string material = Material(profile, native_theme);
  if (material == "opaque") return 0;
  if (material == "clear") return original * 0.6f;
  if (material == "soft") return original * 1.4f;
  return original;
}

bool HasBackgroundOverride(Profile* profile, std::string_view space_id) {
  if (!Available(profile)) return false;
  const auto tokens = GetEditor(profile).Effective(space_id);
  return tokens.contains("background") || tokens.contains("tint");
}

SkColor SidebarForeground(const ui::ColorProviderKey& key,
                          const ui::ColorProvider* provider, SkColor original) {
  int enabled = 0;
  if (!provider || !key.custom_theme ||
      key.contrast_mode != ui::ColorProviderKey::ContrastMode::kNormal ||
      key.forced_colors != ui::ColorProviderKey::ForcedColors::kNone ||
      !key.custom_theme->GetDisplayProperty(kAuxBackdropContrastProperty, &enabled) ||
      enabled != 1)
    return original;
  const SkColor background = provider->GetColor(ui::kColorFrameActive);
  const SkColor foreground = color_utils::GetColorWithMaxContrast(background);
  int alpha = SkColorGetA(original);
  // Low-opacity hover fills/dividers retain their supplied subtlety. Text and
  // glyph opacity increases only as needed for readable custom colors.
  if (alpha >= 0x70) {
    while (alpha < 255 && color_utils::GetContrastRatio(
        color_utils::AlphaBlend(foreground, background, static_cast<SkAlpha>(alpha)),
        background) < 4.5f)
      alpha = std::min(255, alpha + 8);
  }
  return SkColorSetA(foreground, alpha);
}

void NotifyProfileThemeChanged(Profile* profile) {
  GetEditor(profile).InvalidateBackdrops();
  ThemeServiceFactory::GetForProfile(profile)->NotifyThemeChanged();
}
}  // namespace aux_theme
