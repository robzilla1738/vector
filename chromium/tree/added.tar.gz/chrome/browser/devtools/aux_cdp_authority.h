// Copyright 2026 Aux Authors. All rights reserved.
// Independent native CDP authorization, platform.md P4.
#ifndef CHROME_BROWSER_DEVTOOLS_AUX_CDP_AUTHORITY_H_
#define CHROME_BROWSER_DEVTOOLS_AUX_CDP_AUTHORITY_H_
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>

#include "base/functional/callback.h"
#include "base/synchronization/lock.h"
#include "base/time/time.h"
#include "crypto/keypair.h"
#include "net/server/http_server_request_info.h"
#include "net/server/http_server_response_info.h"
namespace aux {
struct CdpResponse {
  int status;
  std::string body;
  std::string mime_type = "application/json";
};
// Construct with a key loaded on a MayBlock worker. Safe on server or UI
// sequence.
class CdpAuthority {
 public:
  CdpAuthority(crypto::keypair::PublicKey key,
               uint16_t port,
               std::set<std::string> origins);
  ~CdpAuthority();
  // nullopt means authorized; a response must be sent before ordinary routing.
  std::optional<CdpResponse> Filter(const net::HttpServerRequestInfo& request,
                                    bool websocket);

 private:
  struct Challenge {
    std::string bytes;
    base::TimeTicks expires;
  };
  void Prune(base::TimeTicks now) EXCLUSIVE_LOCKS_REQUIRED(lock_);
  const crypto::keypair::PublicKey key_;
  const uint16_t port_;
  const std::set<std::string> origins_;
  base::Lock lock_;
  std::map<std::string, Challenge> challenges_ GUARDED_BY(lock_);
  std::map<std::string, base::TimeTicks> sessions_ GUARDED_BY(lock_);
};
using CdpRequestFilter = base::RepeatingCallback<std::optional<
    net::HttpServerResponseInfo>(const net::HttpServerRequestInfo&, bool)>;
CdpRequestFilter CreateCdpRequestFilter(
    std::shared_ptr<CdpAuthority> authority);
}  // namespace aux
#endif
