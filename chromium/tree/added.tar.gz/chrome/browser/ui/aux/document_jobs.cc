// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#include "chrome/browser/ui/aux/document_jobs.h"

#include <algorithm>
#include <array>
#include <optional>
#include <utility>
#include <vector>

#include "build/build_config.h"
#if BUILDFLAG(IS_POSIX)
#include <sys/stat.h>
#endif

#include "base/base64.h"
#include "base/containers/span.h"
#include "base/files/file.h"
#include "base/functional/bind.h"
#include "base/memory/ref_counted.h"
#include "base/memory/shared_memory_mapping.h"
#include "base/memory/weak_ptr.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/strings/string_view_util.h"
#include "base/task/thread_pool.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "base/unguessable_token.h"
#include "chrome/services/aux_document/public/mojom/document_extractor.mojom.h"
#include "content/public/browser/service_process_host.h"
#include "content/public/browser/service_process_info.h"
#include "crypto/hash.h"
#include "mojo/public/cpp/bindings/remote.h"
namespace aux {
namespace {
constexpr size_t kSourceLimit = 64 * 1024 * 1024;
constexpr size_t kOutputLimit = 32 * 1024 * 1024;
constexpr size_t kChunkLimit = 256 * 1024;
using Reply = base::OnceCallback<void(base::DictValue)>;
base::DictValue Fault(std::string code, std::string message) {
  return base::DictValue().Set("error",
                               base::DictValue()
                                   .Set("code", std::move(code))
                                   .Set("message", std::move(message)));
}
base::DictValue Result(base::DictValue value) {
  return base::DictValue().Set("result", std::move(value));
}
std::string Hash(base::span<const uint8_t> bytes) {
  return base::HexEncodeLower(crypto::hash::Sha256(bytes));
}
struct Source {
  size_t size = 0;
  size_t received = 0;
  std::string hash;
  std::string media_type;
  std::vector<std::string> chunks;
};
struct Prepared {
  std::vector<document::mojom::JobSourcePtr> sources;
  std::string failure;
};
Prepared Prepare(std::vector<Source> sources,
                 std::shared_ptr<std::atomic_bool> cancelled) {
  Prepared result;
  for (auto& source : sources) {
    if (cancelled->load()) {
      result.failure = "Original job cancelled";
      return result;
    }
    auto memory = base::ReadOnlySharedMemoryRegion::Create(source.size);
    if (!memory.IsValid()) {
      result.failure = "Source allocation failed";
      return result;
    }
    auto target = memory.mapping.GetMemoryAsSpan<uint8_t>();
    size_t offset = 0;
    for (auto& chunk : source.chunks) {
      target.subspan(offset, chunk.size()).copy_from(base::as_byte_span(chunk));
      offset += chunk.size();
      std::fill(chunk.begin(), chunk.end(), 0);
    }
    if (offset != source.size || Hash(target) != source.hash) {
      result.failure = "Original source bytes do not match their admitted hash";
      return result;
    }
    auto admitted = document::mojom::JobSource::New();
    admitted->source = std::move(memory.region);
    admitted->size = source.size;
    admitted->sha256 = source.hash;
    admitted->media_type = source.media_type;
    result.sources.push_back(std::move(admitted));
  }
  return result;
}
struct CapturedDownload {
  base::ReadOnlySharedMemoryMapping bytes;
  size_t size = 0;
  std::string sha256;
  std::string media_type;
  std::string failure;
};
bool SameDownload(const NativeDownloadFile& a, const NativeDownloadFile& b) {
  return a.state == NativeDownloadFile::State::kReady &&
         b.state == NativeDownloadFile::State::kReady && a.path == b.path &&
         a.size == b.size && a.filename == b.filename &&
         a.native_sha256 == b.native_sha256;
}
std::string DownloadMime(base::span<const uint8_t> bytes) {
  const auto starts = [&](std::string_view signature) {
    return bytes.size() >= signature.size() &&
           std::ranges::equal(bytes.first(signature.size()),
                              base::as_byte_span(signature));
  };
  const std::string_view prefix(reinterpret_cast<const char*>(bytes.data()),
                                std::min<size_t>(1024, bytes.size()));
  if (prefix.find("%PDF-") != std::string_view::npos)
    return "application/pdf";
  constexpr std::array<uint8_t, 8> png = {137, 80, 78, 71, 13, 10, 26, 10};
  if (bytes.size() >= png.size() &&
      std::ranges::equal(bytes.first(png.size()), png))
    return "image/png";
  if (bytes.size() >= 3 && bytes[0] == 0xff && bytes[1] == 0xd8 &&
      bytes[2] == 0xff)
    return "image/jpeg";
  if (bytes.size() >= 12 && starts("RIFF") &&
      std::ranges::equal(bytes.subspan(8u, 4u),
                         base::as_byte_span(std::string_view("WEBP"))))
    return "image/webp";
  if (bytes.size() >= 4 && bytes[0] == 'P' && bytes[1] == 'K' &&
      bytes[2] == 3 && bytes[3] == 4)
    return "application/zip";
  const std::string_view text(reinterpret_cast<const char*>(bytes.data()),
                              bytes.size());
  if (text.find('\0') == std::string_view::npos &&
      base::IsStringUTF8AllowingNoncharacters(text))
    return "text/plain";
  return "application/octet-stream";
}
CapturedDownload CaptureDownload(NativeDownloadFile original,
                                 base::TimeTicks deadline,
                                 std::shared_ptr<std::atomic_bool> cancelled) {
  CapturedDownload result;
#if BUILDFLAG(IS_POSIX)
  if (original.size < 0 || original.size > static_cast<int64_t>(kSourceLimit) ||
      cancelled->load() || base::TimeTicks::Now() >= deadline) {
    result.failure =
        "Original download capture is cancelled, expired or oversized";
    return result;
  }
  base::File file(original.path, base::File::FLAG_OPEN | base::File::FLAG_READ |
                                     base::File::FLAG_NO_FOLLOW);
  struct stat before, after, published;
  if (!file.IsValid() || fstat(file.GetPlatformFile(), &before) != 0 ||
      !S_ISREG(before.st_mode) || before.st_size != original.size) {
    result.failure = "Original download is not the expected regular local file";
    return result;
  }
  auto memory = base::ReadOnlySharedMemoryRegion::Create(
      std::max<size_t>(1, static_cast<size_t>(original.size)));
  if (!memory.IsValid()) {
    result.failure = "Download capture allocation failed";
    return result;
  }
  auto bytes = memory.mapping.GetMemoryAsSpan<uint8_t>().first(static_cast<size_t>(original.size));
  size_t offset = 0;
  while (offset < bytes.size()) {
    if (cancelled->load() || base::TimeTicks::Now() >= deadline) {
      result.failure = "Original download capture cancelled or expired";
      return result;
    }
    const auto count = file.ReadAtCurrentPos(
        bytes.subspan(offset, std::min(kChunkLimit, bytes.size() - offset)));
    if (!count || !*count) {
      result.failure = "Original download bytes are incomplete";
      return result;
    }
    offset += *count;
  }
  base::File current(original.path, base::File::FLAG_OPEN |
                                        base::File::FLAG_READ |
                                        base::File::FLAG_NO_FOLLOW);
  const auto same = [](const struct stat& a, const struct stat& b) {
    return S_ISREG(b.st_mode) && a.st_dev == b.st_dev && a.st_ino == b.st_ino &&
           a.st_size == b.st_size && a.st_mtime == b.st_mtime &&
           a.st_ctime == b.st_ctime
#if BUILDFLAG(IS_APPLE)
           && a.st_mtimespec.tv_nsec == b.st_mtimespec.tv_nsec &&
           a.st_ctimespec.tv_nsec == b.st_ctimespec.tv_nsec
#else
           && a.st_mtim.tv_nsec == b.st_mtim.tv_nsec &&
           a.st_ctim.tv_nsec == b.st_ctim.tv_nsec
#endif
        ;
  };
  if (!current.IsValid() || fstat(file.GetPlatformFile(), &after) != 0 ||
      fstat(current.GetPlatformFile(), &published) != 0 ||
      !same(before, after) || !same(before, published) || cancelled->load() ||
      base::TimeTicks::Now() >= deadline) {
    result.failure = "Original download file changed during immutable capture";
    return result;
  }
  result.sha256 = Hash(bytes);
  if (!original.native_sha256.empty() &&
      result.sha256 != original.native_sha256) {
    result.failure =
        "Downloaded bytes no longer match their actual native hash";
    return result;
  }
  result.media_type = DownloadMime(bytes);
  result.size = bytes.size();
  result.bytes = memory.region.Map();
  if (!result.bytes.IsValid())
    result.failure = "Original download capture mapping failed";
#else
  result.failure =
      "This platform lacks the required local file identity verifier";
#endif
  return result;
}

}  // namespace
class NativeDocumentJobs::Job final
    : public base::RefCounted<Job>,
      public content::ServiceProcessHost::Observer {
 public:
  Job(std::vector<Source> sources, base::DictValue request)
      : sources_(std::move(sources)), request_(std::move(request)) {
    expires_ = base::TimeTicks::Now() + base::Minutes(2);
    timer_.Start(FROM_HERE, base::Milliseconds(100), this, &Job::Check);
  }
  explicit Job(NativeDownloadSource source)
      : download_source_(std::move(source)) {
    expires_ = download_source_->deadline;
    timer_.Start(FROM_HERE, base::Milliseconds(100), this, &Job::Check);
  }
  size_t bytes() const { return source_bytes_; }
  bool closed() const { return state_ == State::kClosed; }
  void set_bytes(size_t bytes) { source_bytes_ = bytes; }
  void Append(const base::DictValue& params, Reply callback) {
    const auto index = params.FindInt("sourceIndex"),
               offset = params.FindInt("offset");
    const auto* encoded = params.FindString("bytesBase64");
    std::string bytes;
    if (state_ != State::kUploading || params.size() != 5 || !index ||
        *index < 0 || static_cast<size_t>(*index) >= sources_.size() ||
        !offset || *offset < 0 || !encoded ||
        !base::Base64Decode(*encoded, &bytes) || bytes.empty() ||
        bytes.size() > kChunkLimit || base::Base64Encode(bytes) != *encoded) {
      std::move(callback).Run(
          Fault("invalid_params", "Invalid document upload chunk"));
      return;
    }
    auto& source = sources_[*index];
    if (source.received != static_cast<size_t>(*offset) ||
        bytes.size() > source.size - source.received) {
      std::move(callback).Run(
          Fault("conflict", "Document chunks must append once in exact order"));
      return;
    }
    source.received += bytes.size();
    source.chunks.push_back(std::move(bytes));
    expires_ = base::TimeTicks::Now() + base::Minutes(2);
    std::move(callback).Run(
        Result(base::DictValue()
                   .Set("action", "append")
                   .Set("offset", static_cast<int>(source.received))));
  }
  void Capture(std::shared_ptr<std::atomic_bool> cancelled, Reply callback) {
    if (!download_source_ || state_ != State::kUploading) {
      std::move(callback).Run(Fault(
          "conflict",
          "Original download capture is unavailable or already dispatched"));
      return;
    }
    cancelled_ = std::move(cancelled);
    pending_ = std::move(callback);
    state_ = State::kDownloadWaiting;
    TryDownload();
  }
  void Run(std::shared_ptr<std::atomic_bool> cancelled, Reply callback) {
    if (download_source_) {
      std::move(callback).Run(Fault(
          "invalid_params", "Use original download capture, not computation"));
      return;
    }
    if (state_ != State::kUploading ||
        std::ranges::any_of(
            sources_, [](const Source& s) { return s.received != s.size; })) {
      std::move(callback).Run(Fault(
          "conflict", "Document job requires every immutable source once"));
      return;
    }
    state_ = State::kPreparing;
    cancelled_ = std::move(cancelled);
    pending_ = std::move(callback);
    expires_ = base::TimeTicks::Now() + base::Seconds(60);
    base::ThreadPool::PostTaskAndReplyWithResult(
        FROM_HERE, {base::TaskPriority::USER_VISIBLE},
        base::BindOnce(&Prepare, std::move(sources_), cancelled_),
        base::BindOnce(&Job::PreparedSources, base::RetainedRef(this)));
  }
  void Read(const base::DictValue& params, Reply callback) {
    auto index = params.FindInt("outputIndex"),
         offset = params.FindInt("offset");
    if (state_ != State::kComplete || params.size() != 4 || !index ||
        *index < 0 || static_cast<size_t>(*index) >= outputs_.size() ||
        !offset || *offset < 0 ||
        static_cast<size_t>(*offset) > outputs_[*index].size()) {
      std::move(callback).Run(
          Fault("ref_stale", "Document output is unavailable at this offset"));
      return;
    }
    if (download_source_ &&
        (base::TimeTicks::Now() >= download_source_->deadline ||
         !SameDownload(download_file_, download_source_->snapshot.Run()))) {
      Retire("ref_stale",
             "Original downloaded source retired before byte publication");
      std::move(callback).Run(
          Fault("ref_stale", "Original downloaded source retired"));
      return;
    }
    auto bytes = outputs_[*index].GetMemoryAsSpan<const uint8_t>();
    if (download_source_)
      bytes = bytes.first(download_size_);
    if (static_cast<size_t>(*offset) > bytes.size()) {
      std::move(callback).Run(
          Fault("ref_stale", "Original download offset unavailable"));
      return;
    }
    auto chunk = bytes.subspan(static_cast<size_t>(*offset),
                               std::min(kChunkLimit, bytes.size() - *offset));
    if (!download_source_)
      expires_ = base::TimeTicks::Now() + base::Minutes(2);
    std::move(callback).Run(
        Result(base::DictValue()
                   .Set("action", "read")
                   .Set("offset", *offset)
                   .Set("bytesBase64", base::Base64Encode(chunk))
                   .Set("done", *offset + chunk.size() == bytes.size())));
  }
  void Close(Reply callback) {
    if (state_ == State::kClosed) {
      std::move(callback).Run(
          Result(base::DictValue().Set("action", "close").Set("joined", true)));
      return;
    }
    closers_.push_back(std::move(callback));
    Retire("cancelled", "Original document job retired");
  }
  void Retire(std::string code, std::string reason) {
    fault_ = Fault(std::move(code), std::move(reason));
    if (cancelled_) {
      cancelled_->store(true);
    }
    sources_.clear();
    outputs_.clear();
    if (state_ == State::kPreparing) {
      return;  // The original worker still owns its bytes.
    }
    if (state_ == State::kRunning) {
      remote_.reset();
      return;
    }
    FinishClosed();
  }
  void OnServiceProcessLaunchFailed(int) override {
    fault_ = Fault("backend_unavailable",
                   "The original document utility could not be launched");
    remote_.reset();
    Terminated();
  }
  void OnServiceProcessTerminatedNormally(
      const content::ServiceProcessInfo&) override {
    Terminated();
  }
  void OnServiceProcessCrashed(const content::ServiceProcessInfo&) override {
    Terminated();
  }

 private:
  friend class base::RefCounted<Job>;
  ~Job() override = default;
  enum class State {
    kUploading,
    kDownloadWaiting,
    kPreparing,
    kRunning,
    kComplete,
    kClosed
  };
  void Check() {
    if ((cancelled_ && cancelled_->load()) ||
        base::TimeTicks::Now() >= expires_) {
      Retire("cancelled", "Document job cancelled or expired");
      return;
    }
    if (state_ == State::kDownloadWaiting)
      TryDownload();
    else if (download_source_ && state_ == State::kComplete &&
             !SameDownload(download_file_, download_source_->snapshot.Run()))
      Retire("ref_stale", "Original download source retired");
  }
  void TryDownload() {
    if (!download_source_ || !cancelled_)
      return;
    auto file = download_source_->snapshot.Run();
    if (cancelled_->load() ||
        base::TimeTicks::Now() >= download_source_->deadline ||
        file.state == NativeDownloadFile::State::kRetired) {
      Retire("ref_stale", "Original download source retired or expired");
      return;
    }
    if (file.state == NativeDownloadFile::State::kWaiting)
      return;
    download_file_ = file;
    state_ = State::kPreparing;
    base::ThreadPool::PostTaskAndReplyWithResult(
        FROM_HERE, {base::MayBlock(), base::TaskPriority::USER_VISIBLE},
        base::BindOnce(&CaptureDownload, file, download_source_->deadline,
                       cancelled_),
        base::BindOnce(&Job::DownloadCaptured, base::RetainedRef(this)));
  }
  void DownloadCaptured(CapturedDownload captured) {
    scoped_refptr<Job> hold(this);
    if (!fault_.empty() || cancelled_->load() || !captured.failure.empty() ||
        base::TimeTicks::Now() >= download_source_->deadline ||
        !SameDownload(download_file_, download_source_->snapshot.Run())) {
      if (fault_.empty())
        fault_ = Fault("ref_stale",
                       captured.failure.empty()
                           ? "Original download source retired during capture"
                           : captured.failure);
      // Release worker-owned immutable bytes before closed becomes observable
      // to a reentrant admission from the original close callback.
      captured.bytes = {};
      FinishClosed();
      return;
    }
    download_size_ = captured.size;
    source_bytes_ = std::max<size_t>(1, captured.size);
    outputs_.push_back(std::move(captured.bytes));
    state_ = State::kComplete;
    auto source =
        base::DictValue()
            .Set("runId", download_source_->run_id)
            .Set("downloadId", download_source_->download_id)
            .Set("filename", download_file_.filename)
            .Set("sha256", captured.sha256)
            .Set("size", static_cast<int>(captured.size))
            .Set("mediaType", captured.media_type)
            .Set("nativeHashVerified", !download_file_.native_sha256.empty());
    if (pending_)
      std::move(pending_).Run(Result(base::DictValue()
                                         .Set("action", "capture")
                                         .Set("source", std::move(source))));
  }
  void PreparedSources(Prepared prepared) {
    if (!fault_.empty() || cancelled_->load() || !prepared.failure.empty()) {
      if (fault_.empty()) {
        fault_ = Fault("invalid_params", prepared.failure.empty()
                                             ? "Document job cancelled"
                                             : prepared.failure);
      }
      prepared.sources.clear();
      FinishClosed();
      return;
    }
    state_ = State::kRunning;
    self_until_exit_ = this;
    content::ServiceProcessHost::Launch(
        remote_.BindNewPipeAndPassReceiver(),
        content::ServiceProcessHost::Options()
            .WithDisplayName("Aux document computation")
            .WithObserver(weak_factory_.GetWeakPtr())
            .Pass());
    remote_.set_disconnect_handler(
        base::BindOnce(&Job::Disconnected, weak_factory_.GetWeakPtr()));
    remote_->Execute(
        std::move(prepared.sources), std::move(request_),
        base::BindOnce(&Job::Computed, weak_factory_.GetWeakPtr()));
  }
  void Computed(document::mojom::JobResultPtr result) {
    if (!result->failure.empty()) {
      fault_ = Fault("invalid_params", result->failure);
    }
    if (fault_.empty()) {
      base::ListValue descriptions;
      size_t total = 0;
      for (auto& output : result->outputs) {
        total += output->size;
        auto mapping = output->source.Map();
        if (result->outputs.size() > 40 || total > kOutputLimit ||
            !output->size || !mapping.IsValid() ||
            mapping.size() != output->size ||
            Hash(mapping.GetMemoryAsSpan<const uint8_t>()) != output->sha256) {
          fault_ = Fault("backend_unavailable",
                         "Isolated document output identity failed");
          break;
        }
        descriptions.Append(base::DictValue()
                                .Set("sha256", output->sha256)
                                .Set("size", static_cast<int>(output->size))
                                .Set("mediaType", output->media_type)
                                .Set("label", output->label));
        outputs_.push_back(std::move(mapping));
      }
      reply_ = Result(base::DictValue()
                          .Set("action", "run")
                          .Set("report", std::move(result->report))
                          .Set("outputs", std::move(descriptions)));
    }
    computed_ = true;
    remote_.reset();  // Reply only after this exact utility has exited.
  }
  void Disconnected() {
    if (!computed_ && fault_.empty()) {
      fault_ = Fault("backend_unavailable",
                     "Original document utility disconnected");
    }
    remote_.reset();
  }
  void Terminated() {
    scoped_refptr<Job> hold(this);
    if (!computed_ && fault_.empty()) {
      fault_ = Fault("backend_unavailable",
                     "Original document utility exited before its result");
    }
    if (!fault_.empty() || !closers_.empty()) {
      FinishClosed();
    } else {
      state_ = State::kComplete;
      cancelled_.reset();
      expires_ = base::TimeTicks::Now() + base::Minutes(2);
      if (pending_) {
        std::move(pending_).Run(std::move(reply_));
      }
    }
    self_until_exit_.reset();
  }
  void FinishClosed() {
    state_ = State::kClosed;
    source_bytes_ = 0;
    sources_.clear();
    outputs_.clear();
    timer_.Stop();
    if (pending_) {
      std::move(pending_).Run(fault_.empty()
                                  ? Fault("cancelled", "Document job closed")
                                  : fault_.Clone());
    }
    for (auto& callback : closers_) {
      std::move(callback).Run(
          Result(base::DictValue().Set("action", "close").Set("joined", true)));
    }
    closers_.clear();
  }
  std::optional<NativeDownloadSource> download_source_;
  NativeDownloadFile download_file_;
  size_t download_size_ = 0;
  State state_ = State::kUploading;
  size_t source_bytes_ = 0;
  std::vector<Source> sources_;
  base::DictValue request_, reply_, fault_;
  std::vector<base::ReadOnlySharedMemoryMapping> outputs_;
  mojo::Remote<document::mojom::DocumentExtractor> remote_;
  std::shared_ptr<std::atomic_bool> cancelled_;
  Reply pending_;
  std::vector<Reply> closers_;
  bool computed_ = false;
  base::TimeTicks expires_;
  base::RepeatingTimer timer_;
  scoped_refptr<Job> self_until_exit_;
  base::WeakPtrFactory<Job> weak_factory_{this};
};
NativeDocumentJobs::NativeDocumentJobs() = default;
NativeDocumentJobs::~NativeDocumentJobs() {
  for (auto& [id, job] : jobs_) {
    job->Retire("ref_stale", "Original native connection retired");
  }
}
void NativeDocumentJobs::BeginDownload(
    NativeDownloadSource source,
    std::shared_ptr<std::atomic_bool> cancelled,
    Reply callback) {
  std::erase_if(jobs_,
                [](const auto& entry) { return entry.second->closed(); });
  size_t occupied = 0;
  for (const auto& [id, job] : jobs_)
    occupied += job->bytes();
  if (cancelled->load() || !source.snapshot ||
      base::TimeTicks::Now() >= source.deadline || jobs_.size() >= 4 ||
      occupied + kSourceLimit > 128 * 1024 * 1024) {
    std::move(callback).Run(
        Fault("ref_stale", "Original download admission unavailable or full"));
    return;
  }
  const auto id = base::UnguessableToken::Create().ToString();
  auto job = base::MakeRefCounted<Job>(std::move(source));
  job->set_bytes(kSourceLimit);
  jobs_.emplace(id, std::move(job));
  std::move(callback).Run(Result(
      base::DictValue().Set("action", "beginDownload").Set("jobId", id)));
}
void NativeDocumentJobs::Dispatch(const base::DictValue& params,
                                  std::shared_ptr<std::atomic_bool> cancelled,
                                  Reply callback) {
  const auto* action = params.FindString("action");
  if (!action || cancelled->load()) {
    std::move(callback).Run(
        Fault("cancelled", "Document action owner unavailable"));
    return;
  }
  if (*action == "begin") {
    std::erase_if(jobs_,
                  [](const auto& entry) { return entry.second->closed(); });
    const auto* descriptions = params.FindList("sources");
    const auto* request = params.FindDict("request");
    size_t total = 0, occupied = 0;
    for (const auto& [id, job] : jobs_) {
      occupied += job->bytes();
    }
    std::vector<Source> sources;
    if (params.size() != 3 || jobs_.size() >= 4 || !descriptions ||
        descriptions->empty() || descriptions->size() > 8 || !request) {
      std::move(callback).Run(
          Fault("invalid_params", "Invalid document job or active job limit"));
      return;
    }
    for (const auto& value : *descriptions) {
      const auto* description = value.GetIfDict();
      auto size = description ? description->FindInt("size") : std::nullopt;
      const auto* hash =
          description ? description->FindString("sha256") : nullptr;
      const auto* type =
          description ? description->FindString("mediaType") : nullptr;
      if (!description || description->size() != 3 || !size || *size <= 0 ||
          *size > static_cast<int>(kSourceLimit) || !hash ||
          hash->size() != 64 ||
          !std::ranges::all_of(*hash,
                               [](char c) {
                                 return (c >= '0' && c <= '9') ||
                                        (c >= 'a' && c <= 'f');
                               }) ||
          !type || type->empty() || type->size() > 200) {
        std::move(callback).Run(
            Fault("invalid_params", "Invalid immutable document source"));
        return;
      }
      total += *size;
      sources.push_back(
          Source{static_cast<size_t>(*size), 0, *hash, *type, {}});
    }
    if (total > kSourceLimit || occupied + total > 128 * 1024 * 1024) {
      std::move(callback).Run(
          Fault("invalid_params", "Document source memory limit exceeded"));
      return;
    }
    const auto id = base::UnguessableToken::Create().ToString();
    auto job = base::MakeRefCounted<Job>(std::move(sources), request->Clone());
    job->set_bytes(total);
    jobs_.emplace(id, std::move(job));
    std::move(callback).Run(
        Result(base::DictValue().Set("action", "begin").Set("jobId", id)));
    return;
  }
  const auto* id = params.FindString("jobId");
  auto found = id ? jobs_.find(*id) : jobs_.end();
  if (found == jobs_.end()) {
    std::move(callback).Run(
        Fault("ref_stale", "Original document job is unavailable"));
    return;
  }
  if (*action == "append") {
    found->second->Append(params, std::move(callback));
  } else if (*action == "capture" && params.size() == 2) {
    found->second->Capture(std::move(cancelled), std::move(callback));
  } else if (*action == "run" && params.size() == 2) {
    found->second->Run(std::move(cancelled), std::move(callback));
  } else if (*action == "read") {
    found->second->Read(params, std::move(callback));
  } else if (*action == "close" && params.size() == 2) {
    // A preparing worker still owns its reservation until Close joins it.
    // Begin prunes only closed jobs, after their immutable resources released.
    auto job = found->second;
    job->Close(std::move(callback));
  } else {
    std::move(callback).Run(
        Fault("invalid_params", "Unsupported document action"));
  }
}
}  // namespace aux
