// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#include "chrome/browser/ui/aux/image_normalize.h"

#include <optional>
#include <string>
#include <string_view>
#include <utility>

#include "base/base64.h"
#include "base/containers/span.h"
#include "base/functional/bind.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_view_util.h"
#include "base/task/thread_pool.h"
#include "crypto/hash.h"
#include "services/data_decoder/public/cpp/decode_image.h"
#include "third_party/skia/include/core/SkBitmap.h"
#include "ui/gfx/codec/png_codec.h"
#include "ui/gfx/geometry/size.h"
namespace aux {
namespace {
constexpr size_t kMaxBytes = 3 * 1024 * 1024;
constexpr uint64_t kMaxPixels = 16000000;
base::DictValue Fault(std::string code, std::string message) {
  return base::DictValue().Set("error",
                               base::DictValue()
                                   .Set("code", std::move(code))
                                   .Set("message", std::move(message)));
}
std::string Hash(base::span<const uint8_t> bytes) {
  return base::HexEncodeLower(crypto::hash::Sha256(bytes));
}
bool Dimensions(int width, int height) {
  return width > 0 && height > 0 && width <= 16384 && height <= 16384 &&
         static_cast<uint64_t>(width) * height <= kMaxPixels;
}
// Reject oversized compressed headers before asking the isolated codec to
// allocate.
bool AdmittedHeader(base::span<const uint8_t> bytes, const std::string& type) {
  if (type == "image/png") {
    constexpr uint8_t signature[] = {137, 80, 78, 71, 13, 10, 26, 10};
    if (bytes.size() < 24 || bytes.first<8>() != base::span(signature)) {
      return false;
    }
    auto number = [&](size_t offset) {
      return (uint32_t(bytes[offset]) << 24) |
             (uint32_t(bytes[offset + 1]) << 16) |
             (uint32_t(bytes[offset + 2]) << 8) | bytes[offset + 3];
    };
    const auto width = number(16), height = number(20);
    return width <= 16384 && height <= 16384 && Dimensions(width, height);
  }
  if (type == "image/webp") {
    if (bytes.size() < 30 || base::as_string_view(bytes.first<4>()) != "RIFF" ||
        base::as_string_view(bytes.subspan<8, 4>()) != "WEBP") {
      return false;
    }
    auto little = [&](size_t offset, size_t count) {
      uint32_t value = 0;
      for (size_t i = 0; i < count; ++i) {
        value |= uint32_t(bytes[offset + i]) << (8 * i);
      }
      return value;
    };
    if (little(4, 4) != bytes.size() - 8 || little(16, 4) > bytes.size() - 20) {
      return false;
    }
    const auto chunk = base::as_string_view(bytes.subspan<12, 4>());
    if (chunk == "VP8X" && little(16, 4) >= 10 && !(bytes[20] & 2)) {
      return Dimensions(little(24, 3) + 1, little(27, 3) + 1);
    }
    if (chunk == "VP8L" && little(16, 4) >= 5 && bytes[20] == 0x2f) {
      const auto dimensions = little(21, 4);
      return Dimensions((dimensions & 0x3fff) + 1,
                        ((dimensions >> 14) & 0x3fff) + 1);
    }
    return chunk == "VP8 " && little(16, 4) >= 10 && bytes[23] == 0x9d &&
           bytes[24] == 1 && bytes[25] == 0x2a &&
           Dimensions(little(26, 2) & 0x3fff, little(28, 2) & 0x3fff);
  }
  if (type != "image/jpeg" || bytes.size() < 4 || bytes[0] != 0xff ||
      bytes[1] != 0xd8) {
    return false;
  }
  size_t offset = 2;
  while (offset + 3 < bytes.size()) {
    if (bytes[offset++] != 0xff) {
      return false;
    }
    while (offset < bytes.size() && bytes[offset] == 0xff) {
      ++offset;
    }
    if (offset >= bytes.size()) {
      return false;
    }
    const auto marker = bytes[offset++];
    if (marker == 0xda || marker == 0xd9 || marker == 0x00) {
      return false;
    }
    if (marker == 0x01 || (marker >= 0xd0 && marker <= 0xd8)) {
      continue;
    }
    if (offset + 2 > bytes.size()) {
      return false;
    }
    const size_t length = (uint16_t(bytes[offset]) << 8) | bytes[offset + 1];
    if (length < 2 || length > bytes.size() - offset) {
      return false;
    }
    if (marker >= 0xc0 && marker <= 0xcf && marker != 0xc4 && marker != 0xc8 &&
        marker != 0xcc) {
      if (length < 8) {
        return false;
      }
      return Dimensions((uint16_t(bytes[offset + 5]) << 8) | bytes[offset + 6],
                        (uint16_t(bytes[offset + 3]) << 8) | bytes[offset + 4]);
    }
    offset += length;
  }
  return false;
}
base::DictValue Encode(SkBitmap bitmap,
                       std::string source_hash,
                       std::shared_ptr<std::atomic_bool> cancelled) {
  if (cancelled->load()) {
    return Fault("cancelled", "Original image owner retired");
  }
  auto encoded = gfx::PNGCodec::EncodeBGRASkBitmap(bitmap, false);
  if (!encoded || encoded->empty() || encoded->size() > kMaxBytes) {
    return Fault("invalid_params",
                 "Normalized image exceeds the PNG admission limit");
  }
  if (cancelled->load()) {
    return Fault("cancelled", "Original image owner retired");
  }
  return base::DictValue().Set(
      "result", base::DictValue()
                    .Set("sourceSha256", std::move(source_hash))
                    .Set("sha256", Hash(*encoded))
                    .Set("width", bitmap.width())
                    .Set("height", bitmap.height())
                    .Set("pngBase64", base::Base64Encode(*encoded)));
}
}  // namespace
void NormalizeImage(const base::DictValue& params,
                    std::shared_ptr<std::atomic_bool> cancelled,
                    base::OnceCallback<void(base::DictValue)> callback) {
  const auto* encoded = params.FindString("bytesBase64");
  const auto* type = params.FindString("mediaType");
  const auto* hash = params.FindString("sha256");
  std::string bytes;
  if (params.size() != 3 || !encoded || !type || !hash ||
      !base::Base64Decode(*encoded, &bytes) || bytes.empty() ||
      bytes.size() > kMaxBytes || base::Base64Encode(bytes) != *encoded ||
      Hash(base::as_byte_span(bytes)) != *hash ||
      !AdmittedHeader(base::as_byte_span(bytes), *type)) {
    std::move(callback).Run(Fault(
        "invalid_params", "Image bytes, MIME or dimensions failed admission"));
    return;
  }
  if (cancelled->load()) {
    std::move(callback).Run(Fault("cancelled", "Original image owner retired"));
    return;
  }
  data_decoder::DecodeImageIsolated(
      base::as_byte_span(bytes), data_decoder::mojom::ImageCodec::kDefault,
      false, kMaxPixels * 4 + 1024, gfx::Size(16384, 16384),
      base::BindOnce(
          [](std::string hash, std::shared_ptr<std::atomic_bool> cancelled,
             base::OnceCallback<void(base::DictValue)> callback,
             const SkBitmap& bitmap) {
            if (cancelled->load() || bitmap.isNull() ||
                !Dimensions(bitmap.width(), bitmap.height())) {
              std::move(callback).Run(
                  Fault(cancelled->load() ? "cancelled" : "invalid_params",
                        "Image decoding failed or its original owner retired"));
              return;
            }
            base::ThreadPool::PostTaskAndReplyWithResult(
                FROM_HERE, {base::TaskPriority::USER_VISIBLE},
                base::BindOnce(&Encode, bitmap, std::move(hash), cancelled),
                std::move(callback));
          },
          *hash, std::move(cancelled), std::move(callback)));
}
}  // namespace aux
