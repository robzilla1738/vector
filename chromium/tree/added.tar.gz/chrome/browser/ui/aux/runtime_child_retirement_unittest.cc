// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/ui/aux/runtime_child_retirement.h"

#include <poll.h>
#include <sys/wait.h>

#include <thread>

#include "base/files/scoped_file.h"
#include "testing/gtest/include/gtest/gtest.h"

namespace aux {
namespace {

// No shell, network, Profile, runtime or browser. The fork child performs only
// async-signal-safe operations before parking in pause().
class Child {
 public:
  ~Child() {
    if (owned_child_ <= 0) {
      return;
    }
    // Test-only cleanup owns this exact fork child as its sole waiter. A zero
    // WNOHANG result proves it is still our unreaped child, so its PID cannot
    // have been recycled even if the kernel creation-time probe failed.
    pid_t result;
    do {
      result = waitpid(owned_child_, nullptr, WNOHANG);
    } while (result < 0 && errno == EINTR);
    if (result == 0) {
      EXPECT_EQ(kill(owned_child_, SIGKILL), 0);
      EXPECT_TRUE(process.WaitForExitWithTimeout(base::Seconds(2), nullptr));
    }
    // ECHILD/already reaped never signals a potentially reused PID.
  }

  bool Start(bool ignore_term, bool fail_cleanup = false) {
    int descriptors[2];
    if (pipe(descriptors) != 0) {
      return false;
    }
    base::ScopedFD reader(descriptors[0]);
    base::ScopedFD writer(descriptors[1]);
    const pid_t pid = fork();
    if (pid < 0) {
      return false;
    }
    if (pid == 0) {
      close(reader.release());
      struct sigaction action = {};
      action.sa_handler =
          ignore_term ? SIG_IGN : (fail_cleanup ? ExitFailure : ExitZero);
      sigemptyset(&action.sa_mask);
      if (sigaction(SIGTERM, &action, nullptr) != 0) {
        _exit(71);
      }
      const char ready = 'R';
      if (write(writer.get(), &ready, 1) != 1) {
        _exit(72);
      }
      close(writer.release());
      for (;;) {
        pause();
      }
    }
    owned_child_ = pid;
    writer.reset();
    process = base::Process(pid);
    creation_time = process.CreationTime();
    pollfd ready = {reader.get(), POLLIN, 0};
    char byte = 0;
    return !creation_time.is_null() && poll(&ready, 1, 2000) == 1 &&
           read(reader.get(), &byte, 1) == 1 && byte == 'R';
  }

  base::Process process;
  base::Time creation_time;

 private:
  pid_t owned_child_ = -1;
  static void ExitZero(int) { _exit(0); }
  static void ExitFailure(int) { _exit(1); }
};

TEST(RuntimeChildRetirementTest, BrowserRetiresOriginalHeldHandshake) {
  int descriptors[2];
  ASSERT_EQ(pipe(descriptors), 0);
  base::ScopedFD reader(descriptors[0]);
  base::ScopedFD writer(descriptors[1]);
  std::atomic<int64_t> shutdown_deadline{0};
  std::thread shutdown([&] {
    // No data arrives. Only the actual original shutdown signal releases this
    // wait; timeout and cancellation are distinct observed outcomes.
    usleep(10'000);
    shutdown_deadline.store(
        (base::TimeTicks::Now() + base::Seconds(5)).ToInternalValue());
  });
  const auto result = WaitForRuntimeHandshake(
      reader.get(), base::TimeTicks::Now() + base::Seconds(15),
      shutdown_deadline);
  shutdown.join();
  EXPECT_EQ(result, RuntimeHandshakeWait::kCancelled);
}

TEST(RuntimeChildRetirementTest, OrdinaryHandshakeStillRequiresActualBytes) {
  int descriptors[2];
  ASSERT_EQ(pipe(descriptors), 0);
  base::ScopedFD reader(descriptors[0]);
  base::ScopedFD writer(descriptors[1]);
  std::atomic<int64_t> shutdown_deadline{0};
  const char byte = 'H';
  ASSERT_EQ(write(writer.get(), &byte, 1), 1);
  EXPECT_EQ(WaitForRuntimeHandshake(
                reader.get(), base::TimeTicks::Now() + base::Seconds(1),
                shutdown_deadline),
            RuntimeHandshakeWait::kReadable);
}

TEST(RuntimeChildRetirementTest, JoinsGracefulOriginalExit) {
  Child child;
  ASSERT_TRUE(child.Start(false));
  bool forced = false;
  const auto result = RetireOriginalRuntimeChild(
      child.process, child.creation_time,
      base::TimeTicks::Now() + base::Seconds(5), forced);
  EXPECT_TRUE(result.exited);
  EXPECT_FALSE(result.forced);
  EXPECT_FALSE(forced);
  EXPECT_EQ(result.exit_code, 0);
  EXPECT_TRUE(result.GracefulCleanupAcknowledged());
}

TEST(RuntimeChildRetirementTest, ForcesAndJoinsOriginalIgnoringTermination) {
  Child child;
  ASSERT_TRUE(child.Start(true));
  bool forced = false;
  const auto result = RetireOriginalRuntimeChild(
      child.process, child.creation_time,
      base::TimeTicks::Now() + base::Seconds(5), forced);
  EXPECT_TRUE(result.exited);
  EXPECT_TRUE(result.forced);
  EXPECT_TRUE(forced);
  EXPECT_EQ(result.exit_code, -1);
  EXPECT_FALSE(result.GracefulCleanupAcknowledged());
}

TEST(RuntimeChildRetirementTest, NonzeroParentExitDoesNotAcknowledgeCleanup) {
  Child child;
  ASSERT_TRUE(child.Start(false, true));
  bool forced = false;
  const auto result = RetireOriginalRuntimeChild(
      child.process, child.creation_time,
      base::TimeTicks::Now() + base::Seconds(5), forced);
  EXPECT_TRUE(result.exited);
  EXPECT_FALSE(result.forced);
  EXPECT_EQ(result.exit_code, 1);
  EXPECT_FALSE(result.GracefulCleanupAcknowledged());
}

TEST(RuntimeChildRetirementTest, ShortAbsoluteBudgetDoesNotBecomeSixtySeconds) {
  Child child;
  ASSERT_TRUE(child.Start(true));
  bool forced = false;
  const auto started = base::TimeTicks::Now();
  const auto result = RetireOriginalRuntimeChild(
      child.process, child.creation_time,
      started + base::Milliseconds(150), forced);
  const auto elapsed = base::TimeTicks::Now() - started;
  EXPECT_TRUE(result.forced);
  EXPECT_TRUE(forced);
  // Functional timeout regression with wide scheduling headroom, not a product
  // performance target: a150ms owner budget must not enter POSIX's60s wait.
  EXPECT_LT(elapsed, base::Seconds(5));
  // The kill was requested at the exhausted deadline. Its exit may or may not
  // already be waitable; retain and reap the SAME original child explicitly.
  EXPECT_TRUE(child.process.WaitForExitWithTimeout(base::Seconds(2), nullptr));
}

TEST(RuntimeChildRetirementTest, ChangedKernelBirthDoesNotSignalChild) {
  Child child;
  ASSERT_TRUE(child.Start(false));
  bool forced = false;
  const auto result = RetireOriginalRuntimeChild(
      child.process, child.creation_time + base::Microseconds(1),
      base::TimeTicks::Now() + base::Seconds(5), forced);
  EXPECT_FALSE(result.exited);
  EXPECT_FALSE(forced);
  EXPECT_FALSE(child.process.WaitForExitWithTimeout(base::TimeDelta(), nullptr));
}

TEST(RuntimeChildRetirementTest, UnknownBirthDoesNotSignalChild) {
  Child child;
  ASSERT_TRUE(child.Start(false));
  bool forced = false;
  const auto result = RetireOriginalRuntimeChild(
      child.process, base::Time(),
      base::TimeTicks::Now() + base::Seconds(5), forced);
  EXPECT_FALSE(result.exited);
  EXPECT_FALSE(forced);
  EXPECT_FALSE(child.process.WaitForExitWithTimeout(base::TimeDelta(), nullptr));
}

TEST(RuntimeChildRetirementTest, RetryKeepsOriginalForcedOutcome) {
  Child child;
  ASSERT_TRUE(child.Start(true));
  bool forced = false;
  const auto deadline = base::TimeTicks::Now() + base::Seconds(5);
  const auto first = RetireOriginalRuntimeChild(
      child.process, child.creation_time, deadline, forced);
  ASSERT_TRUE(first.exited);
  ASSERT_TRUE(forced);
  // Keep the same identity/progress. A repeated inspection of the original
  // reaped child cannot become a fresh graceful-exit claim or signal a new PID.
  const auto again = RetireOriginalRuntimeChild(
      child.process, child.creation_time, deadline, forced);
  EXPECT_TRUE(again.exited);
  EXPECT_TRUE(again.forced);
}

}  // namespace
}  // namespace aux
