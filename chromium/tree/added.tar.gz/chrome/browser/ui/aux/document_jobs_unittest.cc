// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#include "chrome/browser/ui/aux/document_jobs.h"

#include "base/base64.h"
#include "base/containers/span.h"
#include "base/files/file_util.h"
#include "base/files/scoped_temp_dir.h"
#include "base/strings/string_number_conversions.h"
#include "base/test/bind.h"
#include "base/test/task_environment.h"
#include "base/test/test_future.h"
#include "crypto/hash.h"
#include "testing/gtest/include/gtest/gtest.h"

namespace aux {
namespace {
// Tests real file capture and byte-job retirement. The synthetic native closure
// is not evidence of CdpBroker's original navigation/lease/GUID admission.
class NativeDownloadJobsTest : public testing::Test {
 protected:
  void SetUp() override {
    ASSERT_TRUE(directory_.CreateUniqueTempDir());
    file_.state = NativeDownloadFile::State::kReady;
    file_.path = directory_.GetPath().AppendASCII("original.pdf");
    file_.filename = "original.pdf";
    ASSERT_TRUE(base::WriteFile(file_.path, bytes_));
    file_.size = bytes_.size();
  }
  std::string Begin() {
    NativeDownloadSource source;
    source.run_id = "original-run";
    source.download_id = "exact-original-guid";
    source.deadline = base::TimeTicks::Now() + base::Seconds(30);
    source.snapshot = base::BindLambdaForTesting([this] {
      ++snapshots_;
      if (retire_after_capture_ && snapshots_ > 1)
        return NativeDownloadFile();
      return file_;
    });
    base::test::TestFuture<base::DictValue> begun;
    jobs_.BeginDownload(std::move(source), cancelled_, begun.GetCallback());
    const auto* result = begun.Get().FindDict("result");
    EXPECT_NE(result, nullptr);
    return result ? *result->FindString("jobId") : std::string();
  }
  base::DictValue Capture(const std::string& id) {
    base::test::TestFuture<base::DictValue> captured;
    jobs_.Dispatch(base::DictValue().Set("action", "capture").Set("jobId", id),
                   cancelled_, captured.GetCallback());
    return captured.Take();
  }
  base::DictValue Read(const std::string& id) {
    base::test::TestFuture<base::DictValue> read;
    jobs_.Dispatch(base::DictValue()
                       .Set("action", "read")
                       .Set("jobId", id)
                       .Set("outputIndex", 0)
                       .Set("offset", 0),
                   std::make_shared<std::atomic_bool>(false),
                   read.GetCallback());
    return read.Take();
  }
  base::DictValue Close(const std::string& id) {
    base::test::TestFuture<base::DictValue> closed;
    jobs_.Dispatch(base::DictValue().Set("action", "close").Set("jobId", id),
                   std::make_shared<std::atomic_bool>(false),
                   closed.GetCallback());
    return closed.Take();
  }
  base::test::TaskEnvironment tasks_;
  base::ScopedTempDir directory_;
  const std::string bytes_ = "%PDF-1.7\nexact original immutable bytes\n";
  NativeDownloadFile file_;
  int snapshots_ = 0;
  bool retire_after_capture_ = false;
  std::shared_ptr<std::atomic_bool> cancelled_ =
      std::make_shared<std::atomic_bool>(false);
  NativeDocumentJobs jobs_;
};

TEST_F(NativeDownloadJobsTest,
       CapturesHashMimeAndActualBytesWithoutChangingOriginal) {
  file_.native_sha256 =
      base::HexEncodeLower(crypto::hash::Sha256(base::as_byte_span(bytes_)));
  const auto id = Begin();
  auto captured = Capture(id);
  ASSERT_TRUE(captured.FindDict("result"));
  const auto* source = captured.FindDict("result")->FindDict("source");
  ASSERT_TRUE(source);
  EXPECT_EQ(*source->FindString("runId"), "original-run");
  EXPECT_EQ(*source->FindString("downloadId"), "exact-original-guid");
  EXPECT_EQ(*source->FindString("mediaType"), "application/pdf");
  EXPECT_EQ(source->FindBool("nativeHashVerified"), true);
  EXPECT_EQ(*source->FindString("sha256"), file_.native_sha256);
  auto read = Read(id);
  ASSERT_TRUE(read.FindDict("result"));
  std::string actual;
  ASSERT_TRUE(base::Base64Decode(
      *read.FindDict("result")->FindString("bytesBase64"), &actual));
  EXPECT_EQ(actual, bytes_);
  EXPECT_EQ(read.FindDict("result")->FindBool("done"), true);
  auto closed = Close(id);
  ASSERT_TRUE(closed.FindDict("result"));
  EXPECT_EQ(closed.FindDict("result")->FindBool("joined"), true);
  ASSERT_TRUE(base::ReadFileToString(file_.path, &actual));
  EXPECT_EQ(actual, bytes_);
}
TEST_F(NativeDownloadJobsTest, DoesNotTrustFilenameForMimeOrInventNativeHash) {
  ASSERT_TRUE(base::WriteFile(file_.path, "ordinary text"));
  file_.size = 13;
  const auto id = Begin();
  auto captured = Capture(id);
  ASSERT_TRUE(captured.FindDict("result"));
  const auto* source = captured.FindDict("result")->FindDict("source");
  ASSERT_TRUE(source);
  EXPECT_EQ(*source->FindString("mediaType"), "text/plain");
  EXPECT_EQ(source->FindBool("nativeHashVerified"), false);
  EXPECT_TRUE(Close(id).FindDict("result"));
}
TEST_F(NativeDownloadJobsTest, RefusesSymlinkWithoutDeletingOriginal) {
  const auto original = file_.path;
  file_.path = directory_.GetPath().AppendASCII("alias.pdf");
  ASSERT_TRUE(base::CreateSymbolicLink(original, file_.path));
  auto captured = Capture(Begin());
  EXPECT_TRUE(captured.FindDict("error"));
  EXPECT_TRUE(base::PathExists(original));
}
TEST_F(NativeDownloadJobsTest, RefusesChangedSize) {
  --file_.size;
  auto captured = Capture(Begin());
  EXPECT_TRUE(captured.FindDict("error"));
  EXPECT_TRUE(base::PathExists(file_.path));
}
TEST_F(NativeDownloadJobsTest, RefusesBytesChangedFromActualNativeHash) {
  file_.native_sha256 = std::string(64, '0');
  auto captured = Capture(Begin());
  EXPECT_TRUE(captured.FindDict("error"));
  EXPECT_TRUE(base::PathExists(file_.path));
}
TEST_F(NativeDownloadJobsTest, RetiredSourceAfterWorkerReadPublishesNoBytes) {
  retire_after_capture_ = true;
  const auto id = Begin();
  auto captured = Capture(id);
  EXPECT_TRUE(captured.FindDict("error"));
  EXPECT_TRUE(Read(id).FindDict("error"));
  EXPECT_TRUE(base::PathExists(file_.path));
}
TEST_F(NativeDownloadJobsTest,
       ClosingWaitingDownloadJoinsOriginalCaptureExactlyOnce) {
  file_.state = NativeDownloadFile::State::kWaiting;
  const auto id = Begin();
  base::test::TestFuture<base::DictValue> captured;
  jobs_.Dispatch(base::DictValue().Set("action", "capture").Set("jobId", id),
                 cancelled_, captured.GetCallback());
  EXPECT_FALSE(captured.IsReady());
  auto closed = Close(id);
  ASSERT_TRUE(closed.FindDict("result"));
  EXPECT_EQ(closed.FindDict("result")->FindBool("joined"), true);
  EXPECT_TRUE(captured.Get().FindDict("error"));
  file_.state = NativeDownloadFile::State::kReady;
  EXPECT_TRUE(Read(id).FindDict("error"));
  EXPECT_TRUE(base::PathExists(file_.path));
}
TEST_F(NativeDownloadJobsTest,
       SourceRetirementAfterCaptureRefusesFurtherByteReads) {
  const auto id = Begin();
  ASSERT_TRUE(Capture(id).FindDict("result"));
  file_.state = NativeDownloadFile::State::kRetired;
  EXPECT_TRUE(Read(id).FindDict("error"));
  EXPECT_TRUE(base::PathExists(file_.path));
}

TEST(NativeDownloadJobsLifecycleTest,
     ReadingDoesNotRenewOriginalDownloadDeadline) {
  base::test::TaskEnvironment tasks(
      base::test::TaskEnvironment::TimeSource::MOCK_TIME);
  base::ScopedTempDir directory;
  ASSERT_TRUE(directory.CreateUniqueTempDir());
  NativeDownloadFile file;
  file.state = NativeDownloadFile::State::kReady;
  file.path = directory.GetPath().AppendASCII("original.txt");
  file.filename = "original.txt";
  file.size = 5;
  ASSERT_TRUE(base::WriteFile(file.path, "bytes"));
  NativeDocumentJobs jobs;
  NativeDownloadSource source;
  source.run_id = "original-run";
  source.download_id = "original-guid";
  source.deadline = base::TimeTicks::Now() + base::Seconds(30);
  source.snapshot = base::BindLambdaForTesting([&] { return file; });
  base::test::TestFuture<base::DictValue> begun, captured;
  jobs.BeginDownload(std::move(source),
                     std::make_shared<std::atomic_bool>(false),
                     begun.GetCallback());
  ASSERT_TRUE(begun.Get().FindDict("result"));
  const auto id = *begun.Get().FindDict("result")->FindString("jobId");
  jobs.Dispatch(base::DictValue().Set("action", "capture").Set("jobId", id),
                std::make_shared<std::atomic_bool>(false),
                captured.GetCallback());
  tasks.RunUntilIdle();
  ASSERT_TRUE(captured.Get().FindDict("result"));
  const auto read = [&] {
    base::test::TestFuture<base::DictValue> result;
    jobs.Dispatch(base::DictValue()
                      .Set("action", "read")
                      .Set("jobId", id)
                      .Set("outputIndex", 0)
                      .Set("offset", 0),
                  std::make_shared<std::atomic_bool>(false),
                  result.GetCallback());
    return result.Take();
  };
  tasks.FastForwardBy(base::Seconds(10));
  EXPECT_TRUE(read().FindDict("result"));
  tasks.FastForwardBy(base::Seconds(21));
  EXPECT_TRUE(read().FindDict("error"));
  EXPECT_TRUE(base::PathExists(file.path));
}
TEST(NativeDownloadJobsLifecycleTest,
     PreparingCloseRetainsReservationUntilWorkerJoins) {
  base::test::TaskEnvironment tasks(
      base::test::TaskEnvironment::ThreadPoolExecutionMode::QUEUED);
  base::ScopedTempDir directory;
  ASSERT_TRUE(directory.CreateUniqueTempDir());
  NativeDownloadFile file;
  file.state = NativeDownloadFile::State::kReady;
  file.path = directory.GetPath().AppendASCII("original.txt");
  file.filename = "original.txt";
  file.size = 5;
  ASSERT_TRUE(base::WriteFile(file.path, "bytes"));
  NativeDocumentJobs jobs;
  const auto begin = [&] {
    NativeDownloadSource source;
    source.run_id = "original-run";
    source.download_id = "original-guid";
    source.deadline = base::TimeTicks::Now() + base::Seconds(30);
    source.snapshot = base::BindLambdaForTesting([&] { return file; });
    base::test::TestFuture<base::DictValue> result;
    jobs.BeginDownload(std::move(source),
                       std::make_shared<std::atomic_bool>(false),
                       result.GetCallback());
    return result.Take();
  };
  auto first = begin(), second = begin();
  ASSERT_TRUE(first.FindDict("result"));
  ASSERT_TRUE(second.FindDict("result"));
  const auto first_id = *first.FindDict("result")->FindString("jobId");
  const auto second_id = *second.FindDict("result")->FindString("jobId");
  base::test::TestFuture<base::DictValue> capture_first, capture_second;
  jobs.Dispatch(
      base::DictValue().Set("action", "capture").Set("jobId", first_id),
      std::make_shared<std::atomic_bool>(false), capture_first.GetCallback());
  jobs.Dispatch(
      base::DictValue().Set("action", "capture").Set("jobId", second_id),
      std::make_shared<std::atomic_bool>(false), capture_second.GetCallback());
  ASSERT_FALSE(capture_first.IsReady());
  ASSERT_FALSE(capture_second.IsReady());
  base::test::TestFuture<base::DictValue> close_first, close_second;
  jobs.Dispatch(base::DictValue().Set("action", "close").Set("jobId", first_id),
                std::make_shared<std::atomic_bool>(false),
                close_first.GetCallback());
  jobs.Dispatch(
      base::DictValue().Set("action", "close").Set("jobId", second_id),
      std::make_shared<std::atomic_bool>(false), close_second.GetCallback());
  EXPECT_FALSE(close_first.IsReady());
  EXPECT_FALSE(close_second.IsReady());
  // Both original 64 MiB reservations remain while their workers are queued.
  EXPECT_TRUE(begin().FindDict("error"));
  tasks.RunUntilIdle();
  EXPECT_TRUE(capture_first.Get().FindDict("error"));
  EXPECT_TRUE(capture_second.Get().FindDict("error"));
  ASSERT_TRUE(close_first.Get().FindDict("result"));
  ASSERT_TRUE(close_second.Get().FindDict("result"));
  EXPECT_EQ(close_first.Get().FindDict("result")->FindBool("joined"), true);
  EXPECT_EQ(close_second.Get().FindDict("result")->FindBool("joined"), true);
  // Closed entries prune only after original workers released their bytes.
  EXPECT_TRUE(begin().FindDict("result"));
  EXPECT_TRUE(base::PathExists(file.path));
}
}  // namespace
}  // namespace aux
