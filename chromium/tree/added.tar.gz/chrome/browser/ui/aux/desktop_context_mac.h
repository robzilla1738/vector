// Copyright 2026 The Aux Authors
#ifndef CHROME_BROWSER_UI_AUX_DESKTOP_CONTEXT_MAC_H_
#define CHROME_BROWSER_UI_AUX_DESKTOP_CONTEXT_MAC_H_

#include <memory>
#include <string>

#include "base/functional/callback.h"
#include "base/memory/weak_ptr.h"
#include "base/values.h"

namespace aux {
// Profile runtime_host owns persisted consent, normal-window proofs and the
// process-global Profile gate. This object only performs explicitly leased OS
// work.
class DesktopContextMac {
 public:
  using CurrentLease = base::RepeatingCallback<bool(const std::string&, int)>;
  using Reply = base::OnceCallback<void(base::DictValue)>;
  DesktopContextMac(CurrentLease current_lease);
  ~DesktopContextMac();
  DesktopContextMac(const DesktopContextMac&) = delete;
  DesktopContextMac& operator=(const DesktopContextMac&) = delete;

  base::DictValue Status() const;
  static base::ListValue Apps();
  static bool AppSupported(const std::string& bundle_id);
  // Never prompts; caller must have already verified native persisted consent.
  void Configure(const base::DictValue& settings, const std::string& lease_id);
  void RequestAccessibility();
  void PresentOcrPicker();
  base::DictValue Take(const std::string& lease_id);
  void Validate(const base::DictValue& source,
                base::OnceCallback<void(bool)> reply);
  bool Acknowledge(const std::string& lease_id, const std::string& capture_id);
  // Invalidates synchronously; completion joins all original worker and OCR
  // work.
  void Stop(base::OnceClosure completion);

  // Objective-C system picker observer callbacks, main sequence only.
  void PickerSelected(void* filter);
  void PickerStopped();
  void Suspend(bool suspended);

 private:
  struct Impl;
  bool Current() const;
  void Tick();
  void Accept(base::DictValue capture, int generation);
  void CaptureOcr(int pid, int generation);
  void ReadOcr(int pid,
               int generation,
               base::OnceCallback<void(std::string)> reply);
  void FinishOcr();
  void FinishStop();
  std::unique_ptr<Impl> impl_;
  base::WeakPtrFactory<DesktopContextMac> weak_factory_{this};
};
}  // namespace aux
#endif
