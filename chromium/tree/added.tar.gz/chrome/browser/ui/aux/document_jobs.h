// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#ifndef CHROME_BROWSER_UI_AUX_DOCUMENT_JOBS_H_
#define CHROME_BROWSER_UI_AUX_DOCUMENT_JOBS_H_
#include <stdint.h>

#include <atomic>
#include <map>
#include <memory>
#include <string>

#include "base/files/file_path.h"
#include "base/functional/callback.h"
#include "base/memory/scoped_refptr.h"
#include "base/time/time.h"
#include "base/values.h"
namespace aux {
// Only the native CDP continuation creates this original-source closure. No
// runtime path, URL or download row can construct file authority.
struct NativeDownloadFile {
  enum class State { kRetired, kWaiting, kReady };
  State state = State::kRetired;
  base::FilePath path;
  std::string filename;
  int64_t size = 0;
  std::string native_sha256;
};
struct NativeDownloadSource {
  std::string run_id;
  std::string download_id;
  base::TimeTicks deadline;
  base::RepeatingCallback<NativeDownloadFile()> snapshot;
};

// A controller belongs to one authenticated native connection, never a path or
// a replacement runtime. Each computation has its own sandboxed utility.
class NativeDocumentJobs {
 public:
  NativeDocumentJobs();
  ~NativeDocumentJobs();
  void BeginDownload(NativeDownloadSource source,
                     std::shared_ptr<std::atomic_bool> cancelled,
                     base::OnceCallback<void(base::DictValue)> callback);
  void Dispatch(const base::DictValue& params,
                std::shared_ptr<std::atomic_bool> cancelled,
                base::OnceCallback<void(base::DictValue)> callback);

 private:
  class Job;
  std::map<std::string, scoped_refptr<Job>> jobs_;
};
}  // namespace aux
#endif
