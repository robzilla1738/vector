// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#ifndef CHROME_BROWSER_UI_AUX_IMAGE_NORMALIZE_H_
#define CHROME_BROWSER_UI_AUX_IMAGE_NORMALIZE_H_
#include <atomic>
#include <memory>

#include "base/functional/callback.h"
#include "base/values.h"
namespace aux {
void NormalizeImage(const base::DictValue& params,
                    std::shared_ptr<std::atomic_bool> cancelled,
                    base::OnceCallback<void(base::DictValue)> callback);
}
#endif
