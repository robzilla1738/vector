// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
#include <climits>
#include <memory>
#include <utility>

#include "base/functional/bind.h"
#include "base/functional/callback_helpers.h"
#include "base/no_destructor.h"
#include "base/unguessable_token.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/ui/aux/desktop_context_mac.h"
#include "chrome/browser/ui/aux/runtime_host.h"
#include "chrome/browser/ui/aux/tab_catalog.h"
#include "components/prefs/pref_service.h"
namespace {
constexpr char kConsent[] = "aux.desktop_context.consent";
constexpr char kLabs[] = "aux.desktop_context.labs";
// Ownership remains occupied until the original AX/Vision work has joined.
std::string& ProcessLease() {
  static base::NoDestructor<std::string> lease;
  return *lease;
}
base::DictValue Fault(std::string code, std::string message) {
  return base::DictValue().Set("error",
                               base::DictValue()
                                   .Set("code", std::move(code))
                                   .Set("message", std::move(message)));
}
base::DictValue Result(base::DictValue value) {
  return base::DictValue().Set("result", std::move(value));
}
const base::DictValue& ConsentSettings(Profile* profile) {
  const auto* settings =
      profile->GetPrefs()->GetDict(kConsent).FindDict("settings");
  static const base::NoDestructor<base::DictValue> empty;
  return settings ? *settings : *empty;
}
int ConsentRevision(Profile* profile) {
  return profile->GetPrefs()
      ->GetDict(kConsent)
      .FindInt("consentRevision")
      .value_or(0);
}
bool LiveWorkspace(Profile* profile, const base::DictValue& settings) {
  const auto* workspace = settings.FindString("workspaceId");
  const auto* catalog = aux::TabCatalog::GetForProfile(profile);
  return workspace && catalog && catalog->HasRuntimeWorkspace(*workspace);
}
}  // namespace
bool AuxRuntimeHost::DesktopContextLeaseCurrent(const std::string& lease,
                                                int revision) const {
  if (shutting_down_ || profile_->IsOffTheRecord() || lease.empty() ||
      lease != desktop_context_lease_ || lease != ProcessLease() ||
      !desktop_context_generation_ ||
      admitted_native_generation_ != desktop_context_generation_ ||
      admitted_native_generation_ <= retired_native_generation_ ||
      !profile_->GetPrefs()->GetBoolean(kLabs)) {
    return false;
  }
  const auto& consent = ConsentSettings(profile_);
  return consent.FindInt("revision") == revision &&
         consent.FindBool("enabled").value_or(false) &&
         !consent.FindBool("paused").value_or(false) &&
         LiveWorkspace(profile_, consent);
}
base::DictValue AuxRuntimeHost::DesktopContextStatus() const {
  auto status = desktop_context_->Status();
  status.Set("consentRevision", ConsentRevision(profile_));
  return status;
}
struct AuxRuntimeHost::DesktopContextDrain {
  int pending = 0;
  std::vector<base::OnceClosure> completions;
  void Finish() {
    if (pending) {
      return;
    }
    auto ready = std::move(completions);
    for (auto& completion : ready) {
      std::move(completion).Run();
    }
  }
};
void AuxRuntimeHost::RetireDesktopContext(base::OnceClosure completion) {
  auto original = std::move(desktop_context_);
  auto lease = std::exchange(desktop_context_lease_, {});
  desktop_context_generation_ = 0;
  if (!desktop_context_drain_) {
    desktop_context_drain_ = std::make_shared<DesktopContextDrain>();
  }
  auto drain = desktop_context_drain_;
  drain->completions.push_back(std::move(completion));
  if (!original) {
    drain->Finish();
    return;
  }
  ++drain->pending;
  original->Stop(base::BindOnce(
      [](std::shared_ptr<aux::DesktopContextMac> original,
         std::shared_ptr<DesktopContextDrain> drain, std::string lease) {
        if (!lease.empty() && ProcessLease() == lease) {
          ProcessLease().clear();
        }
        --drain->pending;
        drain->Finish();
      },
      original, drain, std::move(lease)));
}
void AuxRuntimeHost::SetDesktopContextLabs(bool enabled) {
  profile_->GetPrefs()->SetBoolean(kLabs, enabled);
  if (!enabled) {
    RetireDesktopContext(base::DoNothing());
  }
}
void AuxRuntimeHost::HandleNativeDesktopContext(
    const base::DictValue& params,
    uint64_t generation,
    base::OnceCallback<void(base::DictValue)> callback) {
  const auto* op = params.FindString("op");
  if (!op || shutting_down_ || profile_->IsOffTheRecord() || !generation ||
      generation != admitted_native_generation_ ||
      generation <= retired_native_generation_) {
    std::move(callback).Run(
        Fault("permission_denied",
              "Desktop context requires its original normal Profile"));
    return;
  }
  const auto window_current = [&](const std::string* token) {
    const auto found =
        token ? turn_contexts_.find(*token) : turn_contexts_.end();
    return found != turn_contexts_.end() &&
           found->second.generation == generation &&
           TurnContextCurrent(found->second);
  };
  const auto create = [&] {
    if (!desktop_context_) {
      desktop_context_ =
          std::make_shared<aux::DesktopContextMac>(base::BindRepeating(
              [](base::WeakPtr<AuxRuntimeHost> host, const std::string& lease,
                 int revision) {
                return host &&
                       host->DesktopContextLeaseCurrent(lease, revision);
              },
              weak_factory_.GetWeakPtr()));
    }
  };
  if (*op == "status") {
    create();
    auto status = DesktopContextStatus();
    const auto& consent = ConsentSettings(profile_);
    if (desktop_context_lease_.empty()) {
      status.Set("configurationRevision",
                 consent.FindInt("revision").value_or(0));
      status.Set("phase", consent.FindBool("enabled").value_or(false)
                              ? "unavailable"
                              : "off");
      status.Set("reason", consent.FindBool("enabled").value_or(false)
                               ? "retired"
                               : "none");
    }
    std::move(callback).Run(Result(
        base::DictValue().Set("op", *op).Set("status", std::move(status))));
    return;
  }
  if (*op == "apps") {
    if (!window_current(params.FindString("token"))) {
      std::move(callback).Run(
          Fault("ref_stale", "Original Settings window retired"));
      return;
    }
    std::move(callback).Run(Result(base::DictValue().Set("op", *op).Set(
        "apps", aux::DesktopContextMac::Apps())));
    return;
  }
  if (*op == "stop") {
    RetireDesktopContext(base::BindOnce(
        [](base::OnceCallback<void(base::DictValue)> callback) {
          std::move(callback).Run(
              Result(base::DictValue().Set("op", "stop").Set("ok", true)));
        },
        std::move(callback)));
    return;
  }
  if (*op == "configure" || *op == "attach") {
    const auto* settings = params.FindDict("settings");
    const auto& persisted = ConsentSettings(profile_);
    const auto revision =
        settings ? settings->FindInt("revision") : std::nullopt;
    const bool explicit_change = *op == "configure";
    const auto expected_consent = params.FindInt("expectedConsentRevision");
    if (!settings || !revision || *revision < 0 ||
        (explicit_change ? (!window_current(params.FindString("token")) ||
                            !expected_consent ||
                            *expected_consent != ConsentRevision(profile_) ||
                            *expected_consent == INT_MAX)
                         : *settings != persisted)) {
      std::move(callback).Run(Fault(
          "ref_stale",
          "Desktop capture consent or its original Settings window changed"));
      return;
    }
    const bool enabled = settings->FindBool("enabled").value_or(false);
    const bool paused = settings->FindBool("paused").value_or(false);
    if (enabled && (!profile_->GetPrefs()->GetBoolean(kLabs) ||
                    !LiveWorkspace(profile_, *settings))) {
      std::move(callback).Run(
          Fault("permission_denied",
                "Choose an available normal Space and enable this feature"));
      return;
    }
    const auto* apps = settings->FindList("selectedApps");
    if (!apps || (enabled && apps->empty())) {
      std::move(callback).Run(
          Fault("invalid_params", "Choose eligible apps explicitly"));
      return;
    }
    for (const auto& app : *apps) {
      const auto* bundle = app.GetDict().FindString("bundleId");
      if (!bundle || !aux::DesktopContextMac::AppSupported(*bundle)) {
        std::move(callback).Run(Fault("permission_denied",
                                      "Browser apps, credential stores and "
                                      "unavailable apps cannot be captured"));
        return;
      }
    }
    if (enabled && !paused && !ProcessLease().empty() &&
        ProcessLease() != desktop_context_lease_) {
      std::move(callback).Run(Fault(
          "conflict", "Another Profile is finishing its desktop capture work"));
      return;
    }
    const auto settings_copy = settings->Clone();
    const int original_consent = ConsentRevision(profile_);
    const std::string operation = *op;
    const std::string token =
        params.FindString("token") ? *params.FindString("token") : "";
    RetireDesktopContext(base::BindOnce(
        [](base::WeakPtr<AuxRuntimeHost> host, uint64_t generation,
           bool explicit_change, int original_consent, std::string token,
           std::string operation, base::DictValue settings,
           base::OnceCallback<void(base::DictValue)> callback) {
          if (!host || host->shutting_down_ ||
              host->admitted_native_generation_ != generation ||
              generation <= host->retired_native_generation_) {
            std::move(callback).Run(
                Fault("ref_stale", "Original desktop capture owner retired"));
            return;
          }
          if (explicit_change) {
            if (ConsentRevision(host->profile_) != original_consent) {
              std::move(callback).Run(Fault(
                  "conflict",
                  "Desktop consent changed while its original work retired"));
              return;
            }
            const auto owner = host->turn_contexts_.find(token);
            if (owner == host->turn_contexts_.end() ||
                owner->second.generation != generation ||
                !host->TurnContextCurrent(owner->second)) {
              std::move(callback).Run(Fault(
                  "ref_stale", "Original desktop Settings window retired"));
              return;
            }
          } else if (settings != ConsentSettings(host->profile_)) {
            std::move(callback).Run(Fault(
                "ref_stale", "Original persisted desktop consent changed"));
            return;
          }
          const bool active = settings.FindBool("enabled").value_or(false) &&
                              !settings.FindBool("paused").value_or(false);
          if (active && (!ProcessLease().empty() ||
                         !host->profile_->GetPrefs()->GetBoolean(kLabs) ||
                         !LiveWorkspace(host->profile_, settings))) {
            std::move(callback).Run(Fault(
                "conflict", "Desktop capture owner or destination changed"));
            return;
          }
          if (explicit_change) {
            host->profile_->GetPrefs()->SetDict(
                kConsent, base::DictValue()
                              .Set("consentRevision", original_consent + 1)
                              .Set("settings", settings.Clone()));
          }
          host->desktop_context_ =
              std::make_shared<aux::DesktopContextMac>(base::BindRepeating(
                  [](base::WeakPtr<AuxRuntimeHost> host,
                     const std::string& lease, int revision) {
                    return host &&
                           host->DesktopContextLeaseCurrent(lease, revision);
                  },
                  host));
          if (active) {
            host->desktop_context_lease_ =
                base::UnguessableToken::Create().ToString();
            ProcessLease() = host->desktop_context_lease_;
            host->desktop_context_generation_ = generation;
          }
          host->desktop_context_->Configure(settings,
                                            host->desktop_context_lease_);
          std::move(callback).Run(
              Result(base::DictValue()
                         .Set("op", operation)
                         .Set("status", host->DesktopContextStatus())));
        },
        weak_factory_.GetWeakPtr(), generation, explicit_change,
        original_consent, token, operation, settings_copy.Clone(),
        std::move(callback)));
    return;
  }
  if (*op == "permission") {
    const auto* kind = params.FindString("kind");
    const auto revision = params.FindInt("revision");
    if (!window_current(params.FindString("token")) || !desktop_context_ ||
        !revision ||
        ConsentSettings(profile_).FindInt("revision") != *revision || !kind ||
        !ConsentSettings(profile_).FindBool("enabled").value_or(false) ||
        !profile_->GetPrefs()->GetBoolean(kLabs)) {
      std::move(callback).Run(
          Fault("ref_stale", "Original desktop permission control changed"));
      return;
    }
    if (*kind == "accessibility") {
      desktop_context_->RequestAccessibility();
    } else if (*kind == "ocr-picker") {
      desktop_context_->PresentOcrPicker();
    } else {
      std::move(callback).Run(
          Fault("invalid_params", "Unknown desktop permission kind"));
      return;
    }
    std::move(callback).Run(Result(base::DictValue().Set("op", *op).Set(
        "status", DesktopContextStatus())));
    return;
  }
  if (!desktop_context_ || desktop_context_generation_ != generation) {
    std::move(callback).Run(
        Fault("ref_stale", "Original desktop capture lease retired"));
    return;
  }
  if (*op == "take") {
    const auto* lease = params.FindString("leaseId");
    if (!lease || *lease != desktop_context_lease_) {
      std::move(callback).Run(
          Fault("ref_stale", "Original desktop lease changed"));
      return;
    }
    auto capture = desktop_context_->Take(*lease);
    std::move(callback).Run(Result(base::DictValue().Set("op", *op).Set(
        "capture",
        capture.empty() ? base::Value() : base::Value(std::move(capture)))));
    return;
  }
  if (*op == "validate") {
    const auto* source = params.FindDict("source");
    if (!source) {
      std::move(callback).Run(
          Fault("invalid_params", "Desktop source identity is required"));
      return;
    }
    auto original = desktop_context_;
    original->Validate(
        *source,
        base::BindOnce(
            [](std::shared_ptr<aux::DesktopContextMac> original,
               base::OnceCallback<void(base::DictValue)> callback, bool valid) {
              std::move(callback).Run(Result(
                  base::DictValue().Set("op", "validate").Set("valid", valid)));
            },
            original, std::move(callback)));
    return;
  }
  if (*op == "acknowledge") {
    const auto* lease = params.FindString("leaseId");
    const auto* capture = params.FindString("captureId");
    if (!lease || !capture ||
        !desktop_context_->Acknowledge(*lease, *capture)) {
      std::move(callback).Run(Fault(
          "ref_stale", "Original desktop capture acknowledgement changed"));
      return;
    }
    std::move(callback).Run(
        Result(base::DictValue().Set("op", *op).Set("ok", true)));
    return;
  }
  std::move(callback).Run(
      Fault("invalid_params", "Unknown desktop capture operation"));
}
