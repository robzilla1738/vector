// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CHROME_BROWSER_UI_AUX_RUNTIME_CHILD_RETIREMENT_H_
#define CHROME_BROWSER_UI_AUX_RUNTIME_CHILD_RETIREMENT_H_

#include <poll.h>
#include <signal.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <cstdint>

#include "base/process/process.h"
#include "base/process/process_handle.h"
#include "base/time/time.h"

namespace aux {

enum class RuntimeHandshakeWait { kReadable, kCancelled, kTimedOut, kFailed };

// Authentication remains on its original worker/socket, but browser teardown
// can retire that original wait without waiting out the normal startup timeout.
inline RuntimeHandshakeWait WaitForRuntimeHandshake(
    int fd,
    base::TimeTicks deadline,
    const std::atomic<int64_t>& browser_shutdown_deadline) {
  for (;;) {
    if (browser_shutdown_deadline.load()) {
      return RuntimeHandshakeWait::kCancelled;
    }
    const auto remaining = deadline - base::TimeTicks::Now();
    if (!remaining.is_positive()) {
      return RuntimeHandshakeWait::kTimedOut;
    }
    pollfd pending = {fd, POLLIN, 0};
    const int result = poll(
        &pending, 1,
        static_cast<int>(std::min<int64_t>(
            100, remaining.InMillisecondsRoundedUp())));
    if (result < 0) {
      if (errno == EINTR) {
        continue;
      }
      return RuntimeHandshakeWait::kFailed;
    }
    if (result == 0) {
      continue;
    }
    if (browser_shutdown_deadline.load()) {
      return RuntimeHandshakeWait::kCancelled;
    }
    return pending.revents & POLLIN ? RuntimeHandshakeWait::kReadable
                                   : RuntimeHandshakeWait::kFailed;
  }
}

struct RuntimeChildRetirement {
  bool exited = false;
  bool forced = false;
  int exit_code = -1;

  // The runtime's exit0 path follows its joined shutdown. Forced/signal/nonzero
  // exit proves only parent death, never descendant/resource retirement.
  bool GracefulCleanupAcknowledged() const {
    return exited && !forced && exit_code == 0;
  }
};

// Only the original unreaped direct child is signalable. A PID alone is not
// authority, and a missing creation time never permits a replacement process.
inline bool OriginalRuntimeChild(const base::Process& process,
                                 base::Time creation_time) {
  return process.IsValid() && !creation_time.is_null() &&
         base::GetParentProcessId(process.Pid()) == getpid() &&
         process.CreationTime() == creation_time;
}

// Transport closure already requested the runtime's joined graceful shutdown.
// SIGTERM preserves its existing shutdown handler. A nonresponsive original
// child is forcibly interrupted only within the same absolute retirement
// budget; an unacknowledged exit is never permission to delete its directories.
inline RuntimeChildRetirement RetireOriginalRuntimeChild(
    base::Process& process,
    base::Time creation_time,
    base::TimeTicks deadline,
    bool& force_requested) {
  RuntimeChildRetirement result;
  result.forced = force_requested;
  if (!process.IsValid()) {
    result.exited = true;
    return result;
  }
  if (process.WaitForExitWithTimeout(base::TimeDelta(), &result.exit_code)) {
    result.exited = true;
    return result;
  }
  const auto remaining = [&] {
    return std::max(base::TimeDelta(), deadline - base::TimeTicks::Now());
  };
  if (force_requested) {
    result.exited =
        process.WaitForExitWithTimeout(remaining(), &result.exit_code);
    return result;
  }
  if (!OriginalRuntimeChild(process, creation_time) ||
      !process.Terminate(0, false)) {
    return result;
  }
  if (process.WaitForExitWithTimeout(
          std::min(base::Seconds(3), remaining()), &result.exit_code)) {
    result.exited = true;
    return result;
  }
  // Recheck the actual kernel identity immediately before the destructive
  // signal. This function is the only waiter/reaper of this launched child.
  if (!OriginalRuntimeChild(process, creation_time) ||
      kill(process.Pid(), SIGKILL) != 0) {
    return result;
  }
  force_requested = true;
  result.forced = true;
  result.exited =
      process.WaitForExitWithTimeout(remaining(), &result.exit_code);
  return result;
}

}  // namespace aux

#endif  // CHROME_BROWSER_UI_AUX_RUNTIME_CHILD_RETIREMENT_H_
