// Copyright 2026 The Aux Authors
#include "chrome/browser/ui/aux/desktop_context_mac.h"

#import <ApplicationServices/ApplicationServices.h>
#import <Cocoa/Cocoa.h>
#import <ScreenCaptureKit/ScreenCaptureKit.h>
#import <Vision/Vision.h>

#include <algorithm>
#include <atomic>
#include <climits>
#include <cmath>
#include <set>
#include <vector>

#include "base/apple/scoped_cftyperef.h"
#include "base/functional/bind.h"
#include "base/functional/callback_helpers.h"
#include "base/no_destructor.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/sys_string_conversions.h"
#include "base/task/sequenced_task_runner.h"
#include "base/task/thread_pool.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "base/uuid.h"
#include "crypto/sha2.h"
#include "ui/base/idle/idle.h"

namespace {
using CF = base::apple::ScopedCFTypeRef<CFTypeRef>;
CF Attribute(AXUIElementRef element, CFStringRef name) {
  CFTypeRef value = nullptr;
  AXUIElementSetMessagingTimeout(element, 0.04);
  if (AXUIElementCopyAttributeValue(element, name, &value) != kAXErrorSuccess) {
    return CF();
  }
  return CF(value);
}
std::string String(CFTypeRef value) {
  return value && CFGetTypeID(value) == CFStringGetTypeID() &&
                 CFStringGetLength(static_cast<CFStringRef>(value)) <= 32768
             ? base::SysCFStringRefToUTF8(static_cast<CFStringRef>(value))
             : "";
}
std::string Text(AXUIElementRef element, CFStringRef name) {
  return String(Attribute(element, name).get());
}
CF VisibleChildren(AXUIElementRef element, size_t maximum) {
  CFArrayRef values = nullptr;
  AXUIElementSetMessagingTimeout(element, 0.04);
  if (AXUIElementCopyAttributeValues(element, kAXVisibleChildrenAttribute, 0,
                                     maximum, &values) != kAXErrorSuccess) {
    return CF();
  }
  return CF(values);
}
bool ExcludedApp(const std::string& bundle) {
  static const base::NoDestructor<std::set<std::string>> excluded(
      {"com.1password.1password", "com.agilebits.onepassword7",
       "com.apple.keychainaccess", "com.apple.Passwords",
       "com.bitwarden.desktop", "com.lastpass.LastPass",
       "com.dashlane.Dashlane"});
  static const base::NoDestructor<std::set<std::string>> browsers(
      {"com.apple.Safari", "com.google.Chrome", "com.google.Chrome.canary",
       "org.chromium.Chromium", "com.microsoft.edgemac", "com.brave.Browser",
       "org.mozilla.firefox", "company.thebrowser.Browser",
       "company.thebrowser.dia", "com.aside.browser"});
  if (excluded->contains(bundle) || browsers->contains(bundle) ||
      bundle == base::SysNSStringToUTF8(
                    NSRunningApplication.currentApplication.bundleIdentifier)) {
    return true;
  }
  NSURL* location = [NSWorkspace.sharedWorkspace
      URLForApplicationWithBundleIdentifier:base::SysUTF8ToNSString(bundle)];
  NSBundle* application = location ? [NSBundle bundleWithURL:location] : nil;
  id types = application.infoDictionary[@"CFBundleURLTypes"];
  if (types && ![types isKindOfClass:NSArray.class]) {
    return true;
  }
  for (id type in types) {
    if (![type isKindOfClass:NSDictionary.class]) {
      return true;
    }
    id schemes = type[@"CFBundleURLSchemes"];
    if (schemes && ![schemes isKindOfClass:NSArray.class]) {
      return true;
    }
    for (id scheme in schemes) {
      if (![scheme isKindOfClass:NSString.class]) {
        return true;
      }
      if ([[scheme lowercaseString] isEqualToString:@"http"] ||
          [[scheme lowercaseString] isEqualToString:@"https"]) {
        return true;
      }
    }
  }
  return false;
}
bool IsElement(CFTypeRef value) {
  return value && CFGetTypeID(value) == AXUIElementGetTypeID();
}
bool Sensitive(AXUIElementRef element) {
  auto role = Text(element, kAXRoleAttribute);
  auto subrole = Text(element, kAXSubroleAttribute);
  if (role.empty() ||
      subrole == base::SysCFStringRefToUTF8(kAXSecureTextFieldSubrole)) {
    return true;
  }
  // An editable field without a known subrole is not permission to OCR around
  // it.
  return role == "AXTextField" && subrole.empty();
}
bool Bounds(AXUIElementRef element, CGRect* result) {
  auto position = Attribute(element, kAXPositionAttribute);
  auto size = Attribute(element, kAXSizeAttribute);
  CGPoint point;
  CGSize extent;
  if (!position || !size || CFGetTypeID(position.get()) != AXValueGetTypeID() ||
      CFGetTypeID(size.get()) != AXValueGetTypeID() ||
      !AXValueGetValue(static_cast<AXValueRef>(position.get()),
                       static_cast<AXValueType>(kAXValueCGPointType), &point) ||
      !AXValueGetValue(static_cast<AXValueRef>(size.get()),
                       static_cast<AXValueType>(kAXValueCGSizeType), &extent)) {
    return false;
  }
  *result = CGRectMake(point.x, point.y, extent.width, extent.height);
  return extent.width > 0 && extent.height > 0;
}
struct Sample {
  base::DictValue value;
  base::apple::ScopedCFTypeRef<AXUIElementRef> window{nullptr};
  bool safe = false;
  CGRect bounds = CGRectZero;
};
// Runs only on the dedicated sequenced MayBlock runner. Every AX IPC is
// bounded; neither whole-document editable values nor unknown visibility are
// admitted.
Sample ReadVisible(int pid,
                   const std::shared_ptr<std::atomic_bool>& cancelled) {
  Sample result;
  const auto deadline = base::TimeTicks::Now() + base::Milliseconds(400);
  base::apple::ScopedCFTypeRef<AXUIElementRef> app(
      AXUIElementCreateApplication(pid));
  auto focused = Attribute(app.get(), kAXFocusedUIElementAttribute);
  auto window = Attribute(app.get(), kAXFocusedWindowAttribute);
  if (cancelled->load() || !IsElement(focused.get()) ||
      !IsElement(window.get()) ||
      Sensitive(static_cast<AXUIElementRef>(focused.get()))) {
    return result;
  }
  result.window.reset(static_cast<AXUIElementRef>(CFRetain(window.get())));
  CGRect window_bounds;
  if (!Bounds(result.window.get(), &window_bounds)) {
    return result;
  }
  result.bounds = window_bounds;
  std::string selection = Text(static_cast<AXUIElementRef>(focused.get()),
                               kAXSelectedTextAttribute);
  if (selection.size() > 4096) {
    selection.clear();
  }
  std::string text;
  std::string document_url = Text(result.window.get(), kAXDocumentAttribute);
  if (!document_url.starts_with("https://") &&
      !document_url.starts_with("http://")) {
    document_url.clear();
  }
  std::vector<base::apple::ScopedCFTypeRef<AXUIElementRef>> pending;
  pending.emplace_back(static_cast<AXUIElementRef>(CFRetain(window.get())));
  size_t visited = 0;
  while (!pending.empty() && visited++ < 256 && text.size() < 32768 &&
         !cancelled->load() && base::TimeTicks::Now() < deadline) {
    auto element = std::move(pending.back());
    pending.pop_back();
    CGRect bounds;
    if (!Bounds(element.get(), &bounds) ||
        !CGRectContainsRect(window_bounds, bounds)) {
      continue;
    }
    auto hidden = Attribute(element.get(), kAXHiddenAttribute);
    if (hidden && CFGetTypeID(hidden.get()) == CFBooleanGetTypeID() &&
        CFBooleanGetValue(static_cast<CFBooleanRef>(hidden.get()))) {
      continue;
    }
    const auto role = Text(element.get(), kAXRoleAttribute);
    if (role == "AXWebArea" && document_url.empty()) {
      auto url = Attribute(element.get(), kAXURLAttribute);
      if (url && CFGetTypeID(url.get()) == CFURLGetTypeID()) {
        document_url = String(CFURLGetString(static_cast<CFURLRef>(url.get())));
      } else {
        document_url = String(url.get());
      }
      if (!document_url.starts_with("https://") &&
          !document_url.starts_with("http://")) {
        document_url.clear();
      }
    }
    if (role == "AXTextArea" || role == "AXTextField") {
      if (Sensitive(element.get())) {
        return {};
      }
      auto range = Attribute(element.get(), kAXVisibleCharacterRangeAttribute);
      CFRange visible;
      if (range && CFGetTypeID(range.get()) == AXValueGetTypeID() &&
          AXValueGetValue(static_cast<AXValueRef>(range.get()),
                          static_cast<AXValueType>(kAXValueCFRangeType),
                          &visible) &&
          visible.location >= 0 && visible.length > 0 &&
          visible.length <= 32768) {
        CFTypeRef substring = nullptr;
        if (AXUIElementCopyParameterizedAttributeValue(
                element.get(), kAXStringForRangeParameterizedAttribute,
                range.get(), &substring) == kAXErrorSuccess) {
          CF owned(substring);
          auto value = String(owned.get());
          if (text.size() + value.size() + 1 <= 32768) {
            text += value + "\n";
          }
        }
      }
    } else if (role == "AXStaticText") {
      auto value = Text(element.get(), kAXValueAttribute);
      if (!value.empty() && text.size() + value.size() + 1 <= 32768) {
        text += value + "\n";
      }
    }
    auto children = VisibleChildren(
        element.get(),
        256 - std::min(visited + pending.size(), static_cast<size_t>(256)));
    if (children && CFGetTypeID(children.get()) == CFArrayGetTypeID()) {
      auto array = static_cast<CFArrayRef>(children.get());
      for (CFIndex index = CFArrayGetCount(array) - 1;
           index >= 0 && pending.size() + visited < 256; --index) {
        auto* child = CFArrayGetValueAtIndex(array, index);
        if (IsElement(child)) {
          pending.emplace_back(static_cast<AXUIElementRef>(CFRetain(child)));
        }
      }
    }
  }
  // A timeout or node overflow is partial visible text, never a full-document
  // fallback.
  if (cancelled->load()) {
    return {};
  }
  result.safe = true;
  if (text.empty() && !selection.empty()) {
    text = selection;
  }
  result.value.Set("text", text);
  result.value.Set("selection", selection);
  if (!document_url.empty() && document_url.size() <= 8192) {
    result.value.Set("documentUrl", document_url);
  }
  auto title = Text(result.window.get(), kAXTitleAttribute);
  result.value.Set("windowTitle", title.size() <= 500 ? title : "");
  return result;
}
bool SelectedWindowIsForeground(int pid, CGWindowID selected, CGRect bounds) {
  CF windows(CGWindowListCopyWindowInfo(
      kCGWindowListOptionOnScreenOnly | kCGWindowListExcludeDesktopElements,
      kCGNullWindowID));
  if (!windows) {
    return false;
  }
  auto array = static_cast<CFArrayRef>(windows.get());
  for (CFIndex index = 0; index < CFArrayGetCount(array); ++index) {
    auto dictionary =
        static_cast<CFDictionaryRef>(CFArrayGetValueAtIndex(array, index));
    auto owner = static_cast<CFNumberRef>(
        CFDictionaryGetValue(dictionary, kCGWindowOwnerPID));
    auto number = static_cast<CFNumberRef>(
        CFDictionaryGetValue(dictionary, kCGWindowNumber));
    auto layer = static_cast<CFNumberRef>(
        CFDictionaryGetValue(dictionary, kCGWindowLayer));
    int owner_pid = 0, window_number = 0, window_layer = -1;
    if (!owner || !number || !layer ||
        !CFNumberGetValue(owner, kCFNumberIntType, &owner_pid) ||
        !CFNumberGetValue(number, kCFNumberIntType, &window_number) ||
        !CFNumberGetValue(layer, kCFNumberIntType, &window_layer)) {
      continue;
    }
    if (owner_pid != pid || window_layer != 0) {
      continue;
    }
    CGRect actual;
    auto rectangle = static_cast<CFDictionaryRef>(
        CFDictionaryGetValue(dictionary, kCGWindowBounds));
    return static_cast<CGWindowID>(window_number) == selected && rectangle &&
           CGRectMakeWithDictionaryRepresentation(rectangle, &actual) &&
           CGRectEqualToRect(actual, bounds);
  }
  return false;
}
}  // namespace

API_AVAILABLE(macos(14.0))
@interface AuxDesktopPickerObserver : NSObject <SCContentSharingPickerObserver>
@property(nonatomic, assign) base::WeakPtr<aux::DesktopContextMac> owner;
@end
@implementation AuxDesktopPickerObserver
@synthesize owner = _owner;
- (void)contentSharingPicker:(SCContentSharingPicker*)picker
         didUpdateWithFilter:(SCContentFilter*)filter
                   forStream:(SCStream*)stream {
  auto owner = _owner;
  dispatch_async(dispatch_get_main_queue(), ^{
    if (owner) {
      owner->PickerSelected((__bridge void*)filter);
    }
  });
}
- (void)contentSharingPicker:(SCContentSharingPicker*)picker
          didCancelForStream:(SCStream*)stream {
  auto owner = _owner;
  dispatch_async(dispatch_get_main_queue(), ^{
    if (owner) {
      owner->PickerStopped();
    }
  });
}
- (void)contentSharingPickerStartDidFailWithError:(NSError*)error {
  auto owner = _owner;
  dispatch_async(dispatch_get_main_queue(), ^{
    if (owner) {
      owner->PickerStopped();
    }
  });
}
@end

namespace aux {
struct DesktopContextMac::Impl {
  explicit Impl(CurrentLease current)
      : current_lease(std::move(current)),
        worker(base::ThreadPool::CreateSequencedTaskRunner(
            {base::MayBlock(), base::TaskPriority::BEST_EFFORT})) {}
  CurrentLease current_lease;
  scoped_refptr<base::SequencedTaskRunner> worker;
  base::RepeatingTimer timer;
  base::CallbackListSubscription lock_subscription;
  std::shared_ptr<std::atomic_bool> cancelled =
      std::make_shared<std::atomic_bool>(false);
  base::DictValue settings;
  base::DictValue pending;
  base::apple::ScopedCFTypeRef<AXUIElementRef> pending_window;
  id __strong picker_observer = nil;
  SCContentFilter* __strong filter = nil;
  VNRecognizeTextRequest* __strong active_ocr = nil;
  std::string lease;
  std::string epoch;
  std::string last_text;
  int revision = 0;
  int generation = 0;
  int pid = 0;
  int filter_pid = 0;
  CGWindowID filter_window = kCGNullWindowID;
  CGRect focused_bounds = CGRectZero;
  std::string document_url;
  bool enabled = false;
  bool paused = false;
  bool ocr = false;
  bool busy = false;
  bool locked = false;
  bool suspended = false;
  int ocr_work = 0;
  int stop_barriers = 0;
  NSMutableArray* __strong notifications = [[NSMutableArray alloc] init];
  size_t dropped = 0;
  base::TimeTicks last_capture;
  std::set<std::string> apps;
  std::vector<base::OnceClosure> stopped;
};
DesktopContextMac::DesktopContextMac(CurrentLease current)
    : impl_(std::make_unique<Impl>(std::move(current))) {
  ui::InitIdleMonitor();
  impl_->locked = ui::CheckIdleStateIsLocked();
  auto weak = weak_factory_.GetWeakPtr();
  NSNotificationCenter* center = NSWorkspace.sharedWorkspace.notificationCenter;
  for (NSNotificationName name in @[
         NSWorkspaceWillSleepNotification,
         NSWorkspaceScreensDidSleepNotification,
         NSWorkspaceSessionDidResignActiveNotification
       ]) {
    [impl_->notifications
        addObject:[center addObserverForName:name
                                      object:nil
                                       queue:NSOperationQueue.mainQueue
                                  usingBlock:^(NSNotification* note) {
                                    if (weak) {
                                      weak->Suspend(true);
                                    }
                                  }]];
  }
  for (NSNotificationName name in @[
         NSWorkspaceDidWakeNotification, NSWorkspaceScreensDidWakeNotification,
         NSWorkspaceSessionDidBecomeActiveNotification
       ]) {
    [impl_->notifications
        addObject:[center addObserverForName:name
                                      object:nil
                                       queue:NSOperationQueue.mainQueue
                                  usingBlock:^(NSNotification* note) {
                                    if (weak) {
                                      weak->Suspend(false);
                                    }
                                  }]];
  }
  impl_->lock_subscription = ui::AddScreenLockCallback(base::BindRepeating(
      [](base::WeakPtr<DesktopContextMac> owner, bool locked) {
        if (!owner) {
          return;
        }
        owner->impl_->locked = locked;
        if (locked) {
          owner->impl_->cancelled->store(true);
          [owner->impl_->active_ocr cancel];
          owner->impl_->pending.clear();
          owner->impl_->pending_window.reset();
          owner->impl_->filter = nil;
        } else {
          owner->impl_->cancelled = std::make_shared<std::atomic_bool>(false);
        }
      },
      weak_factory_.GetWeakPtr()));
}
DesktopContextMac::~DesktopContextMac() {
  impl_->cancelled->store(true);
  [impl_->active_ocr cancel];
  impl_->timer.Stop();
  for (id observer in impl_->notifications) {
    [NSWorkspace.sharedWorkspace.notificationCenter removeObserver:observer];
  }
  if (@available(macOS 14.0, *)) {
    if (impl_->picker_observer) {
      [[SCContentSharingPicker sharedPicker]
          removeObserver:impl_->picker_observer];
    }
  }
}
bool DesktopContextMac::Current() const {
  return impl_->enabled && !impl_->apps.empty() && !impl_->paused &&
         !impl_->locked && !impl_->suspended && !ui::CheckIdleStateIsLocked() &&
         AXIsProcessTrusted() && !impl_->lease.empty() &&
         impl_->current_lease.Run(impl_->lease, impl_->revision);
}
base::DictValue DesktopContextMac::Status() const {
  const bool trusted = AXIsProcessTrusted();
  const bool locked =
      impl_->locked || impl_->suspended || ui::CheckIdleStateIsLocked();
  const char* phase = !impl_->enabled || impl_->lease.empty() ? "off"
                      : impl_->paused                         ? "paused"
                      : locked                                ? "locked"
                      : !trusted ? "permission-required"
                                 : "running";
  const char* reason = impl_->enabled && impl_->lease.empty() ? "retired"
                       : !trusted                             ? "permission"
                       : locked                               ? "locked"
                                                              : "none";
  base::DictValue value;
  value.Set("supported", true);
  value.Set("phase", phase);
  value.Set("accessibilityTrusted", trusted);
  if (@available(macOS 15.2, *)) {
    value.Set("ocrSupported", true);
  } else {
    value.Set("ocrSupported", false);
  }
  value.Set("pickerGrantActive", impl_->filter != nil);
  value.Set("configurationRevision", impl_->revision);
  value.Set("dropped", static_cast<int>(std::min(
                           impl_->dropped, static_cast<size_t>(INT_MAX))));
  value.Set("reason", reason);
  if (Current()) {
    value.Set("leaseId", impl_->lease);
  } else {
    value.Set("leaseId", base::Value());
  }
  return value;
}
bool DesktopContextMac::AppSupported(const std::string& bundle) {
  return !ExcludedApp(bundle) &&
         [NSWorkspace.sharedWorkspace
             URLForApplicationWithBundleIdentifier:base::SysUTF8ToNSString(
                                                       bundle)] != nil;
}
base::ListValue DesktopContextMac::Apps() {
  base::ListValue apps;
  std::set<std::string> seen;
  for (NSRunningApplication* application in NSWorkspace.sharedWorkspace
           .runningApplications) {
    if (application.activationPolicy != NSApplicationActivationPolicyRegular ||
        application.processIdentifier ==
            NSProcessInfo.processInfo.processIdentifier) {
      continue;
    }
    const auto bundle = base::SysNSStringToUTF8(application.bundleIdentifier);
    if (bundle.empty() || !AppSupported(bundle) ||
        !seen.insert(bundle).second) {
      continue;
    }
    base::DictValue app;
    app.Set("bundleId", bundle);
    app.Set("displayName", base::SysNSStringToUTF8(application.localizedName));
    apps.Append(std::move(app));
    if (seen.size() == 200) {
      break;
    }
  }
  return apps;
}
void DesktopContextMac::Configure(const base::DictValue& settings,
                                  const std::string& lease) {
  impl_->cancelled->store(true);
  [impl_->active_ocr cancel];
  ++impl_->generation;
  impl_->timer.Stop();
  impl_->pending.clear();
  impl_->pending_window.reset();
  impl_->filter = nil;
  impl_->cancelled = std::make_shared<std::atomic_bool>(false);
  impl_->last_text.clear();
  impl_->last_capture = base::TimeTicks();
  impl_->settings = settings.Clone();
  impl_->lease = lease;
  impl_->revision = settings.FindInt("revision").value_or(0);
  impl_->enabled = settings.FindBool("enabled").value_or(false);
  impl_->paused = settings.FindBool("paused").value_or(false);
  impl_->ocr = settings.FindBool("ocrEnabled").value_or(false);
  impl_->apps.clear();
  if (const auto* apps = settings.FindList("selectedApps")) {
    for (const auto& app : *apps) {
      if (app.is_dict()) {
        if (const auto* id = app.GetDict().FindString("bundleId")) {
          if (!ExcludedApp(*id)) {
            impl_->apps.insert(*id);
          }
        }
      }
    }
  }
  if (impl_->enabled && !impl_->paused) {
    impl_->timer.Start(FROM_HERE, base::Milliseconds(750),
                       base::BindRepeating(&DesktopContextMac::Tick,
                                           weak_factory_.GetWeakPtr()));
  }
}
void DesktopContextMac::RequestAccessibility() {
  NSDictionary* options =
      @{(__bridge NSString*)kAXTrustedCheckOptionPrompt : @YES};
  AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)options);
}
void DesktopContextMac::PresentOcrPicker() {
  if (!Current() || !impl_->ocr) {
    return;
  }
  if (@available(macOS 15.2, *)) {
    if (impl_->picker_observer) {
      [[SCContentSharingPicker sharedPicker]
          removeObserver:impl_->picker_observer];
    }
    impl_->picker_observer = [[AuxDesktopPickerObserver alloc] init];
    [(AuxDesktopPickerObserver*)impl_->picker_observer
        setOwner:weak_factory_.GetWeakPtr()];
    SCContentSharingPicker* picker = [SCContentSharingPicker sharedPicker];
    [picker addObserver:impl_->picker_observer];
    SCContentSharingPickerConfiguration* configuration =
        [[SCContentSharingPickerConfiguration alloc] init];
    configuration.allowedPickerModes = SCContentSharingPickerModeSingleWindow;
    NSMutableArray<NSString*>* excluded = [[NSMutableArray alloc] init];
    for (NSRunningApplication* app in NSWorkspace.sharedWorkspace
             .runningApplications) {
      const auto bundle = base::SysNSStringToUTF8(app.bundleIdentifier);
      if (app.bundleIdentifier &&
          (!impl_->apps.contains(bundle) || ExcludedApp(bundle))) {
        [excluded addObject:app.bundleIdentifier];
      }
    }
    configuration.excludedBundleIDs = excluded;
    configuration.allowsChangingSelectedContent = YES;
    picker.defaultConfiguration = configuration;
    picker.active = YES;
    [picker presentPickerUsingContentStyle:SCShareableContentStyleWindow];
  }
}
void DesktopContextMac::PickerSelected(void* opaque) {
  if (@available(macOS 15.2, *)) {
    SCContentFilter* filter = (__bridge SCContentFilter*)opaque;
    if (!Current() || !impl_->ocr || filter.includedWindows.count != 1) {
      PickerStopped();
      return;
    }
    SCWindow* window = filter.includedWindows.firstObject;
    const auto bundle =
        base::SysNSStringToUTF8(window.owningApplication.bundleIdentifier);
    if (!window.owningApplication || !impl_->apps.contains(bundle)) {
      PickerStopped();
      return;
    }
    impl_->filter = filter;
    impl_->filter_pid = window.owningApplication.processID;
    impl_->filter_window = window.windowID;
  }
}
void DesktopContextMac::PickerStopped() {
  impl_->filter = nil;
  impl_->filter_pid = 0;
  impl_->cancelled->store(true);
  [impl_->active_ocr cancel];
  ++impl_->generation;
  impl_->pending.clear();
  impl_->pending_window.reset();
  impl_->cancelled = std::make_shared<std::atomic_bool>(false);
}
void DesktopContextMac::Suspend(bool suspended) {
  impl_->suspended = suspended;
  impl_->cancelled->store(true);
  [impl_->active_ocr cancel];
  ++impl_->generation;
  impl_->pending.clear();
  impl_->pending_window.reset();
  impl_->filter = nil;
  if (!suspended) {
    impl_->cancelled = std::make_shared<std::atomic_bool>(false);
  }
}
void DesktopContextMac::Tick() {
  if (!Current() || impl_->busy) {
    return;
  }
  NSRunningApplication* foreground =
      NSWorkspace.sharedWorkspace.frontmostApplication;
  const auto bundle = base::SysNSStringToUTF8(foreground.bundleIdentifier);
  if (!foreground || ExcludedApp(bundle) || !impl_->apps.contains(bundle)) {
    impl_->pending.clear();
    return;
  }
  if (!impl_->pending.empty()) {
    ++impl_->dropped;
    return;
  }
  if (!impl_->last_capture.is_null() &&
      base::TimeTicks::Now() - impl_->last_capture < base::Seconds(15)) {
    return;
  }
  impl_->busy = true;
  impl_->pid = foreground.processIdentifier;
  impl_->epoch = base::Uuid::GenerateRandomV4().AsLowercaseString();
  const int generation = impl_->generation;
  const int pid = impl_->pid;
  const auto cancelled = impl_->cancelled;
  impl_->worker->PostTaskAndReplyWithResult(
      FROM_HERE, base::BindOnce(&ReadVisible, pid, cancelled),
      base::BindOnce(
          [](base::WeakPtr<DesktopContextMac> owner, int generation,
             std::string bundle, std::string name, Sample sample) {
            if (!owner) {
              return;
            }
            auto& state = *owner->impl_;
            if (generation != state.generation || !owner->Current() ||
                !sample.safe ||
                NSWorkspace.sharedWorkspace.frontmostApplication
                        .processIdentifier != state.pid) {
              state.busy = false;
              return;
            }
            state.pending_window = std::move(sample.window);
            state.focused_bounds = sample.bounds;
            state.document_url = sample.value.FindString("documentUrl")
                                     ? *sample.value.FindString("documentUrl")
                                     : "";
            const auto* text = sample.value.FindString("text");
            if ((!text || text->empty()) && state.ocr && state.filter &&
                state.filter_pid == state.pid &&
                SelectedWindowIsForeground(state.pid, state.filter_window,
                                           sample.bounds)) {
              owner->CaptureOcr(state.pid, generation);
              return;
            }
            sample.value.Set("app", base::DictValue()
                                        .Set("bundleId", bundle)
                                        .Set("displayName", name));
            owner->Accept(std::move(sample.value), generation);
          },
          weak_factory_.GetWeakPtr(), generation, bundle,
          base::SysNSStringToUTF8(foreground.localizedName)));
}
void DesktopContextMac::Accept(base::DictValue capture, int generation) {
  impl_->busy = false;
  if (generation != impl_->generation || !Current() ||
      NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier !=
          impl_->pid) {
    return;
  }
  const auto* text = capture.FindString("text");
  const auto* selection = capture.FindString("selection");
  if (!text || text->empty() || !selection || text->size() > 32768 ||
      selection->size() > 4096) {
    return;
  }
  const auto combined = *text + std::string(1, '\0') + *selection;
  if (combined == impl_->last_text) {
    return;
  }
  impl_->last_text = combined;
  impl_->last_capture = base::TimeTicks::Now();
  const double now =
      static_cast<double>(base::Time::Now().InMillisecondsSinceUnixEpoch());
  const auto* workspace = impl_->settings.FindString("workspaceId");
  if (!workspace) {
    return;
  }
  capture.Set("captureId", base::Uuid::GenerateRandomV4().AsLowercaseString());
  capture.Set("workspaceId", *workspace);
  capture.Set("leaseId", impl_->lease);
  capture.Set("configurationRevision", impl_->revision);
  capture.Set("sourceEpoch", impl_->epoch);
  capture.Set("processId", impl_->pid);
  capture.Set("windowId", impl_->epoch);
  capture.Set("capturedAt", now);
  capture.Set("expiresAt", now + 14.0 * 86400000);
  if (!capture.FindString("kind")) {
    capture.Set("kind", "accessibility");
  }
  capture.Set("sha256",
              base::HexEncodeLower(crypto::SHA256HashString(combined)));
  impl_->pending = std::move(capture);
}
base::DictValue DesktopContextMac::Take(const std::string& lease) {
  const double captured_at =
      impl_->pending.FindDouble("capturedAt").value_or(0);
  if (!Current() || lease != impl_->lease ||
      NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier !=
          impl_->pid ||
      (!impl_->pending.empty() &&
       base::Time::Now().InMillisecondsSinceUnixEpoch() - captured_at >
           60000)) {
    if (!impl_->pending.empty()) {
      ++impl_->dropped;
    }
    impl_->pending.clear();
    impl_->pending_window.reset();
    return {};
  }
  return impl_->pending.Clone();
}
void DesktopContextMac::Validate(const base::DictValue& source,
                                 base::OnceCallback<void(bool)> reply) {
  const auto* id = source.FindString("captureId");
  const auto* expected = impl_->pending.FindString("captureId");
  auto expected_source = impl_->pending.Clone();
  expected_source.Remove("text");
  expected_source.Remove("selection");
  if (expected_source != source || !Current() || !id || !expected ||
      *id != *expected ||
      NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier !=
          impl_->pid ||
      !impl_->pending_window) {
    std::move(reply).Run(false);
    return;
  }
  const int generation = impl_->generation;
  auto previous = impl_->pending_window;
  const std::string expected_hash = *impl_->pending.FindString("sha256");
  const std::string expected_url =
      impl_->pending.FindString("documentUrl")
          ? *impl_->pending.FindString("documentUrl")
          : "";
  const bool ocr = *impl_->pending.FindString("kind") == "ocr";
  auto callback =
      std::make_shared<base::OnceCallback<void(bool)>>(std::move(reply));
  impl_->worker->PostTaskAndReplyWithResult(
      FROM_HERE, base::BindOnce(&ReadVisible, impl_->pid, impl_->cancelled),
      base::BindOnce(
          [](base::WeakPtr<DesktopContextMac> owner, int generation,
             base::apple::ScopedCFTypeRef<AXUIElementRef> previous,
             std::string expected_hash, std::string expected_url, bool ocr,
             std::shared_ptr<base::OnceCallback<void(bool)>> callback,
             Sample sample) {
            const auto* url = sample.value.FindString("documentUrl");
            bool valid = owner && generation == owner->impl_->generation &&
                         owner->Current() && sample.safe && sample.window &&
                         CFEqual(previous.get(), sample.window.get()) &&
                         (url ? *url : "") == expected_url &&
                         NSWorkspace.sharedWorkspace.frontmostApplication
                                 .processIdentifier == owner->impl_->pid;
            if (!valid) {
              std::move(*callback).Run(false);
              return;
            }
            if (!ocr) {
              const std::string text = sample.value.FindString("text")
                                           ? *sample.value.FindString("text")
                                           : "";
              const std::string selection =
                  sample.value.FindString("selection")
                      ? *sample.value.FindString("selection")
                      : "";
              std::move(*callback).Run(
                  base::HexEncodeLower(crypto::SHA256HashString(
                      text + std::string(1, '\0') + selection)) ==
                  expected_hash);
              return;
            }
            if (!owner->impl_->filter ||
                !SelectedWindowIsForeground(owner->impl_->pid,
                                            owner->impl_->filter_window,
                                            sample.bounds)) {
              std::move(*callback).Run(false);
              return;
            }
            owner->ReadOcr(
                owner->impl_->pid, generation,
                base::BindOnce(
                    [](base::WeakPtr<DesktopContextMac> owner, int generation,
                       base::apple::ScopedCFTypeRef<AXUIElementRef> previous,
                       std::string expected_hash, std::string expected_url,
                       std::shared_ptr<base::OnceCallback<void(bool)>> callback,
                       std::string text) {
                      if (!owner || text.empty() ||
                          generation != owner->impl_->generation ||
                          !owner->Current() ||
                          base::HexEncodeLower(crypto::SHA256HashString(
                              text + std::string(1, '\0'))) != expected_hash) {
                        std::move(*callback).Run(false);
                        return;
                      }
                      // OCR can take time: verify sensitive focus and the exact
                      // window again.
                      owner->impl_->worker->PostTaskAndReplyWithResult(
                          FROM_HERE,
                          base::BindOnce(&ReadVisible, owner->impl_->pid,
                                         owner->impl_->cancelled),
                          base::BindOnce(
                              [](base::WeakPtr<DesktopContextMac> owner,
                                 int generation,
                                 base::apple::ScopedCFTypeRef<AXUIElementRef>
                                     previous,
                                 std::string expected_url,
                                 std::shared_ptr<base::OnceCallback<void(bool)>>
                                     callback,
                                 Sample final) {
                                const auto* url =
                                    final.value.FindString("documentUrl");
                                std::move(*callback).Run(
                                    owner &&
                                    generation == owner->impl_->generation &&
                                    owner->Current() && final.safe &&
                                    final.window &&
                                    CFEqual(previous.get(),
                                            final.window.get()) &&
                                    (url ? *url : "") == expected_url &&
                                    owner->impl_->filter &&
                                    SelectedWindowIsForeground(
                                        owner->impl_->pid,
                                        owner->impl_->filter_window,
                                        final.bounds) &&
                                    NSWorkspace.sharedWorkspace
                                            .frontmostApplication
                                            .processIdentifier ==
                                        owner->impl_->pid);
                              },
                              owner, generation, std::move(previous),
                              expected_url, callback));
                    },
                    owner, generation, std::move(previous), expected_hash,
                    expected_url, callback));
          },
          weak_factory_.GetWeakPtr(), generation, std::move(previous),
          expected_hash, expected_url, ocr, callback));
}
bool DesktopContextMac::Acknowledge(const std::string& lease,
                                    const std::string& capture) {
  const auto* pending = impl_->pending.FindString("captureId");
  if (lease != impl_->lease || !pending || capture != *pending) {
    return false;
  }
  impl_->pending.clear();
  impl_->pending_window.reset();
  return true;
}
void DesktopContextMac::Stop(base::OnceClosure completion) {
  impl_->cancelled->store(true);
  [impl_->active_ocr cancel];
  ++impl_->generation;
  impl_->timer.Stop();
  impl_->lease.clear();
  impl_->pending.clear();
  impl_->pending_window.reset();
  impl_->filter = nil;
  impl_->stopped.push_back(std::move(completion));
  ++impl_->stop_barriers;
  impl_->worker->PostTaskAndReply(
      FROM_HERE, base::DoNothing(),
      base::BindOnce(
          [](base::WeakPtr<DesktopContextMac> owner) {
            if (!owner) {
              return;
            }
            --owner->impl_->stop_barriers;
            owner->FinishStop();
          },
          weak_factory_.GetWeakPtr()));
}
void DesktopContextMac::FinishStop() {
  if (impl_->stop_barriers || impl_->ocr_work) {
    return;
  }
  impl_->busy = false;
  auto completions = std::move(impl_->stopped);
  for (auto& completion : completions) {
    std::move(completion).Run();
  }
}
void DesktopContextMac::FinishOcr() {
  --impl_->ocr_work;
  impl_->busy = false;
  FinishStop();
}
void DesktopContextMac::CaptureOcr(int pid, int generation) {
  ReadOcr(
      pid, generation,
      base::BindOnce(
          [](base::WeakPtr<DesktopContextMac> owner, int generation,
             std::string text) {
            if (!owner || text.empty() ||
                generation != owner->impl_->generation || !owner->Current()) {
              return;
            }
            base::DictValue capture;
            capture.Set("kind", "ocr");
            capture.Set("text", text);
            capture.Set("selection", "");
            capture.Set("windowTitle", "");
            if (!owner->impl_->document_url.empty()) {
              capture.Set("documentUrl", owner->impl_->document_url);
            }
            NSRunningApplication* app =
                NSWorkspace.sharedWorkspace.frontmostApplication;
            capture.Set("app",
                        base::DictValue()
                            .Set("bundleId",
                                 base::SysNSStringToUTF8(app.bundleIdentifier))
                            .Set("displayName",
                                 base::SysNSStringToUTF8(app.localizedName)));
            owner->Accept(std::move(capture), generation);
          },
          weak_factory_.GetWeakPtr(), generation));
}
void DesktopContextMac::ReadOcr(int pid,
                                int generation,
                                base::OnceCallback<void(std::string)> reply) {
  if (@available(macOS 15.2, *)) {
    if (!Current() || !impl_->filter || impl_->filter_pid != pid ||
        !SelectedWindowIsForeground(pid, impl_->filter_window,
                                    impl_->focused_bounds)) {
      impl_->busy = false;
      std::move(reply).Run("");
      return;
    }
    SCStreamConfiguration* configuration = [[SCStreamConfiguration alloc] init];
    const auto bounds = impl_->filter.contentRect;
    const double scale =
        std::min({2.0, 2048.0 / std::max(1.0, bounds.size.width),
                  1536.0 / std::max(1.0, bounds.size.height)});
    configuration.width =
        std::max(1, static_cast<int>(std::floor(bounds.size.width * scale)));
    configuration.height =
        std::max(1, static_cast<int>(std::floor(bounds.size.height * scale)));
    configuration.capturesAudio = NO;
    configuration.showsCursor = NO;
    ++impl_->ocr_work;
    auto callback = std::make_shared<base::OnceCallback<void(std::string)>>(
        std::move(reply));
    SCContentFilter* filter = impl_->filter;
    auto weak = weak_factory_.GetWeakPtr();
    auto cancelled = impl_->cancelled;
    [SCScreenshotManager
        captureImageWithFilter:filter
                 configuration:configuration
             completionHandler:^(CGImageRef image, NSError* error) {
               if (!image || error || cancelled->load()) {
                 dispatch_async(dispatch_get_main_queue(), ^{
                   if (weak) {
                     if (generation == weak->impl_->generation) {
                       weak->PickerStopped();
                     }
                     std::move(*callback).Run("");
                     weak->FinishOcr();
                   }
                 });
                 return;
               }
               CGImageRetain(image);
               dispatch_async(dispatch_get_main_queue(), ^{
                 if (!weak) {
                   CGImageRelease(image);
                   std::move(*callback).Run("");
                   return;
                 }
                 if (cancelled->load() ||
                     generation != weak->impl_->generation ||
                     !weak->Current()) {
                   CGImageRelease(image);
                   std::move(*callback).Run("");
                   weak->FinishOcr();
                   return;
                 }
                 VNRecognizeTextRequest* request =
                     [[VNRecognizeTextRequest alloc] init];
                 request.recognitionLevel =
                     VNRequestTextRecognitionLevelAccurate;
                 request.automaticallyDetectsLanguage = YES;
                 weak->impl_->active_ocr = request;
                 dispatch_async(
                     dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                       VNImageRequestHandler* handler =
                           [[VNImageRequestHandler alloc] initWithCGImage:image
                                                                  options:@{}];
                       NSError* failure = nil;
                       [handler performRequests:@[ request ] error:&failure];
                       std::string text;
                       if (!failure && !cancelled->load()) {
                         for (VNRecognizedTextObservation* observation in
                                  request.results) {
                           auto line = base::SysNSStringToUTF8(
                               [observation topCandidates:1]
                                   .firstObject.string);
                           if (text.size() + line.size() + 1 > 32768) {
                             break;
                           }
                           text += line + "\n";
                         }
                       }
                       CGImageRelease(image);
                       dispatch_async(dispatch_get_main_queue(), ^{
                         if (!weak) {
                           std::move(*callback).Run("");
                           return;
                         }
                         if (weak->impl_->active_ocr == request) {
                           weak->impl_->active_ocr = nil;
                         }
                         const bool valid =
                             !cancelled->load() &&
                             generation == weak->impl_->generation &&
                             weak->Current() && weak->impl_->filter == filter &&
                             NSWorkspace.sharedWorkspace.frontmostApplication
                                     .processIdentifier == pid;
                         std::move(*callback).Run(valid ? text : "");
                         weak->FinishOcr();
                       });
                     });
               });
             }];
  } else {
    impl_->busy = false;
    std::move(reply).Run("");
  }
}
}  // namespace aux
