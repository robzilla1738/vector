// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#ifndef CHROME_BROWSER_UI_AUX_PREVIEW_AUX_PREVIEW_CONTROLS_H_
#define CHROME_BROWSER_UI_AUX_PREVIEW_AUX_PREVIEW_CONTROLS_H_
#include <optional>
#include <string>
#include "ui/gfx/geometry/rect.h"
class BrowserWindowInterface;
namespace aux::preview {
// Registers the native decorator. Called before native preview creation; no
// renderer or startup feature flag is allowed to install a substitute.
void EnsureNativePreviewControls();
int NativePreviewControlsWidth(BrowserWindowInterface*);
// A Quick window opened with no address starts with an empty field, ready to type.
void ClearQuickAddress(BrowserWindowInterface*);
// Peek is a sheet at about 90% of its source window's page card, in screen
// coordinates. Empty when the source has no card to sit over.
std::optional<gfx::Rect> PeekSheetBounds(BrowserWindowInterface* source);
// Once Peek is shown: dims the source card and keeps the sheet over it.
void PresentPeekSheet(BrowserWindowInterface* peek);
// A short status over the bottom of a window's card that fades on its own,
// in place of a modal alert.
void ShowPreviewStatus(BrowserWindowInterface*, const std::u16string& text);
}
#endif
