// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/ui/aux_preview/aux_preview_controls.h"
#include "chrome/browser/ui/aux_preview/aux_preview_controller.h"
#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include "base/functional/bind.h"
#include "base/memory/raw_ptr.h"
#include "base/memory/weak_ptr.h"
#include "base/no_destructor.h"
#include "base/scoped_multi_source_observation.h"
#include "base/scoped_observation.h"
#include "base/strings/utf_string_conversions.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "chrome/browser/aux/organization/space_directory.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/tabs/tab_strip_model.h"
#include "chrome/browser/ui/color/chrome_color_id.h"
#include "chrome/browser/ui/views/frame/aux_emoji_picker.h"
#include "chrome/browser/ui/views/frame/aux_frame_metrics.h"
#include "chrome/browser/ui/views/frame/browser_view.h"
#include "chrome/browser/ui/views/toolbar/toolbar_button.h"
#include "chrome/browser/ui/views/toolbar/toolbar_view.h"
#include "chrome/browser/ui/views/omnibox/omnibox_view_views.h"
#include "chrome/grit/generated_resources.h"
#include "components/vector_icons/vector_icons.h"
#include "content/public/browser/web_contents.h"
#include "content/public/browser/web_contents_observer.h"
#include "third_party/skia/include/core/SkColor.h"
#include "ui/base/accelerators/accelerator.h"
#include "ui/base/hit_test.h"
#include "ui/base/l10n/l10n_util.h"
#include "ui/base/metadata/metadata_header_macros.h"
#include "ui/base/metadata/metadata_impl_macros.h"
#include "ui/base/mojom/menu_source_type.mojom.h"
#include "ui/color/color_id.h"
#include "ui/events/event.h"
#include "ui/events/keycodes/keyboard_codes.h"
#include "ui/menus/simple_menu_model.h"
#include "ui/views/accessibility/view_accessibility.h"
#include "ui/views/background.h"
#include "ui/views/border.h"
#include "ui/views/controls/button/md_text_button.h"
#include "ui/views/controls/label.h"
#include "ui/views/controls/menu/menu_runner.h"
#include "ui/views/controls/menu/menu_types.h"
#include "ui/views/layout/flex_layout.h"
#include "ui/views/view.h"
#include "ui/views/view_class_properties.h"
#include "ui/views/view_utils.h"
#include "ui/views/widget/widget.h"
#include "ui/views/widget/widget_observer.h"
namespace aux::preview {
namespace {
constexpr int kTrafficLightsWidth = 76;
// The page card of a window, in screen coordinates.
gfx::Rect CardBounds(BrowserView* view) {
  auto* card = view->contents_container();
  return card && card->GetVisible() && !card->bounds().IsEmpty()
      ? card->GetBoundsInScreen() : view->GetWidget()->GetClientAreaBoundsInScreen();
}
// Dims the source card under Peek; a click on it dismisses Peek.
class Backdrop final : public views::View {
  METADATA_HEADER(Backdrop, views::View)
 public:
  explicit Backdrop(base::RepeatingClosure dismiss) : dismiss_(std::move(dismiss)) {
    SetBackground(views::CreateRoundedRectBackground(SkColorSetA(SK_ColorBLACK, 0x47),
                                                     frame_metrics::CardRadius()));
  }
  bool OnMousePressed(const ui::MouseEvent&) override { return true; }
  void OnMouseReleased(const ui::MouseEvent& event) override {
    if (HitTestPoint(event.location())) dismiss_.Run();
  }
 private:
  base::RepeatingClosure dismiss_;
};
BEGIN_METADATA(Backdrop)
END_METADATA
std::unique_ptr<views::Widget> FramelessChild(views::Widget* parent, const gfx::Rect& bounds,
                                              const char* name, bool accept_events) {
  auto widget = std::make_unique<views::Widget>();
  views::Widget::InitParams params(views::Widget::InitParams::CLIENT_OWNS_WIDGET,
                                   views::Widget::InitParams::TYPE_WINDOW_FRAMELESS);
  params.opacity = views::Widget::InitParams::WindowOpacity::kTranslucent;
  params.activatable = views::Widget::InitParams::Activatable::kNo;
  params.accept_events = accept_events;
  params.shadow_type = views::Widget::InitParams::ShadowType::kNone;
  params.parent = parent->GetNativeView();
  params.bounds = bounds;
  params.name = name;
  widget->Init(std::move(params));
  return widget;
}
// One status at a time per window, closed by its timer or with the window.
class StatusToast final : public views::WidgetObserver {
 public:
  static void Show(views::Widget* parent, const gfx::Rect& card, const std::u16string& text) {
    Toasts().erase(parent);
    Toasts()[parent] = std::make_unique<StatusToast>(parent, card, text);
  }
  StatusToast(views::Widget* parent, const gfx::Rect& card, const std::u16string& text)
      : parent_(parent) {
    auto label = std::make_unique<views::Label>(text);
    label->SetMultiLine(true);
    label->SetMaximumWidth(std::clamp(card.width() - 48, 160, 420));
    label->SetHorizontalAlignment(gfx::ALIGN_CENTER);
    label->SetEnabledColor(ui::kColorSysInverseOnSurface);
    label->SetBorder(views::CreateEmptyBorder(gfx::Insets::VH(8, 14)));
    label->SetBackground(views::CreateRoundedRectBackground(ui::kColorSysInverseSurface,
                                                            frame_metrics::kPopoverRadius));
    const auto size = label->GetPreferredSize();
    const gfx::Rect bounds(card.CenterPoint().x() - size.width() / 2,
                           card.bottom() - size.height() - 20, size.width(), size.height());
    widget_ = FramelessChild(parent, bounds, "AuxPreviewStatus", false);
    widget_->SetContentsView(std::move(label));
    widget_->ShowInactive();
    widget_->GetRootView()->GetViewAccessibility().AnnouncePolitely(text);
    parent_observation_.Observe(parent);
    timer_.Start(FROM_HERE, base::Seconds(4),
                 base::BindOnce([](views::Widget* parent) { Toasts().erase(parent); }, parent));
  }
  void OnWidgetDestroying(views::Widget*) override {
    parent_observation_.Reset();
    Toasts().erase(parent_);
  }
 private:
  static std::map<views::Widget*, std::unique_ptr<StatusToast>>& Toasts() {
    static base::NoDestructor<std::map<views::Widget*, std::unique_ptr<StatusToast>>> toasts;
    return *toasts;
  }
  raw_ptr<views::Widget> parent_;
  std::unique_ptr<views::Widget> widget_;
  base::OneShotTimer timer_;
  base::ScopedObservation<views::Widget, views::WidgetObserver> parent_observation_{this};
};
void ReportFailure(base::WeakPtr<BrowserWindowInterface> browser, base::DictValue result) {
  if (result.FindBool("ok").value_or(false) || !browser) return;
  if (auto* contents = browser->GetTabStripModel()->GetActiveWebContents())
    ReportRestriction(contents, l10n_util::GetStringUTF8(IDS_AUX_PREVIEW_MOVE_FAILED));
}
class Controls final : public views::View, public content::WebContentsObserver,
                       public views::WidgetObserver {
  METADATA_HEADER(Controls, views::View)
 public:
  explicit Controls(BrowserWindowInterface* browser)
      : WebContentsObserver(browser->GetTabStripModel()->GetActiveWebContents()),
        browser_(browser->GetWeakPtr()) {
    SetLayoutManager(std::make_unique<views::FlexLayout>())
        ->SetOrientation(views::LayoutOrientation::kHorizontal)
        .SetCrossAxisAlignment(views::LayoutAlignment::kCenter);
    // The bar sits in the traffic-light row (Little Arc). This space clears the
    // lights and drags the window like a titlebar.
    auto* lights = AddChildView(std::make_unique<views::View>());
    lights->SetPreferredSize(gfx::Size(kTrafficLightsWidth, 1));
    lights->SetProperty(views::kHitTestComponentKey, static_cast<int>(HTCAPTION));
    lights->SetProperty(views::kCrossAxisAlignmentKey, views::LayoutAlignment::kStretch);
    back_ = AddChildView(std::make_unique<ToolbarButton>(
        base::BindRepeating(&Controls::GoBack, weak_.GetWeakPtr())));
    back_->SetVectorIcon(vector_icons::kArrowBackIcon);
    back_->SetTooltipText(l10n_util::GetStringUTF16(IDS_AUX_PREVIEW_BACK));
    // Like Little Arc: back here, the page actions at the trailing end, and no
    // profile label unless there is a restriction to explain. A Quick window
    // closes with its traffic light; Peek also has a dismiss button.
    dismiss_ = AddChildView(std::make_unique<ToolbarButton>(
        base::BindRepeating(&Controls::Close, weak_.GetWeakPtr())));
    dismiss_->SetVectorIcon(vector_icons::kCloseIcon);
    dismiss_->SetTooltipText(l10n_util::GetStringUTF16(IDS_AUX_PEEK_DISMISS));
    dismiss_->SetVisible(GetKind(browser) == Kind::kPeek);
    label_ = AddChildView(std::make_unique<views::Label>());
    label_->SetMaximumWidth(160);
    label_->SetEnabledColor(kColorToolbarText);
    label_->SetHorizontalAlignment(gfx::ALIGN_LEFT);
    subscription_ = ObservePresentation(browser, base::BindRepeating(&Controls::Refresh, weak_.GetWeakPtr()));
    Refresh();
    if (GetKind(browser) == Kind::kPeek) {
      // Peek behaves like a sheet over its window: Escape (when the page does
      // not use it) or returning to the source window dismisses it.
      AddAccelerator(ui::Accelerator(ui::VKEY_ESCAPE, ui::EF_NONE));
      auto* source = GetSource(browser);
      auto* source_view = source ? BrowserView::GetBrowserViewForBrowser(source) : nullptr;
      if (source_view && source_view->GetWidget()) {
        source_widget_ = source_view->GetWidget();
        widgets_.AddObservation(source_view->GetWidget());
      }
    }
  }
  void AddedToWidget() override {
    // Peek watches its own activation; Little Aux remembers where it is left.
    if (!widgets_.IsObservingSource(GetWidget()))
      widgets_.AddObservation(GetWidget());
  }
  bool AcceleratorPressed(const ui::Accelerator& accelerator) override {
    Close();
    return true;
  }
  void OnWidgetActivationChanged(views::Widget* widget, bool active) override {
    if (GetKind(browser_.get()) != Kind::kPeek) return;
    // Arm only once Peek itself has been active, so the source regaining focus
    // as the context menu closes does not dismiss a Peek that is opening.
    if (widget == GetWidget())
      armed_ |= active;
    else if (active && armed_)
      Close();
  }
  void OnWidgetBoundsChanged(views::Widget* widget, const gfx::Rect&) override {
    if (widget == source_widget_)
      LayoutSheet();
    else if (widget == GetWidget() && GetKind(browser_.get()) == Kind::kQuick)
      RememberQuickBounds(browser_.get());
  }
  void OnWidgetDestroying(views::Widget* widget) override {
    if (widget == source_widget_) {
      backdrop_.reset();
      source_widget_ = nullptr;
    }
    widgets_.RemoveObservation(widget);
  }
  void DidStopLoading() override { Refresh(); }
  void PrimaryPageChanged(content::Page&) override { Refresh(); }
  void DidStartLoading() override { Refresh(); }
  // Arc's Peek: the page card dims and the sheet stays over it, moving and
  // resizing with the source window as one of its child windows.
  void PresentSheet() {
    if (!source_widget_ || !GetWidget() || backdrop_) return;
    auto* source_view = BrowserView::GetBrowserViewForNativeWindow(source_widget_->GetNativeWindow());
    if (!source_view) return;
    backdrop_ = FramelessChild(source_widget_, CardBounds(source_view), "AuxPeekBackdrop", true);
    backdrop_->SetContentsView(std::make_unique<Backdrop>(
        base::BindRepeating(&Controls::Close, weak_.GetWeakPtr())));
    backdrop_->ShowInactive();
    // Added after the backdrop, so it orders above it.
    views::Widget::ReparentNativeView(GetWidget()->GetNativeView(), source_widget_->GetNativeView());
    LayoutSheet();
  }
 private:
  void LayoutSheet() {
    auto* source = browser_ ? GetSource(browser_.get()) : nullptr;
    auto* source_view = source ? BrowserView::GetBrowserViewForBrowser(source) : nullptr;
    const auto sheet = source ? PeekSheetBounds(source) : std::nullopt;
    if (!source_view || !sheet || !GetWidget()) return;
    if (backdrop_) backdrop_->SetBounds(CardBounds(source_view));
    GetWidget()->SetBounds(*sheet);
  }
  void Refresh() {
    if (!browser_) return;
    const auto state = Presentation(browser_.get());
    const bool promoting = state.FindBool("promoting").value_or(false);
    back_->SetEnabled(!promoting && state.FindBool("canBack").value_or(false));
    dismiss_->SetEnabled(!promoting);
    const auto* restriction = state.FindString("restriction");
    const bool restricted = restriction && !restriction->empty();
    label_->SetText(restricted ? base::UTF8ToUTF16(*restriction) : std::u16string());
    label_->SetTooltipText(std::u16string(label_->GetText()));
    label_->SetVisible(restricted);
    InvalidateLayout();
  }
  void GoBack() {
    if (!browser_) return;
    auto weak = weak_.GetWeakPtr();
    const bool moved = Back(browser_.get());
    if (!weak) return;
    if (!moved && web_contents())
      ReportRestriction(web_contents(), l10n_util::GetStringUTF8(IDS_AUX_PREVIEW_BACK_UNAVAILABLE));
    if (weak)
      Refresh();
  }
  void Close() {
    if (!browser_) return;
    std::string reason;
    const auto alive = weak_.GetWeakPtr();
    const bool dismissed = Dismiss(browser_.get(), &reason);
    if (alive && !dismissed && web_contents())
      ReportRestriction(web_contents(), reason);
  }
  base::WeakPtr<BrowserWindowInterface> browser_;
  raw_ptr<ToolbarButton> back_ = nullptr;
  raw_ptr<ToolbarButton> dismiss_ = nullptr;
  raw_ptr<views::Label> label_ = nullptr;
  raw_ptr<views::Widget> source_widget_ = nullptr;
  std::unique_ptr<views::Widget> backdrop_;
  base::CallbackListSubscription subscription_;
  base::ScopedMultiSourceObservation<views::Widget, views::WidgetObserver> widgets_{this};
  bool armed_ = false;
  base::WeakPtrFactory<Controls> weak_{this};
};
BEGIN_METADATA(Controls)
END_METADATA
// A quiet chip like Little Arc's, in the address field's neutral fill.
void StyleChip(views::MdTextButton* chip, bool last) {
  chip->SetStyle(ui::ButtonStyle::kTonal);
  chip->SetBgColorIdOverride(kColorToolbarBackgroundSubtleEmphasis);
  chip->SetEnabledTextColors(kColorToolbarText);
  chip->SetCornerRadius(frame_metrics::kControlRadius);
  chip->SetCustomPadding(gfx::Insets::VH(0, 10));
  chip->SetProperty(views::kMarginsKey, gfx::Insets::TLBR(0, 6, 0, last ? 6 : 0));
}
// A trailing page action: Peek's "Expand to tab" and "Open in split", and
// Little Aux's "Open in Aux". Each moves the page into a normal window.
class PromoteButton final : public views::MdTextButton {
  METADATA_HEADER(PromoteButton, views::MdTextButton)
 public:
  enum class Action { kTab, kSplit };
  PromoteButton(BrowserWindowInterface* browser, Action action)
      : views::MdTextButton(base::BindRepeating(&PromoteButton::Run, base::Unretained(this))),
        browser_(browser->GetWeakPtr()), action_(action) {
    const bool peek = GetKind(browser) == Kind::kPeek;
    SetText(l10n_util::GetStringUTF16(action == Action::kSplit ? IDS_AUX_PEEK_OPEN_IN_SPLIT
        : peek ? IDS_AUX_PEEK_EXPAND_TO_TAB : IDS_AUX_LITTLE_AUX_OPEN_IN_AUX));
    SetTooltipText(l10n_util::GetStringUTF16(action == Action::kSplit ? IDS_AUX_PEEK_OPEN_IN_SPLIT_TOOLTIP
        : peek ? IDS_AUX_PEEK_EXPAND_TO_TAB_TOOLTIP : IDS_AUX_LITTLE_AUX_OPEN_IN_AUX_TOOLTIP));
    StyleChip(this, action == Action::kTab);
    subscription_ = ObservePresentation(browser, base::BindRepeating(&PromoteButton::Refresh, weak_.GetWeakPtr()));
    Refresh();
  }
 private:
  void Refresh() {
    if (browser_)
      SetEnabled(!Presentation(browser_.get()).FindBool("promoting").value_or(false));
  }
  void Run() {
    if (!browser_) return;
    auto done = base::BindOnce(&ReportFailure, browser_);
    if (action_ == Action::kSplit)
      PromoteToSplit(browser_.get(), std::move(done));
    else
      Promote(browser_.get(), nullptr, {}, std::move(done));
  }
  base::WeakPtr<BrowserWindowInterface> browser_;
  const Action action_;
  base::CallbackListSubscription subscription_;
  base::WeakPtrFactory<PromoteButton> weak_{this};
};
BEGIN_METADATA(PromoteButton)
END_METADATA
// Little Aux's "Move to Space": the Spaces of this window's data group, in
// the browser-wide order. A page keeps its sign-ins, so it can only move to
// a Space that shares them.
class SpaceButton final : public views::MdTextButton, public ui::SimpleMenuModel::Delegate {
  METADATA_HEADER(SpaceButton, views::MdTextButton)
 public:
  explicit SpaceButton(BrowserWindowInterface* browser)
      : views::MdTextButton(base::BindRepeating(&SpaceButton::ShowMenu, base::Unretained(this)),
                            l10n_util::GetStringUTF16(IDS_AUX_LITTLE_AUX_MOVE_TO_SPACE)),
        browser_(browser->GetWeakPtr()) {
    SetTooltipText(l10n_util::GetStringUTF16(IDS_AUX_LITTLE_AUX_MOVE_TO_SPACE_TOOLTIP));
    StyleChip(this, false);
    subscription_ = ObservePresentation(browser, base::BindRepeating(&SpaceButton::Refresh, weak_.GetWeakPtr()));
    Refresh();
  }
  void ExecuteCommand(int command_id, int) override {
    if (!browser_ || command_id < 0 || static_cast<size_t>(command_id) >= ids_.size()) return;
    Promote(browser_.get(), nullptr, ids_[command_id], base::BindOnce(&ReportFailure, browser_));
  }
  bool IsCommandIdEnabled(int command_id) const override { return command_id != kNoSpaces; }
 private:
  static constexpr int kNoSpaces = 0x7fff;
  void Refresh() {
    if (browser_)
      SetEnabled(!Presentation(browser_.get()).FindBool("promoting").value_or(false));
  }
  void ShowMenu() {
    if (!browser_) return;
    const auto group = organization::GroupOf(browser_->GetProfile()->GetOriginalProfile()->GetPath());
    ids_.clear();
    model_ = std::make_unique<ui::SimpleMenuModel>(this);
    for (const auto& space : organization::ReadSpaceDirectory()) {
      if (space.group != group) continue;
      std::u16string label = base::UTF8ToUTF16(space.name);
      if (!IsAuxPlaceholderSpaceIcon(space.icon))
        label = base::UTF8ToUTF16(space.icon) + u"  " + label;
      model_->AddItem(static_cast<int>(ids_.size()), label);
      ids_.push_back(space.id);
    }
    if (ids_.empty())
      model_->AddItem(kNoSpaces, l10n_util::GetStringUTF16(IDS_AUX_LITTLE_AUX_NO_SPACES));
    runner_ = std::make_unique<views::MenuRunner>(model_.get(), views::MenuRunner::CONTEXT_MENU);
    runner_->RunMenuAt(GetWidget(), nullptr, GetBoundsInScreen(),
                       views::MenuAnchorPosition::kBubbleBottomRight, ui::mojom::MenuSourceType::kMouse);
  }
  base::WeakPtr<BrowserWindowInterface> browser_;
  std::vector<std::string> ids_;
  std::unique_ptr<ui::SimpleMenuModel> model_;
  std::unique_ptr<views::MenuRunner> runner_;
  base::CallbackListSubscription subscription_;
  base::WeakPtrFactory<SpaceButton> weak_{this};
};
BEGIN_METADATA(SpaceButton)
END_METADATA
template <typename T>
T* AddTrailing(ToolbarView* toolbar, std::unique_ptr<T> view) {
  auto* added = toolbar->AddChildView(std::move(view));
  added->SetProperty(views::kFlexBehaviorKey,
      views::FlexSpecification(views::LayoutOrientation::kHorizontal,
          views::MinimumFlexSizeRule::kPreferred, views::MaximumFlexSizeRule::kPreferred));
  return added;
}
Controls* FindControls(BrowserWindowInterface* browser) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  auto* toolbar = view ? view->toolbar() : nullptr;
  if (!toolbar) return nullptr;
  for (const auto& child : toolbar->children())
    if (auto* controls = views::AsViewClass<Controls>(child.get())) return controls;
  return nullptr;
}
bool Decorate(BrowserWindowInterface* browser) {
  if (!browser || !GetKind(browser) || browser->GetType() != BrowserWindowInterface::TYPE_POPUP)
    return false;
  auto* view = BrowserView::GetBrowserViewForBrowser(browser);
  auto* toolbar = view ? view->toolbar() : nullptr;
  auto* location = toolbar ? toolbar->location_bar_view() : nullptr;
  if (!location || !location->omnibox_view()) return false;
  const bool peek = GetKind(browser) == Kind::kPeek;
  if (!peek) {
    // Chromium popup location bars are read-only by default. A registered
    // Quick window is a small browser and keeps the actual omnibox editor.
    auto* omnibox = location->omnibox_view();
    omnibox->SetReadOnly(false);
    omnibox->GetViewAccessibility().SetReadOnly(false);
    omnibox->GetViewAccessibility().SetIsEditable(true);
    omnibox->SetPlaceholderText(l10n_util::GetStringUTF16(IDS_AUX_LITTLE_AUX_ADDRESS_PLACEHOLDER));
  }
  // TYPE_POPUP uses the existing location-bar FlexLayout. The real location
  // input/security model remains in place; only native siblings are added.
  auto* controls = toolbar->AddChildViewAt(std::make_unique<Controls>(browser), 0);
  controls->SetProperty(views::kFlexBehaviorKey,
      views::FlexSpecification(views::LayoutOrientation::kHorizontal,
          views::MinimumFlexSizeRule::kPreferred, views::MaximumFlexSizeRule::kPreferred));
  if (peek)
    AddTrailing(toolbar, std::make_unique<PromoteButton>(browser, PromoteButton::Action::kSplit));
  else
    AddTrailing(toolbar, std::make_unique<SpaceButton>(browser));
  AddTrailing(toolbar, std::make_unique<PromoteButton>(browser, PromoteButton::Action::kTab));
  toolbar->InvalidateLayout();
  return true;
}
}  // namespace
void ClearQuickAddress(BrowserWindowInterface* browser) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  auto* location = view && view->toolbar() ? view->toolbar()->location_bar_view() : nullptr;
  if (location && location->omnibox_view())
    location->omnibox_view()->SetUserText(std::u16string(), /*update_popup=*/false);
}
int NativePreviewControlsWidth(BrowserWindowInterface* browser) {
  if (!GetKind(browser)) return 0;
  auto* view = BrowserView::GetBrowserViewForBrowser(browser);
  auto* toolbar = view ? view->toolbar() : nullptr;
  if (!toolbar) return 0;
  int width = 0;
  for (const auto& child : toolbar->children())
    if (views::AsViewClass<Controls>(child.get()) || views::AsViewClass<PromoteButton>(child.get()) ||
        views::AsViewClass<SpaceButton>(child.get())) {
      const auto* margins = child->GetProperty(views::kMarginsKey);
      width += child->GetPreferredSize().width() + (margins ? margins->width() : 0);
    }
  return width;
}
std::optional<gfx::Rect> PeekSheetBounds(BrowserWindowInterface* source) {
  auto* view = source ? BrowserView::GetBrowserViewForBrowser(source) : nullptr;
  if (!view || !view->GetWidget()) return std::nullopt;
  gfx::Rect sheet = CardBounds(view);
  if (sheet.IsEmpty()) return std::nullopt;
  sheet.ClampToCenteredSize(gfx::Size(sheet.width() * 9 / 10, sheet.height() * 9 / 10));
  return sheet;
}
void PresentPeekSheet(BrowserWindowInterface* peek) {
  if (GetKind(peek) != Kind::kPeek) return;
  if (auto* controls = FindControls(peek)) controls->PresentSheet();
}
void ShowPreviewStatus(BrowserWindowInterface* browser, const std::u16string& text) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  if (!view || !view->GetWidget() || text.empty()) return;
  StatusToast::Show(view->GetWidget(), CardBounds(view), text);
}
void EnsureNativePreviewControls() {
  static bool installed = false;
  if (installed) return;
  SetNativeWindowDecorator(base::BindRepeating(&Decorate));
  installed = true;
}
}  // namespace aux::preview
