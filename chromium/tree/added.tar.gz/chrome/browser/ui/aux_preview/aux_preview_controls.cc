// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/ui/aux_preview/aux_preview_controls.h"
#include "chrome/browser/ui/aux_preview/aux_preview_controller.h"
#include <memory>
#include <string>
#include "base/functional/bind.h"
#include "base/memory/raw_ptr.h"
#include "base/memory/weak_ptr.h"
#include "base/scoped_multi_source_observation.h"
#include "base/strings/utf_string_conversions.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/tabs/tab_strip_model.h"
#include "chrome/browser/ui/color/chrome_color_id.h"
#include "chrome/browser/ui/views/frame/browser_view.h"
#include "chrome/browser/ui/views/toolbar/toolbar_button.h"
#include "chrome/browser/ui/views/toolbar/toolbar_view.h"
#include "chrome/browser/ui/views/omnibox/omnibox_view_views.h"
#include "components/vector_icons/vector_icons.h"
#include "content/public/browser/web_contents.h"
#include "content/public/browser/web_contents_observer.h"
#include "ui/base/accelerators/accelerator.h"
#include "ui/base/metadata/metadata_header_macros.h"
#include "ui/base/metadata/metadata_impl_macros.h"
#include "ui/events/keycodes/keyboard_codes.h"
#include "ui/views/controls/button/md_text_button.h"
#include "ui/views/controls/label.h"
#include "ui/views/layout/flex_layout.h"
#include "ui/views/view.h"
#include "ui/views/view_class_properties.h"
#include "ui/views/view_utils.h"
#include "ui/views/widget/widget.h"
#include "ui/views/widget/widget_observer.h"
namespace aux::preview {
namespace {
class Controls final : public views::View, public content::WebContentsObserver,
                       public views::WidgetObserver {
  METADATA_HEADER(Controls, views::View)
 public:
  explicit Controls(BrowserWindowInterface* browser)
      : WebContentsObserver(browser->GetTabStripModel()->GetActiveWebContents()),
        browser_(browser->GetWeakPtr()) {
    SetLayoutManager(std::make_unique<views::FlexLayout>())
        ->SetOrientation(views::LayoutOrientation::kHorizontal)
        .SetCrossAxisAlignment(views::LayoutAlignment::kCenter);
    back_ = AddChildView(std::make_unique<ToolbarButton>(
        base::BindRepeating(&Controls::GoBack, weak_.GetWeakPtr())));
    back_->SetVectorIcon(vector_icons::kArrowBackIcon);
    back_->SetTooltipText(u"Back");
    // Like Little Arc: back here, "Open in Aux" at the trailing end, and no
    // profile label unless there is a restriction to explain. A Quick window
    // closes with its traffic light; Peek also has a dismiss button.
    dismiss_ = AddChildView(std::make_unique<ToolbarButton>(
        base::BindRepeating(&Controls::Close, weak_.GetWeakPtr())));
    dismiss_->SetVectorIcon(vector_icons::kCloseIcon);
    dismiss_->SetTooltipText(u"Dismiss preview");
    dismiss_->SetVisible(GetKind(browser) == Kind::kPeek);
    label_ = AddChildView(std::make_unique<views::Label>());
    label_->SetMaximumWidth(160);
    label_->SetEnabledColor(kColorToolbarText);
    label_->SetHorizontalAlignment(gfx::ALIGN_LEFT);
    subscription_ = ObservePresentation(browser, base::BindRepeating(&Controls::Refresh, weak_.GetWeakPtr()));
    Refresh();
    if (GetKind(browser) == Kind::kPeek) {
      // Peek behaves like a sheet over its window: Escape (when the page does
      // not use it) or returning to the source window dismisses it.
      AddAccelerator(ui::Accelerator(ui::VKEY_ESCAPE, ui::EF_NONE));
      auto* source = GetSource(browser);
      auto* source_view = source ? BrowserView::GetBrowserViewForBrowser(source) : nullptr;
      if (source_view && source_view->GetWidget())
        widgets_.AddObservation(source_view->GetWidget());
    }
  }
  void AddedToWidget() override {
    if (GetKind(browser_.get()) == Kind::kPeek && !widgets_.IsObservingSource(GetWidget()))
      widgets_.AddObservation(GetWidget());
  }
  bool AcceleratorPressed(const ui::Accelerator& accelerator) override {
    Close();
    return true;
  }
  void OnWidgetActivationChanged(views::Widget* widget, bool active) override {
    // Arm only once Peek itself has been active, so the source regaining focus
    // as the context menu closes does not dismiss a Peek that is opening.
    if (widget == GetWidget())
      armed_ |= active;
    else if (active && armed_)
      Close();
  }
  void OnWidgetDestroying(views::Widget* widget) override { widgets_.RemoveObservation(widget); }
  void DidStopLoading() override { Refresh(); }
  void PrimaryPageChanged(content::Page&) override { Refresh(); }
  void DidStartLoading() override { Refresh(); }
 private:
  void Refresh() {
    if (!browser_) return;
    const auto state = Presentation(browser_.get());
    const bool promoting = state.FindBool("promoting").value_or(false);
    back_->SetEnabled(!promoting && state.FindBool("canBack").value_or(false));
    dismiss_->SetEnabled(!promoting);
    const auto* restriction = state.FindString("restriction");
    const bool restricted = restriction && !restriction->empty();
    label_->SetText(restricted ? base::UTF8ToUTF16(*restriction) : std::u16string());
    label_->SetTooltipText(std::u16string(label_->GetText()));
    label_->SetVisible(restricted);
    InvalidateLayout();
  }
  void GoBack() {
    if (!browser_) return;
    auto weak = weak_.GetWeakPtr();
    const bool moved = Back(browser_.get());
    if (!weak) return;
    if (!moved && web_contents())
      ReportRestriction(web_contents(), "Back is unavailable while this page has active work.");
    if (weak)
      Refresh();
  }
  void Close() {
    if (!browser_) return;
    std::string reason;
    const auto alive = weak_.GetWeakPtr();
    const bool dismissed = Dismiss(browser_.get(), &reason);
    if (alive && !dismissed && web_contents())
      ReportRestriction(web_contents(), reason);
  }
  base::WeakPtr<BrowserWindowInterface> browser_;
  raw_ptr<ToolbarButton> back_ = nullptr;
  raw_ptr<ToolbarButton> dismiss_ = nullptr;
  raw_ptr<views::Label> label_ = nullptr;
  base::CallbackListSubscription subscription_;
  base::ScopedMultiSourceObservation<views::Widget, views::WidgetObserver> widgets_{this};
  bool armed_ = false;
  base::WeakPtrFactory<Controls> weak_{this};
};
BEGIN_METADATA(Controls)
END_METADATA
// The trailing "Open in Aux" button: moves the page into the source window.
class PromoteButton final : public views::MdTextButton {
  METADATA_HEADER(PromoteButton, views::MdTextButton)
 public:
  explicit PromoteButton(BrowserWindowInterface* browser)
      : views::MdTextButton(base::BindRepeating(&PromoteButton::OpenAsTab,
                                                base::Unretained(this)),
                            u"Open in Aux"),
        browser_(browser->GetWeakPtr()) {
    SetStyle(ui::ButtonStyle::kTonal);
    SetTooltipText(u"Move this page into a tab in your Aux window");
    SetProperty(views::kMarginsKey, gfx::Insets::TLBR(0, 6, 0, 6));
    subscription_ = ObservePresentation(browser, base::BindRepeating(&PromoteButton::Refresh, weak_.GetWeakPtr()));
    Refresh();
  }
 private:
  void Refresh() {
    if (browser_)
      SetEnabled(!Presentation(browser_.get()).FindBool("promoting").value_or(false));
  }
  void OpenAsTab() {
    if (!browser_) return;
    Promote(browser_.get(), nullptr, {}, base::BindOnce(&PromoteButton::OnPromoted, weak_.GetWeakPtr()));
  }
  void OnPromoted(base::DictValue result) {
    if (result.FindBool("ok").value_or(false) || !browser_) return;
    auto* contents = browser_->GetTabStripModel()->GetActiveWebContents();
    const auto* error = result.FindString("error");
    if (contents)
      ReportRestriction(contents, error ? *error : "The tab could not be promoted.");
  }
  base::WeakPtr<BrowserWindowInterface> browser_;
  base::CallbackListSubscription subscription_;
  base::WeakPtrFactory<PromoteButton> weak_{this};
};
BEGIN_METADATA(PromoteButton)
END_METADATA
bool Decorate(BrowserWindowInterface* browser) {
  if (!browser || !GetKind(browser) || browser->GetType() != BrowserWindowInterface::TYPE_POPUP)
    return false;
  auto* view = BrowserView::GetBrowserViewForBrowser(browser);
  auto* toolbar = view ? view->toolbar() : nullptr;
  auto* location = toolbar ? toolbar->location_bar_view() : nullptr;
  if (!location || !location->omnibox_view()) return false;
  if (GetKind(browser) == Kind::kQuick) {
    // Chromium popup location bars are read-only by default. A registered
    // Quick window is a small browser and keeps the actual omnibox editor.
    auto* omnibox = location->omnibox_view();
    omnibox->SetReadOnly(false);
    omnibox->GetViewAccessibility().SetReadOnly(false);
    omnibox->GetViewAccessibility().SetIsEditable(true);
  }
  // TYPE_POPUP uses the existing location-bar FlexLayout. The real location
  // input/security model remains in place; only native siblings are added.
  auto* controls = toolbar->AddChildViewAt(std::make_unique<Controls>(browser), 0);
  controls->SetProperty(views::kFlexBehaviorKey,
      views::FlexSpecification(views::LayoutOrientation::kHorizontal,
          views::MinimumFlexSizeRule::kPreferred, views::MaximumFlexSizeRule::kPreferred));
  auto* promote = toolbar->AddChildView(std::make_unique<PromoteButton>(browser));
  promote->SetProperty(views::kFlexBehaviorKey,
      views::FlexSpecification(views::LayoutOrientation::kHorizontal,
          views::MinimumFlexSizeRule::kPreferred, views::MaximumFlexSizeRule::kPreferred));
  toolbar->InvalidateLayout();
  return true;
}
}  // namespace
int NativePreviewControlsWidth(BrowserWindowInterface* browser) {
  if (!GetKind(browser)) return 0;
  auto* view = BrowserView::GetBrowserViewForBrowser(browser);
  auto* toolbar = view ? view->toolbar() : nullptr;
  if (!toolbar) return 0;
  int width = 0;
  for (const auto& child : toolbar->children())
    if (views::AsViewClass<Controls>(child.get()) || views::AsViewClass<PromoteButton>(child.get())) {
      const auto* margins = child->GetProperty(views::kMarginsKey);
      width += child->GetPreferredSize().width() + (margins ? margins->width() : 0);
    }
  return width;
}
void EnsureNativePreviewControls() {
  static bool installed = false;
  if (installed) return;
  SetNativeWindowDecorator(base::BindRepeating(&Decorate));
  installed = true;
}
}  // namespace aux::preview
