// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/ui/aux_preview/aux_preview_controller.h"
#include <algorithm>
#include "chrome/browser/ui/aux_preview/aux_preview_controls.h"
#include <map>
#include <memory>
#include <optional>
#include <utility>
#include "base/functional/bind.h"
#include "base/memory/weak_ptr.h"
#include "base/no_destructor.h"
#include "base/scoped_observation.h"
#include "base/task/sequenced_task_runner.h"
#include "base/time/time.h"
#include "base/strings/utf_string_conversions.h"
#include "chrome/browser/aux/AuxBrowserPrivateRoots.h"
#include "chrome/browser/aux/AuxSelectedStateHome.h"
#include "chrome/browser/aux/profile_identity.h"
#include "chrome/browser/browser_process.h"
#include "chrome/browser/media/webrtc/media_capture_devices_dispatcher.h"
#include "chrome/browser/media/webrtc/media_stream_capture_indicator.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/profiles/profile_attributes_entry.h"
#include "chrome/browser/profiles/profile_attributes_storage.h"
#include "chrome/browser/profiles/profile_manager.h"
#include "chrome/browser/profiles/profile_window.h"
#include "chrome/browser/ui/aux/page_identity.h"
#include "chrome/browser/ui/browser_commands.h"
#include "chrome/browser/ui/browser_init_state.h"
#include "chrome/browser/ui/browser_tabstrip.h"
#include "chrome/browser/ui/browser_window_state.h"
#include "chrome/browser/ui/browser_window/public/browser_collection_observer.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/browser_window/public/create_browser_window.h"
#include "chrome/browser/ui/browser_window/public/global_browser_collection.h"
#include "chrome/browser/ui/navigator/browser_navigator.h"
#include "chrome/browser/ui/navigator/browser_navigator_params.h"
#include "chrome/browser/ui/tabs/tab_strip_model.h"
#include "chrome/browser/ui/unload_controller.h"
#include "chrome/browser/ui/views/frame/aux_organization_window_controller.h"
#include "chrome/browser/ui/views/frame/aux_split_commands.h"
#include "chrome/grit/generated_resources.h"
#include "components/prefs/pref_service.h"
#include "components/prefs/scoped_user_pref_update.h"
#include "components/tabs/public/tab_interface.h"
#include "content/public/browser/browser_thread.h"
#include "content/public/browser/devtools_agent_host.h"
#include "content/public/browser/download_manager.h"
#include "content/public/browser/navigation_controller.h"
#include "content/public/browser/render_frame_host.h"
#include "content/public/browser/weak_document_ptr.h"
#include "content/public/browser/web_contents.h"
#include "ui/base/base_window.h"
#include "ui/base/l10n/l10n_util.h"
#include "ui/display/screen.h"
#include "url/origin.h"
namespace aux::preview {
namespace {
struct Window {
  Kind kind;
  base::WeakPtr<BrowserWindowInterface> browser;
  base::WeakPtr<BrowserWindowInterface> source;
  base::WeakPtr<Profile> profile;
  std::shared_ptr<const aux::peer::BrowserPrivateRoots> roots;
  std::string profile_id, epoch, restriction;
  uint64_t generation = 0;
  bool promoting = false;
  // The pending promotion joins the destination's active tab as a split.
  bool split = false;
  bool initialized = false;
  base::RepeatingClosureList changes;
};
class Registry final : public BrowserCollectionObserver {
 public:
  Registry() { observation_.Observe(GlobalBrowserCollection::GetInstance()); }
  void OnBrowserClosed(BrowserWindowInterface* browser) override { windows.erase(browser); }
  std::map<const BrowserWindowInterface*, std::shared_ptr<Window>> windows;
 private:
  base::ScopedObservation<GlobalBrowserCollection, BrowserCollectionObserver> observation_{this};
};
auto& Decorator() {
  static base::NoDestructor<base::RepeatingCallback<bool(BrowserWindowInterface*)>> callback;
  return *callback;
}
Registry& Windows() { static base::NoDestructor<Registry> registry; return *registry; }
std::shared_ptr<Window> Find(const BrowserWindowInterface* browser) {
  if (!browser) return nullptr;
  const auto found = Windows().windows.find(browser);
  return found == Windows().windows.end() ? nullptr : found->second;
}
BrowserWindowInterface* BrowserFor(content::WebContents* contents) {
  auto* tab = contents ? tabs::TabInterface::MaybeGetFromContents(contents) : nullptr;
  return tab ? tab->GetBrowserWindowInterface() : nullptr;
}
bool Regular(Profile* profile) {
  return profile && profile->IsRegularProfile() && !profile->IsOffTheRecord() &&
      profile == profile->GetOriginalProfile() && !aux::IsProfileCookieRestorePending(profile);
}
bool Current(const std::shared_ptr<Window>& window) {
  if (!window || !window->browser || !Regular(window->profile.get()) ||
      window->browser->GetProfile() != window->profile.get() ||
      !window->roots || !window->roots->Revalidate() ||
      aux::GetProfileId(window->profile.get()) != window->profile_id ||
      aux::GetProfileCookieBindingEpoch(window->profile.get()) != window->epoch) return false;
  const auto native = aux::peer::InspectNativeBrowserShutdown();
  return window->generation && !native.wrong_process && !native.admission_closed &&
      !native.sequence_uncertain && native.admitted_generation == window->generation;
}
bool BusyBrowser(BrowserWindowInterface* browser) {
  const auto* init = browser ? BrowserInitState::From(browser) : nullptr;
  const auto* unload = browser ? UnloadController::From(browser) : nullptr;
  return !browser || !init || init->is_aux_profile_switch_cache() || !unload ||
      unload->is_attempting_to_close_browser() || unload->is_delete_scheduled();
}
bool AgentOwned(content::WebContents* contents) {
  auto* tab = contents ? tabs::TabInterface::MaybeGetFromContents(contents) : nullptr;
  if (!tab) return true;
  const auto* identity = aux::PageIdentity::FromWebContents(contents);
  return identity && identity->runtime_owned();
}
bool Protected(content::WebContents* contents, bool moving = false) {
  // Close and history navigation use Chromium's real beforeunload dispatch.
  // The presence of a pagehide/visibility handler alone must not trap a preview.
  if (!contents || AgentOwned(contents) || (moving && contents->IsLoading()) ||
      contents->IsCurrentlyAudible() || contents->IsBeingCaptured()) return true;
  auto* tab = tabs::TabInterface::MaybeGetFromContents(contents);
  if (!tab || tab->IsBlocked() || tab->IsSplit()) return true;
  if (content::DevToolsAgentHost::HasFor(contents) &&
      content::DevToolsAgentHost::GetOrCreateFor(contents)->IsAttached()) return true;
  const auto capture = MediaCaptureDevicesDispatcher::GetInstance()->GetMediaStreamCaptureIndicator();
  if (capture->IsCapturingUserMedia(contents) || capture->IsBeingMirrored(contents) ||
      capture->IsCapturingTab(contents) || capture->IsCapturingWindow(contents) ||
      capture->IsCapturingDisplay(contents)) return true;
  auto* profile = Profile::FromBrowserContext(contents->GetBrowserContext());
  return !Regular(profile) || profile->GetDownloadManager()->InProgressCount() != 0;
}
bool SafeUrl(const GURL& url) {
  return url.is_valid() && url.SchemeIsHTTPOrHTTPS() && !url.has_username() &&
      !url.has_password() && url.spec().size() <= 16384;
}
// Little Aux's own place and size, in the profile's window-placement prefs
// beside Chromium's popup entry, which Peek and site popups share.
constexpr char kQuickPlacement[] = "aux_little_aux";
std::optional<gfx::Rect> SavedQuickBounds(Profile* profile) {
  const auto* saved = chrome::GetWindowPlacementDictionaryReadOnly(kQuickPlacement, profile->GetPrefs());
  const auto left = saved ? saved->FindInt("left") : std::nullopt;
  const auto top = saved ? saved->FindInt("top") : std::nullopt;
  const auto right = saved ? saved->FindInt("right") : std::nullopt;
  const auto bottom = saved ? saved->FindInt("bottom") : std::nullopt;
  if (!left || !top || !right || !bottom || *right - *left < 320 || *bottom - *top < 240)
    return std::nullopt;
  return gfx::Rect(*left, *top, *right - *left, *bottom - *top);
}
// `source` is null only for Little Aux opened with no window (Quick); Peek
// always previews a link of its source page.
OpenResult Open(Profile* profile, BrowserWindowInterface* source,
                content::RenderFrameHost* frame, const GURL& url, Kind kind) {
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  const bool sourced = source != nullptr;
  if ((sourced && (BusyBrowser(source) || source->GetProfile() != profile || !frame)) ||
      (!sourced && kind != Kind::kQuick) || !Regular(profile) ||
      (!SafeUrl(url) && !(kind == Kind::kQuick && url.is_empty())))
    return {.error = "A regular active profile and HTTP(S) link are required"};
  EnsureNativePreviewControls();
  if (!Decorator()) return {.error = "Native preview controls are unavailable"};
  content::WeakDocumentPtr document;
  base::WeakPtr<content::WebContents> source_contents;
  if (sourced) {
    auto* contents = source->GetTabStripModel()->GetActiveWebContents();
    if (!contents || !frame->IsActive() || content::WebContents::FromRenderFrameHost(frame) != contents ||
        frame->GetBrowserContext() != profile || AgentOwned(contents))
      return {.error = "The source document is unavailable or controlled by active work"};
    document = frame->GetWeakDocumentPtr();
    source_contents = contents->GetWeakPtr();
  }
  auto source_weak = sourced ? source->GetWeakPtr() : nullptr;
  auto window = std::make_shared<Window>();
  window->kind = kind; window->source = source_weak;
  window->profile = profile->GetWeakPtr();
  window->roots = aux::peer::CaptureActualChromiumBrowserRoots();
  const auto native = aux::peer::InspectNativeBrowserShutdown();
  if (!window->roots || !window->roots->Revalidate() || !native.admitted_generation ||
      native.wrong_process || native.admission_closed || native.sequence_uncertain)
    return {.error = "Browser startup authority is unavailable"};
  window->generation = native.admitted_generation;
  window->profile_id = aux::GetProfileId(profile);
  window->epoch = aux::GetProfileCookieBindingEpoch(profile);
  auto* screen = display::Screen::Get();
  if (!screen || window->epoch.empty()) return {.error = "Preview window is unavailable"};
  // Peek is a sheet over the source page's card; Little Aux returns to where
  // it was last left, else centers over the source window or the main display.
  auto saved = kind == Kind::kPeek ? PeekSheetBounds(source) : SavedQuickBounds(profile);
  const auto anchor = sourced ? source->GetWindow()->GetBounds()
                              : screen->GetPrimaryDisplay().work_area();
  const auto area = saved ? screen->GetDisplayMatching(*saved).work_area()
                          : screen->GetDisplayMatching(anchor).work_area();
  gfx::Rect bounds = saved.value_or(gfx::Rect(std::min(760, area.width()), std::min(560, area.height())));
  if (!saved)
    bounds.set_origin(gfx::Point(anchor.x() + (anchor.width() - bounds.width()) / 2,
                                anchor.y() + (anchor.height() - bounds.height()) / 2));
  bounds.AdjustToFit(area);
  BrowserWindowCreateParams params(BrowserWindowInterface::TYPE_POPUP, profile, true);
  params.initial_bounds = bounds;
  params.omit_from_session_restore = true;
  // Marks the Little Arc frame: one bar in the traffic-light row.
  params.app_name = "aux-preview-popup";
  params.should_trigger_session_restore = false;
  params.is_trusted_source = false;  // Always retain the actual native origin UI.
  const auto source_current = [&]() {
    if (!sourced) return true;
    auto* live_frame = document.AsRenderFrameHostIfValid();
    return source_weak && source_contents && live_frame && live_frame->IsActive() &&
        !BusyBrowser(source_weak.get()) &&
        source_weak->GetProfile() == window->profile.get() &&
        source_weak->GetTabStripModel()->GetActiveWebContents() == source_contents.get() &&
        content::WebContents::FromRenderFrameHost(live_frame) == source_contents.get() &&
        !AgentOwned(source_contents.get());
  };
  auto* browser = CreateBrowserWindow(std::move(params));
  if (!browser) return {.error = "Could not create a native preview window"};
  window->browser = browser->GetWeakPtr();
  Windows().windows[browser] = window;
  // Creation can run native callbacks. Recheck the original document/owner
  // before starting any network request; no speculative loads were scheduled.
  if (!Current(window) || !source_current()) {
    browser->GetWindow()->Close();
    return {.error = "The source profile or document changed"};
  }
  // Insert an actual blank native tab first so its TabInterface/window owner
  // already exists when the target request's navigation throttles are created.
  auto* blank = chrome::AddAndReturnTabAt(browser, GURL("about:blank"), -1, true,
      std::nullopt, false, NavigateParams::WindowAction::kNoAction);
  const auto blank_contents = blank ? blank->GetWeakPtr() : nullptr;
  if (!blank_contents || !window->browser || !Decorator().Run(window->browser.get()) ||
      !Current(window) || !source_current() || !blank_contents ||
      window->browser->GetTabStripModel()->count() != 1 ||
      window->browser->GetTabStripModel()->GetActiveWebContents() != blank_contents.get()) {
    if (window->browser) window->browser->GetWindow()->Close();
    return {.error = "The source or native preview controls became unavailable"};
  }
  if (!url.is_empty()) {
    NavigateParams navigation(window->browser.get(), url, ui::PAGE_TRANSITION_LINK);
    navigation.disposition = WindowOpenDisposition::CURRENT_TAB;
    navigation.initiator_origin = url::Origin();
    Navigate(&navigation);
    if (!Current(window) || !blank_contents ||
        navigation.navigated_or_inserted_contents != blank_contents.get() ||
        window->browser->GetTabStripModel()->GetActiveWebContents() != blank_contents.get()) {
      if (window->browser) window->browser->GetWindow()->Close();
      return {.error = "Preview navigation was refused"};
    }
  }
  // Popup initial bounds can be read as content bounds; place the frame itself
  // so a remembered Little Aux does not creep by its bar's height each time.
  window->browser->GetWindow()->SetBounds(bounds);
  window->initialized = true;
  window->browser->GetWindow()->Show();
  if (!Current(window) || BusyBrowser(window->browser.get()))
    return {.error = "Preview owner changed while showing the window"};
  if (kind == Kind::kPeek) {
    PresentPeekSheet(window->browser.get());
    if (!Current(window) || BusyBrowser(window->browser.get()))
      return {.error = "Preview owner changed while presenting the sheet"};
  }
  window->browser->GetWindow()->Activate();
  if (!Current(window) || BusyBrowser(window->browser.get()))
    return {.error = "Preview owner changed while activating the window"};
  if (url.is_empty()) {
    chrome::FocusLocationBar(window->browser.get());
    ClearQuickAddress(window->browser.get());
  }
  if (!Current(window) || BusyBrowser(window->browser.get()))
    return {.error = "Preview owner changed before opening completed"};
  return {.browser = window->browser.get()};
}
base::DictValue Result(bool ok, std::string message = {}) {
  return base::DictValue().Set("ok", ok).Set("error", message);
}
void Move(std::shared_ptr<Window> window, std::string space,
          base::OnceCallback<void(base::DictValue)> done,
          BrowserWindowInterface* target) {
  if (!Current(window) || !window->promoting || BusyBrowser(target) ||
      target->GetType() != BrowserWindowInterface::TYPE_NORMAL ||
      target->GetProfile() != window->profile.get() || Find(target)) {
    window->promoting = window->split = false; std::move(done).Run(Result(false, "Destination is unavailable")); return;
  }
  auto* browser = window->browser.get();
  auto* model = browser->GetTabStripModel();
  if (model->count() != 1 || Protected(model->GetActiveWebContents(), true)) {
    window->promoting = window->split = false; std::move(done).Run(Result(false, "Finish active preview work before promoting")); return;
  }
  const auto handle = model->GetTabAtIndex(0)->GetHandle();
  const auto contents = model->GetActiveWebContents()->GetWeakPtr();
  auto destination = target->GetWeakPtr();
  auto* organization = aux::AuxOrganizationWindowController::FromBrowser(target);
  if (!organization || !organization->IsProjectionReady() ||
      (!space.empty() && !organization->SelectSpace(space))) {
    window->promoting = window->split = false; std::move(done).Run(Result(false, "Destination Space is unavailable or busy")); return;
  }
  // Space selection can synchronously project tabs, switch ownership or close
  // a window. Reacquire both real owners and the SAME source tab afterward.
  browser = window->browser.get();
  model = browser ? browser->GetTabStripModel() : nullptr;
  organization = destination ? aux::AuxOrganizationWindowController::FromBrowser(destination.get()) : nullptr;
  if (!Current(window) || !destination || BusyBrowser(destination.get()) ||
      destination->GetProfile() != window->profile.get() || Find(destination.get()) ||
      !organization || !organization->IsProjectionReady() ||
      (!space.empty() && organization->ActiveSpaceId() != space) ||
      !model || model->count() != 1 || !contents || !handle.Get() ||
      model->GetTabAtIndex(0) != handle.Get() ||
      model->GetActiveWebContents() != contents.get() || Protected(contents.get(), true)) {
    window->promoting = window->split = false; std::move(done).Run(Result(false, "The preview or destination changed before handoff")); return;
  }
  // "Open in split" pairs the page with the tab the destination was showing.
  auto* partner = window->split ? destination->GetTabStripModel()->GetActiveTab() : nullptr;
  const auto partner_handle = partner ? partner->GetHandle() : tabs::TabHandle();
  window->split = false;
  // Chromium transfers the real TabModel/WebContents and navigation history.
  // The source popup can close synchronously as its final tab leaves.
  chrome::MoveTabsToExistingWindow(browser, destination.get(), {0});
  const auto moved_here = [&]() {
    const auto native = aux::peer::InspectNativeBrowserShutdown();
    return destination && window->profile && contents && handle.Get() &&
        !BusyBrowser(destination.get()) &&
        destination->GetProfile() == window->profile.get() &&
        aux::GetProfileCookieBindingEpoch(window->profile.get()) == window->epoch &&
        !aux::IsProfileCookieRestorePending(window->profile.get()) &&
        window->roots && window->roots->Revalidate() && window->generation &&
        native.admitted_generation == window->generation && !native.wrong_process &&
        !native.admission_closed && !native.sequence_uncertain &&
        handle.Get()->GetContents() == contents.get() &&
        handle.Get()->GetBrowserWindowInterface() == destination.get();
  };
  window->promoting = false;
  if (moved_here()) {
    destination->GetWindow()->Show();
    if (!moved_here()) {
      std::move(done).Run(Result(false, "Destination changed after handoff; the tab was not reopened"));
      return;
    }
    destination->GetWindow()->Activate();
    if (!moved_here()) {
      std::move(done).Run(Result(false, "Destination changed during activation; the tab was not reopened"));
      return;
    }
    // A split the destination can't take leaves the page as an ordinary tab.
    if (partner_handle.Get())
      aux::JoinNativeSplit(*destination, partner_handle.Get(), handle.Get(),
                           split_tabs::SplitPaneTree::Axis::kHorizontal, false);
    std::move(done).Run(Result(true));
  } else {
    std::move(done).Run(Result(false, "The tab could not be moved; it was not reopened"));
  }
}
// A window Chromium has just opened may still be projecting its Spaces; a
// Space choice waits for it briefly before Move decides.
void MoveWhenReady(std::shared_ptr<Window> window, std::string space,
                   base::OnceCallback<void(base::DictValue)> done,
                   base::WeakPtr<BrowserWindowInterface> target, int attempts) {
  auto* organization = target ? aux::AuxOrganizationWindowController::FromBrowser(target.get()) : nullptr;
  if (space.empty() || !organization || organization->IsProjectionReady() || attempts <= 0) {
    Move(std::move(window), std::move(space), std::move(done), target.get());
    return;
  }
  base::SequencedTaskRunner::GetCurrentDefault()->PostDelayedTask(FROM_HERE,
      base::BindOnce(&MoveWhenReady, std::move(window), std::move(space), std::move(done),
                     std::move(target), attempts - 1),
      base::Milliseconds(100));
}
void MoveToOpened(std::shared_ptr<Window> window, std::string space,
                  base::OnceCallback<void(base::DictValue)> done,
                  BrowserWindowInterface* target) {
  MoveWhenReady(std::move(window), std::move(space), std::move(done),
                target ? target->GetWeakPtr() : nullptr, 30);
}
}  // namespace
void SetNativeWindowDecorator(base::RepeatingCallback<bool(BrowserWindowInterface*)> callback) {
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  Decorator() = std::move(callback);
}
base::CallbackListSubscription ObservePresentation(BrowserWindowInterface* browser, base::RepeatingClosure callback) {
  const auto window = Find(browser);
  return window ? window->changes.Add(std::move(callback)) : base::CallbackListSubscription();
}
OpenResult OpenPeek(BrowserWindowInterface* browser, content::RenderFrameHost* frame,
                    const GURL& url, Trigger trigger) {
  if (trigger == Trigger::kOptInLinkClick &&
      (!browser || !browser->GetProfile()->GetPrefs()->FindPreference(kPeekOrdinaryLinksPref) ||
       !browser->GetProfile()->GetPrefs()->GetBoolean(kPeekOrdinaryLinksPref)))
    return {.error = "Ordinary-link Peek is disabled"};
  return browser ? Open(browser->GetProfile(), browser, frame, url, Kind::kPeek)
                 : OpenResult{.error = "A source window is required"};
}
bool CanOpenQuick(BrowserWindowInterface* browser) {
  if (BusyBrowser(browser) || !Regular(browser->GetProfile())) return false;
  auto* contents = browser->GetTabStripModel()->GetActiveWebContents();
  if (!contents || !contents->GetPrimaryMainFrame() || AgentOwned(contents)) return false;
  const auto roots = aux::peer::CaptureActualChromiumBrowserRoots();
  const auto native = aux::peer::InspectNativeBrowserShutdown();
  return roots && roots->Revalidate() && native.admitted_generation &&
      !native.wrong_process && !native.admission_closed && !native.sequence_uncertain;
}
OpenResult OpenQuick(BrowserWindowInterface* browser, const GURL& url) {
  auto* contents = browser ? browser->GetTabStripModel()->GetActiveWebContents() : nullptr;
  if (!browser) return {.error = "A source window is required"};
  return Open(browser->GetProfile(), browser, contents ? contents->GetPrimaryMainFrame() : nullptr,
              url == GURL("about:blank") ? GURL() : url, Kind::kQuick);
}
OpenResult OpenQuickForProfile(Profile* profile, const GURL& url) {
  if (!profile) return {.error = "A regular active profile is required"};
  return Open(profile, nullptr, nullptr, url == GURL("about:blank") ? GURL() : url, Kind::kQuick);
}
void RememberQuickBounds(BrowserWindowInterface* browser) {
  const auto window = Find(browser);
  if (!window || window->kind != Kind::kQuick || !window->initialized || !window->profile) return;
  const auto bounds = browser->GetWindow()->GetBounds();
  if (bounds.IsEmpty() || browser->GetWindow()->IsMinimized() ||
      browser->GetWindow()->IsFullscreen()) return;
  std::unique_ptr<ScopedDictPrefUpdate> update;
  auto& placement = chrome::GetWindowPlacementDictionaryReadWrite(
      kQuickPlacement, window->profile->GetPrefs(), update);
  placement.Set("left", bounds.x());
  placement.Set("top", bounds.y());
  placement.Set("right", bounds.right());
  placement.Set("bottom", bounds.bottom());
}
std::optional<Kind> GetKind(const BrowserWindowInterface* browser) {
  const auto window = Find(browser);
  return window ? std::optional(window->kind) : std::nullopt;
}
BrowserWindowInterface* GetSource(const BrowserWindowInterface* browser) {
  const auto window = Find(browser);
  return window ? window->source.get() : nullptr;
}
bool IsPreviewContents(content::WebContents* contents) {
  return GetKind(BrowserFor(contents)).has_value();
}
bool IsPeekContents(content::WebContents* contents) {
  return GetKind(BrowserFor(contents)) == Kind::kPeek;
}
bool CanClose(BrowserWindowInterface* browser, std::string* reason) {
  const auto window = Find(browser);
  if (!window) return true;
  if (browser->GetTabStripModel()->empty()) return true;
  if (!window->initialized && browser->GetTabStripModel()->count() == 1 &&
      browser->GetTabStripModel()->GetActiveWebContents()->GetVisibleURL() == GURL("about:blank")) return true;
  if (!Current(window) || window->promoting) {
    if (reason) *reason = l10n_util::GetStringUTF8(IDS_AUX_PREVIEW_SETTLING);
    return false;
  }
  for (auto* tab : *browser->GetTabStripModel()) {
    if (Protected(tab->GetContents())) {
      if (reason) *reason = l10n_util::GetStringUTF8(IDS_AUX_PREVIEW_CLOSE_BUSY);
      return false;
    }
  }
  return true;
}
bool Dismiss(BrowserWindowInterface* browser, std::string* reason) {
  if (!Find(browser) || !CanClose(browser, reason)) return false;
  browser->GetWindow()->Close(); return true;
}
bool Back(BrowserWindowInterface* browser) {
  const auto window = Find(browser);
  auto* contents = browser ? browser->GetTabStripModel()->GetActiveWebContents() : nullptr;
  if (!Current(window) || window->promoting || Protected(contents) ||
      !contents->GetController().CanGoBack()) return false;
  contents->GetController().GoBack(); return true;
}
void Promote(BrowserWindowInterface* browser, BrowserWindowInterface* destination,
             const std::string& space, base::OnceCallback<void(base::DictValue)> done) {
  const auto window = Find(browser);
  if (!Current(window) || window->promoting || browser->GetTabStripModel()->count() != 1 ||
      Protected(browser->GetTabStripModel()->GetActiveWebContents(), true)) {
    std::move(done).Run(Result(false, "Preview is unavailable or has active work")); return;
  }
  const bool explicit_destination = destination != nullptr;
  const auto requested_destination = destination ? destination->GetWeakPtr() : nullptr;
  window->promoting = true;
  window->changes.Notify();
  if (!Current(window)) {
    window->promoting = false;
    std::move(done).Run(Result(false, "Preview owner changed")); return;
  }
  if (explicit_destination) {
    if (!requested_destination) {
      window->promoting = false;
      std::move(done).Run(Result(false, "The chosen destination closed"));
      return;
    }
    Move(window, space, std::move(done), requested_destination.get()); return;
  }
  if (window->source && !BusyBrowser(window->source.get()) &&
      window->source->GetType() == BrowserWindowInterface::TYPE_NORMAL &&
      window->source->GetProfile() == window->profile.get()) {
    Move(window, space, std::move(done), window->source.get()); return;
  }
  profiles::OpenBrowserWindowForProfile(
      base::BindOnce(&MoveToOpened, window, space, std::move(done)), false, false, false,
      window->profile.get());
}
void PromoteToSplit(BrowserWindowInterface* browser,
                    base::OnceCallback<void(base::DictValue)> done) {
  const auto window = Find(browser);
  // A split needs a tab to sit beside: only Peek's own source window has it.
  if (!window || window->kind != Kind::kPeek || !window->source ||
      window->source->GetType() != BrowserWindowInterface::TYPE_NORMAL ||
      !window->source->GetTabStripModel()->GetActiveTab()) {
    std::move(done).Run(Result(false, "Split view needs the window this preview came from"));
    return;
  }
  if (window->promoting) {
    std::move(done).Run(Result(false, "Preview is unavailable or has active work"));
    return;
  }
  window->split = true;
  Promote(browser, window->source.get(), {}, std::move(done));
  // An explicit destination settles synchronously; a refusal before Move
  // must not leave the next promotion splitting.
  if (!window->promoting) window->split = false;
}
base::DictValue Presentation(BrowserWindowInterface* browser) {
  const auto window = Find(browser);
  if (!window) return base::DictValue();
  std::string name = "Profile";
  if (window->profile && g_browser_process && g_browser_process->profile_manager()) {
    auto* entry = g_browser_process->profile_manager()->GetProfileAttributesStorage()
        .GetProfileAttributesWithPath(window->profile->GetPath());
    if (entry) name = base::UTF16ToUTF8(entry->GetName());
  }
  auto* contents = browser->GetTabStripModel()->GetActiveWebContents();
  return base::DictValue().Set("mode", window->kind == Kind::kPeek ? "peek" : "quick")
      .Set("profileName", name).Set("restriction", window->restriction)
      .Set("canBack", contents && contents->GetController().CanGoBack())
      .Set("promoting", window->promoting);
}
bool AllowNewContents(content::WebContents* source) {
  if (!IsPeekContents(source)) return true;
  ReportRestriction(source, l10n_util::GetStringUTF8(IDS_AUX_PEEK_NO_NEW_WINDOWS));
  return false;
}
void ReportRestriction(content::WebContents* contents, std::string reason) {
  if (const auto window = Find(BrowserFor(contents))) {
    window->restriction = std::move(reason);
    window->changes.Notify();
  }
}
bool CurrentOwner(content::WebContents* contents) { return Current(Find(BrowserFor(contents))); }
}  // namespace aux::preview
