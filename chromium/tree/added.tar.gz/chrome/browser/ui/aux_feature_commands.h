// Copyright 2026 The Aux Authors. BSD-style license: see //LICENSE.
#ifndef CHROME_BROWSER_UI_AUX_FEATURE_COMMANDS_H_
#define CHROME_BROWSER_UI_AUX_FEATURE_COMMANDS_H_
#include <string>
#include <vector>
class BrowserWindowInterface;
namespace aux {
// Switch to Space 1..9: kAuxSwitchToSpaceFirst + 0..8, Ctrl+1..9 by default.
inline constexpr int kAuxSwitchToSpaceFirst = 34140;
inline constexpr int kAuxSwitchToSpaceLast = 34148;
// Help › Keyboard Shortcuts.
inline constexpr int kAuxShowKeyboardShortcuts = 34149;
// Pause or resume ad blocking on the active tab's site, then reload it.
inline constexpr int kAuxToggleSiteAdblock = 34150;
// The window's Spaces in order, for the Spaces menu.
struct AuxSpaceMenuEntry {
  std::u16string name;
  bool active = false;
};
std::vector<AuxSpaceMenuEntry> GetAuxSpaceMenuEntries(BrowserWindowInterface* browser);
bool IsAuxFeatureCommand(int command);
// Whether ad blocking is paused on the active tab's site.
bool IsAuxSiteAdblockPaused(BrowserWindowInterface* browser);
bool IsAuxFeatureCommandEnabled(BrowserWindowInterface* browser, int command);
bool ExecuteAuxFeatureCommand(BrowserWindowInterface* browser, int command);
}  // namespace aux
#endif
