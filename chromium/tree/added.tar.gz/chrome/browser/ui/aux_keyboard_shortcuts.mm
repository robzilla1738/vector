// Copyright 2026 Aux Authors. All rights reserved.
#include "chrome/browser/ui/aux_keyboard_shortcuts.h"

#import <AppKit/AppKit.h>
#import <objc/runtime.h>
#include "ui/base/cocoa/command_dispatcher.h"
#include <algorithm>
#include <iterator>
#include <set>
#include <string_view>
#include <vector>
#include "base/no_destructor.h"
#include "base/apple/scoped_cftyperef.h"
#include "base/json/json_writer.h"
#include "chrome/browser/aux/AuxBrowserPrivateRoots.h"
#include "chrome/browser/aux/AuxSelectedStateHome.h"
#include "chrome/browser/aux/profile_identity.h"
#include "content/public/browser/browser_thread.h"
#include "crypto/hash.h"

#include "chrome/app/chrome_command_ids.h"
#include "chrome/browser/ui/browser_commands.h"
#include "chrome/browser/ui/aux_feature_commands.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/utf_string_conversions.h"
#include "base/supports_user_data.h"
#include "chrome/browser/browser_process.h"
#include "chrome/browser/extensions/api/aux_mini_popup/aux_mini_popup_api.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/ui/aux_keyboard_shortcut_parser.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/browser_window/public/global_browser_collection.h"
#include "components/pref_registry/pref_registry_syncable.h"
#include "components/prefs/pref_service.h"
#include "content/public/browser/web_contents.h"
#include "content/public/browser/web_contents_observer.h"
#include "ui/base/accelerators/accelerator.h"
#include "ui/base/accelerators/global_accelerator_listener/global_accelerator_listener.h"
#include "ui/base/accelerators/platform_accelerator_cocoa.h"
#include "ui/events/event_constants.h"
#include "ui/events/keycodes/keyboard_code_conversion_mac.h"
#include "ui/gfx/native_ui_types.h"

namespace aux {
namespace {
constexpr char kOverrides[] = "aux.browser.keyboard_shortcuts";
constexpr char kPopupShortcut[] = "aux.popup.shortcut";
constexpr int kPopup = 34069;
struct Binding {
  int command;
  std::string_view shortcut;
};
constexpr Binding kBindings[] = {
    {34061, "Command+S"},       {52500, "Command+Shift+A"},
    {34068, "Ctrl+Command+E"},  {34067, "Command+Shift+E"},
    {34071, "Command+Shift+C"}, {34057, "Command+Shift+\\"},
    {34066, "Command+Shift+-"}, {kPopup, "Alt+Space"},
    {IDC_NEW_TAB, "Command+T"}, {IDC_FOCUS_LOCATION, "Command+L"},
    {IDC_FOCUS_SEARCH, "Command+K"}, {IDC_CLOSE_TAB, "Command+W"},
    {IDC_RESTORE_TAB, "Command+Shift+T"}, {IDC_RELOAD, "Command+R"},
    {IDC_RELOAD_BYPASSING_CACHE, "Command+Shift+R"},
    {IDC_BACK, "Command+Left"}, {IDC_FORWARD, "Command+Right"},
    {IDC_SHOW_DOWNLOADS, "Command+Shift+J"},
    {IDC_DEV_TOOLS, "Command+Alt+I"}, {IDC_VIEW_SOURCE, "Command+Alt+U"},
    {34120, "Ctrl+Command+S"},
    {34121, "Ctrl+Command+L"},
    {34122, "Ctrl+Command+N"},
    {34123, "Ctrl+Command+Right"},
    {34124, "Ctrl+Command+Left"},
    {34125, "Ctrl+Command+G"},
    {34126, "Ctrl+Command+P"},
    {34127, "Ctrl+Command+K"},
    {34128, "Ctrl+Command+W"},
    {34129, "Ctrl+Command+U"},
    {34130, "Ctrl+Command+Period"},
    {34131, "Ctrl+Command+Comma"},
    {34132, "Ctrl+Command+\\"},
    {34133, "Ctrl+Command+-"},
    {34134, "Ctrl+Command+X"},
    {34135, "Alt+Command+N"},
    {34136, "Command+Shift+2"},
    {34137, "Ctrl+Command+V"},
    {34138, "Ctrl+Command+I"},
    {34139, "Ctrl+Command+T"},
    // Switch to Space 1-9, as in Arc.
    {34140, "Ctrl+1"}, {34141, "Ctrl+2"}, {34142, "Ctrl+3"},
    {34143, "Ctrl+4"}, {34144, "Ctrl+5"}, {34145, "Ctrl+6"},
    {34146, "Ctrl+7"}, {34147, "Ctrl+8"}, {34148, "Ctrl+9"},
    {34149, ""}};
struct NavigationCommand { int command; const char* id; const char* title; };
constexpr NavigationCommand kNavigationCommands[] = {
    {IDC_NEW_TAB, "new-tab", "New tab"},
    {IDC_FOCUS_LOCATION, "navigate", "Open URL or search"},
    {IDC_FOCUS_SEARCH, "command-bar", "Commands"},
    {IDC_BACK, "back", "Back"}, {IDC_FORWARD, "forward", "Forward"},
    {IDC_RELOAD, "reload", "Reload"},
    {IDC_RELOAD_BYPASSING_CACHE, "reload-without-cache", "Reload without cache"},
    {IDC_STOP, "stop", "Stop loading"}, {IDC_CLOSE_TAB, "close-tab", "Close tab"},
    {IDC_RESTORE_TAB, "restore-tab", "Reopen closed tab"},
    {IDC_SHOW_DOWNLOADS, "downloads", "Downloads"},
    {IDC_SHOW_HISTORY, "history", "History"},
    {IDC_DEV_TOOLS, "developer-tools", "Developer tools"},
    {IDC_DEV_TOOLS_INSPECT, "inspect", "Inspect page"},
    {IDC_VIEW_SOURCE, "view-source", "View source"},
    {34061, "sidebar", "Toggle sidebar"},
    {34068, "ask-aux", "Ask Aux"}, {34071, "copy-url", "Copy URL"},
    {34120, "minimal", "Toggle minimal UI"},
    {34121, "sidebar-navigation", "Toggle navigation in sidebar"},
    {34122, "new-space", "New Space"},
    {34123, "next-space", "Next Space"},
    {34124, "previous-space", "Previous Space"},
    {34125, "new-folder", "New folder"},
    {34126, "pin-current", "Pin current tab"},
    {34127, "keep-in-space", "Keep tab in Space"},
    {34128, "archive-current", "Archive current tab"},
    {34129, "unload-current-view", "Unload current tab view"},
    {34130, "next-pane", "Next pane"},
    {34131, "previous-pane", "Previous pane"},
    {34132, "split-horizontal", "Split horizontally"},
    {34133, "split-vertical", "Split vertically"},
    {34134, "unsplit", "Remove split"},
    {34135, "quick-window", "Quick window"},
    {34136, "screenshot", "Take screenshot"},
    {34137, "pip", "Picture in picture"},
    {34138, "developer-mode", "Toggle developer mode"},
    {34139, "theme-editor", "Edit theme"},
    {34140, "space-1", "Switch to Space 1"}, {34141, "space-2", "Switch to Space 2"},
    {34142, "space-3", "Switch to Space 3"}, {34143, "space-4", "Switch to Space 4"},
    {34144, "space-5", "Switch to Space 5"}, {34145, "space-6", "Switch to Space 6"},
    {34146, "space-7", "Switch to Space 7"}, {34147, "space-8", "Switch to Space 8"},
    {34148, "space-9", "Switch to Space 9"},
    {34149, "keyboard-shortcuts", "Keyboard shortcuts"}};

const Binding* FindBinding(int command) {
  const auto it = std::ranges::find(kBindings, command, &Binding::command);
  return it == std::end(kBindings) ? nullptr : it;
}

std::string Default(const Binding& binding) {
  if (binding.command != kPopup)
    return std::string(binding.shortcut);
  // Preserve the real registered global owner's default, not the UI fallback.
  return g_browser_process->local_state()
      ->GetDefaultPrefValue(kPopupShortcut)
      ->GetString();
}
std::string Effective(Profile* profile, const Binding& binding) {
  if (binding.command == kPopup)
    return g_browser_process->local_state()->GetString(kPopupShortcut);
  if (!profile->GetPrefs()->FindPreference(kOverrides)) return Default(binding);
  const auto* saved = profile->GetPrefs()
                          ->GetDict(kOverrides)
                          .FindString(base::NumberToString(binding.command));
  return saved && (saved->empty() || ParseKeyboardShortcut(*saved)) ? *saved : Default(binding);
}
class Capture;
std::set<Capture*>& Captures() {
  static base::NoDestructor<std::set<Capture*>> captures;
  return *captures;
}
bool& PreviouslySuspended() {
  static bool value = false;
  return value;
}
const char kCaptureKey[] = "aux.kCaptureKey";
class Capture : public base::SupportsUserData::Data,
                public content::WebContentsObserver {
 public:
  explicit Capture(content::WebContents* contents)
      : WebContentsObserver(contents) {}
  ~Capture() override { Set(false); }
  void Set(bool suspended) {
    auto& captures = Captures();
    if (suspended == captures.contains(this))
      return;
    auto* listener = ui::GlobalAcceleratorListener::GetInstance();
    if (suspended) {
      if (captures.empty()) {
        PreviouslySuspended() =
            listener && listener->IsShortcutHandlingSuspended();
        if (listener)
          listener->SetShortcutHandlingSuspended(true);
      }
      captures.insert(this);
    } else {
      captures.erase(this);
      if (captures.empty() && listener && !PreviouslySuspended())
        listener->SetShortcutHandlingSuspended(false);
    }
  }
  void PrimaryPageChanged(content::Page&) override { Set(false); }
  void PrimaryMainFrameRenderProcessGone(base::TerminationStatus) override {
    Set(false);
  }
  void WebContentsDestroyed() override { Set(false); }
};
const char kOriginalMenuEquivalent[] = "aux.kOriginalMenuEquivalent";
NSDictionary* OriginalMenuEquivalent(NSMenuItem* item) {
  NSDictionary* original = objc_getAssociatedObject(item, &kOriginalMenuEquivalent);
  // Respect a real native owner changing a menu item after our last update;
  // only our own last-written equivalent may be restored from the snapshot.
  if (!original || ![original[@"lastKey"] isEqualToString:item.keyEquivalent] ||
      [original[@"lastModifiers"] unsignedIntegerValue] != item.keyEquivalentModifierMask) {
    original = @{@"key": item.keyEquivalent ?: @"",
                 @"modifiers": @(item.keyEquivalentModifierMask),
                 @"lastKey": item.keyEquivalent ?: @"",
                 @"lastModifiers": @(item.keyEquivalentModifierMask)};
    objc_setAssociatedObject(item, &kOriginalMenuEquivalent, original,
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
  }
  return original;
}
void SetMenuEquivalent(NSMenuItem* item, NSString* key, NSUInteger modifiers) {
  NSDictionary* original = OriginalMenuEquivalent(item);
  item.keyEquivalent = key;
  item.keyEquivalentModifierMask = modifiers;
  objc_setAssociatedObject(item, &kOriginalMenuEquivalent,
      @{@"key": original[@"key"], @"modifiers": original[@"modifiers"],
        @"lastKey": key, @"lastModifiers": @(modifiers)},
      OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
bool SameEquivalent(NSString* key, NSUInteger modifiers,
                    KeyEquivalentAndModifierMask* other) {
  return [key isEqualToString:other.keyEquivalent] && modifiers == other.modifierMask;
}
void UpdateMenuItem(Profile* profile, NSMenuItem* item) {
  if (item.action != @selector(commandDispatch:) &&
      item.action != @selector(commandDispatchUsingKeyModifiers:))
    return;
  const auto* binding = FindBinding(item.tag);
  NSDictionary* original = OriginalMenuEquivalent(item);
  if (binding && binding->command != kPopup) {
    const auto parsed = ParseKeyboardShortcut(Effective(profile, *binding));
    if (!parsed) {
      SetMenuEquivalent(item, @"", 0);
      return;
    }
    auto* equivalent = ui::GetKeyEquivalentAndModifierMaskFromAccelerator(*parsed);
    SetMenuEquivalent(item, equivalent.keyEquivalent, equivalent.modifierMask);
    return;
  }
  NSString* key = original[@"key"];
  NSUInteger modifiers = [original[@"modifiers"] unsignedIntegerValue];
  // A supplied/profile shortcut may displace an unrelated upstream default
  // (e.g. Toggle Sidebar / Save Page). Remove only its misleading key hint,
  // retaining the actual menu item and all native click/enabled validation.
  if (key.length) {
    for (const auto& candidate : kBindings) {
      if (candidate.command == kPopup) continue;
      const auto parsed = ParseKeyboardShortcut(Effective(profile, candidate));
      if (parsed && SameEquivalent(key, modifiers,
          ui::GetKeyEquivalentAndModifierMaskFromAccelerator(*parsed))) {
        key = @"";
        modifiers = 0;
        break;
      }
    }
  }
  SetMenuEquivalent(item, key, modifiers);
}
void UpdateMenu(Profile* profile, NSMenu* menu) {
  for (NSMenuItem* item in menu.itemArray) {
    UpdateMenuItem(profile, item);
    if (item.submenu) UpdateMenu(profile, item.submenu);
  }
}
void RefreshActiveMenu() {
  auto* browser = GlobalBrowserCollection::GetInstance()->GetActiveBrowser();
  if (browser) RefreshKeyboardShortcutMenu(browser->GetProfile());
}
bool MenuConflict(Profile* profile, NSMenu* menu,
                  KeyEquivalentAndModifierMask* key, int command,
                  const base::DictValue* prospective = nullptr) {
  for (NSMenuItem* item in menu.itemArray) {
    if (item.submenu && MenuConflict(profile, item.submenu, key, command, prospective))
      return true;
    if (item.tag == command) continue;
    const auto* binding = FindBinding(item.tag);
    if (binding && binding->command != kPopup) {
      const auto* proposed = prospective
          ? prospective->FindString(base::NumberToString(binding->command)) : nullptr;
      const auto effective = ParseKeyboardShortcut(prospective
          ? (proposed ? *proposed : Default(*binding)) : Effective(profile, *binding));
      if (effective) {
        auto* equivalent = ui::GetKeyEquivalentAndModifierMaskFromAccelerator(*effective);
        if (SameEquivalent(equivalent.keyEquivalent, equivalent.modifierMask, key))
          return true;
      }
    } else {
      NSDictionary* original = OriginalMenuEquivalent(item);
      if (SameEquivalent(original[@"key"],
                         [original[@"modifiers"] unsignedIntegerValue], key))
        return true;
    }
  }
  return false;
}
base::DictValue ShortcutFailure(std::string error) {
  return base::DictValue().Set("success", false).Set("error", std::move(error));
}
std::string Digest(std::string_view text) {
  return base::HexEncode(crypto::hash::Sha256(text));
}
std::string ShortcutOwner(Profile* profile) {
  DCHECK_CURRENTLY_ON(content::BrowserThread::UI);
  if (!g_browser_process || !g_browser_process->local_state() ||
      !profile || !profile->IsRegularProfile() || profile->IsOffTheRecord() ||
      profile != profile->GetOriginalProfile() || IsProfileCookieRestorePending(profile))
    return {};
  const auto roots = peer::CaptureActualChromiumBrowserRoots();
  const auto admission = peer::InspectNativeBrowserShutdown();
  if (!roots || !roots->Revalidate() || !admission.admitted_generation ||
      admission.wrong_process || admission.admission_closed || admission.sequence_uncertain)
    return {};
  const auto id = GetProfileId(profile);
  const auto epoch = GetProfileCookieBindingEpoch(profile);
  if (id.empty() || epoch.empty()) return {};
  return Digest(id + ":" + epoch + ":" + base::NumberToString(admission.admitted_generation));
}
std::string ShortcutRevision(Profile* profile, const std::string& owner) {
  // Dict iteration is key ordered. JSON includes raw stored values, so even an
  // invalid/unknown existing entry changes CAS rather than disappearing in a UI
  // normalized view. The global chord is read for collisions, never mutated.
  base::ListValue canonical;
  canonical.Append(owner);
  canonical.Append(profile->GetPrefs()->GetDict(kOverrides).Clone());
  canonical.Append(g_browser_process->local_state()->GetString(kPopupShortcut));
  auto json = base::WriteJson(canonical);
  return json ? Digest(*json) : std::string();
}
std::optional<std::string> ValidateMappings(const base::DictValue& mappings) {
  if (mappings.size() >= std::size(kBindings)) return "Too many shortcut mappings";
  for (const auto [key, value] : mappings) {
    int command = 0;
    if (!base::StringToInt(key, &command) || base::NumberToString(command) != key ||
        command == kPopup || !FindBinding(command) || !value.is_string() ||
        value.GetString().size() > 96 ||
        (!value.GetString().empty() && !ParseKeyboardShortcut(value.GetString())))
      return "Unknown or invalid shortcut mapping; Mini popup is configured separately";
  }
  return std::nullopt;
}
std::optional<std::string> ValidateProspective(Profile* profile,
                                              const base::DictValue& mappings) {
  if (auto error = ValidateMappings(mappings)) return error;
  if (!NSApp.mainMenu) return "Browser menu reservations are unavailable";
  // The OS returns enabled symbolic hotkeys without acquiring any new grants.
  base::apple::ScopedCFTypeRef<CFArrayRef> hotkeys;
  if (CopySymbolicHotKeys(hotkeys.InitializeInto()) != noErr || !hotkeys)
    return "macOS shortcut reservations are unavailable; no shortcuts changed";
  std::vector<ui::Accelerator> reserved;
  for (CFIndex i = 0; i < CFArrayGetCount(hotkeys.get()); ++i) {
    auto item = static_cast<CFDictionaryRef>(CFArrayGetValueAtIndex(hotkeys.get(), i));
    if (!item || CFGetTypeID(item) != CFDictionaryGetTypeID()) continue;
    const auto* enabled = CFDictionaryGetValue(item, kHISymbolicHotKeyEnabled);
    if (!enabled || CFGetTypeID(enabled) != CFBooleanGetTypeID() ||
        !CFBooleanGetValue(static_cast<CFBooleanRef>(enabled))) continue;
    const auto* code = CFDictionaryGetValue(item, kHISymbolicHotKeyCode);
    const auto* modifiers = CFDictionaryGetValue(item, kHISymbolicHotKeyModifiers);
    int code_value = 0, modifiers_value = 0;
    if (!code || !modifiers || CFGetTypeID(code) != CFNumberGetTypeID() ||
        CFGetTypeID(modifiers) != CFNumberGetTypeID() ||
        !CFNumberGetValue(static_cast<CFNumberRef>(code), kCFNumberIntType, &code_value) ||
        !CFNumberGetValue(static_cast<CFNumberRef>(modifiers), kCFNumberIntType, &modifiers_value))
      return "macOS shortcut reservations could not be read";
    int flags = 0;
    if (modifiers_value & cmdKey) flags |= ui::EF_COMMAND_DOWN;
    if (modifiers_value & controlKey) flags |= ui::EF_CONTROL_DOWN;
    if (modifiers_value & optionKey) flags |= ui::EF_ALT_DOWN;
    if (modifiers_value & shiftKey) flags |= ui::EF_SHIFT_DOWN;
    reserved.emplace_back(ui::KeyboardCodeFromKeyCode(code_value), flags);
  }
  reserved.emplace_back(ui::VKEY_TAB, ui::EF_COMMAND_DOWN);
  reserved.emplace_back(ui::VKEY_TAB, ui::EF_COMMAND_DOWN | ui::EF_SHIFT_DOWN);
  std::vector<std::pair<int, ui::Accelerator>> table;
  for (const auto& binding : kBindings) {
    const auto* mapping = mappings.FindString(base::NumberToString(binding.command));
    const auto value = binding.command == kPopup ? Effective(profile, binding)
                                                : mapping ? *mapping : Default(binding);
    if (value.empty() && binding.command != kPopup) continue;
    auto parsed = ParseKeyboardShortcut(value);
    if (!parsed) return "Existing global shortcut is unavailable";
    for (const auto& [other, accelerator] : table)
      if (*parsed == accelerator)
        return "Shortcut conflict between commands " + base::NumberToString(other) +
               " and " + base::NumberToString(binding.command);
    table.emplace_back(binding.command, *parsed);
    if (binding.command == kPopup) continue;
    // An inherited/current chord may already collide with the user's OS
    // settings. Do not let that unrelated unchanged row veto this edit.
    // Every newly assigned chord, including imports and resets, is checked.
    if (parsed != ParseKeyboardShortcut(Effective(profile, binding)) &&
        std::ranges::find(reserved, *parsed) != reserved.end())
      return "Command " + base::NumberToString(binding.command) + " conflicts with a macOS shortcut";
    // Preserve the supplied command's own intentional default displacement,
    // while comparing all other menu commands against the prospective table.
    if (parsed != ParseKeyboardShortcut(Default(binding)) &&
        MenuConflict(profile, NSApp.mainMenu,
          ui::GetKeyEquivalentAndModifierMaskFromAccelerator(*parsed), binding.command, &mappings))
      return "Command " + base::NumberToString(binding.command) + " conflicts with a browser menu shortcut";
  }
  return std::nullopt;
}

}  // namespace

bool IsNavigationCommand(int command) {
  return std::ranges::find(kNavigationCommands, command,
                          &NavigationCommand::command) != std::end(kNavigationCommands);
}
base::ListValue GetNavigationCommandCatalog(BrowserWindowInterface* browser) {
  base::ListValue result;
  if (!browser) return result;
  for (const auto& command : kNavigationCommands) {
    base::DictValue row;
    row.Set("id", command.id);
    row.Set("commandId", command.command);
    row.Set("title", command.title);
    row.Set("enabled", IsAuxFeatureCommand(command.command)
        ? IsAuxFeatureCommandEnabled(browser, command.command)
        : chrome::IsCommandEnabled(browser, command.command));
    if (const auto* binding = FindBinding(command.command))
      row.Set("shortcut", Effective(browser->GetProfile()->GetOriginalProfile(), *binding));
    result.Append(std::move(row));
  }
  return result;
}
void RegisterKeyboardShortcutPrefs(user_prefs::PrefRegistrySyncable* registry) {
  registry->RegisterDictionaryPref(kOverrides);
}
base::ListValue GetKeyboardShortcuts(Profile* profile) {
  base::ListValue result;
  for (const auto& binding : kBindings) {
    const auto effective = Effective(profile, binding);
    const auto initial = Default(binding);
    base::DictValue row;
    row.Set("commandId", binding.command);
    row.Set("serializedShortcut", effective);
    row.Set("defaultSerializedShortcut", initial);
    const auto effective_key = ParseKeyboardShortcut(effective);
    row.Set("shortcut",
            effective_key ? base::UTF16ToUTF8(effective_key->GetShortcutText())
                          : effective);
    const auto default_key = ParseKeyboardShortcut(initial);
    row.Set("defaultShortcut", default_key
        ? base::UTF16ToUTF8(default_key->GetShortcutText()) : std::string());
    row.Set("isCustomized", effective != initial);
    result.Append(std::move(row));
  }
  return result;
}
base::DictValue GetShortcutProfile(Profile* profile) {
  const auto owner = ShortcutOwner(profile);
  if (owner.empty() || !profile->GetPrefs()->FindPreference(kOverrides))
    return ShortcutFailure("Shortcut profile authority unavailable");
  const auto revision = ShortcutRevision(profile, owner);
  if (revision.empty()) return ShortcutFailure("Shortcut revision unavailable");
  base::ListValue bindings;
  for (auto& row : GetKeyboardShortcuts(profile))
    if (row.GetDict().FindInt("commandId") != kPopup) bindings.Append(std::move(row));
  return base::DictValue().Set("success", true).Set("format", "aux-shortcuts")
      .Set("version", 1).Set("platform", "mac").Set("ownerGeneration", owner)
      .Set("revision", revision).Set("bindings", std::move(bindings));
}
base::DictValue ExportShortcutProfile(Profile* profile) {
  auto current = GetShortcutProfile(profile);
  if (!current.FindBool("success").value_or(false)) return current;
  base::DictValue mappings;
  for (const auto& binding : kBindings) {
    if (binding.command == kPopup) continue;
    mappings.Set(base::NumberToString(binding.command), Effective(profile, binding));
  }
  return base::DictValue().Set("success", true)
      .Set("ownerGeneration", *current.FindString("ownerGeneration"))
      .Set("revision", *current.FindString("revision")).Set("configuration",
      base::DictValue().Set("format", "aux-shortcuts").Set("version", 1)
        .Set("platform", "mac").Set("mappings", std::move(mappings)));
}
base::DictValue ImportShortcutProfile(Profile* profile,
    const std::string& owner_generation, const std::string& revision,
    const base::DictValue& mappings) {
  const auto owner = ShortcutOwner(profile);
  if (owner.empty() || owner != owner_generation ||
      !profile->GetPrefs()->FindPreference(kOverrides))
    return ShortcutFailure("Shortcut profile changed; reopen settings");
  if (revision != ShortcutRevision(profile, owner))
    return ShortcutFailure("Shortcuts changed; review the current table before retrying");
  if (profile->GetPrefs()->IsManagedPreference(kOverrides))
    return ShortcutFailure("Shortcuts are managed");
  if (auto error = ValidateProspective(profile, mappings)) return ShortcutFailure(*error);
  base::DictValue normalized;
  for (const auto [key, value] : mappings) {
    int command = 0;
    base::StringToInt(key, &command);
    if (ParseKeyboardShortcut(value.GetString()) != ParseKeyboardShortcut(Default(*FindBinding(command))))
      normalized.Set(key, value.Clone());
  }
  // All checks precede exactly one profile-local write. No global registration,
  // second counter-pref, sequential per-command mutation or partial import.
  if (ShortcutOwner(profile) != owner || ShortcutRevision(profile, owner) != revision)
    return ShortcutFailure("Shortcut authority changed during validation");
  const auto live_profile = profile->GetWeakPtr();
  profile->GetPrefs()->SetDict(kOverrides, normalized.Clone());
  // Preference/menu observers may synchronously retire or rebind the owner.
  if (!live_profile || ShortcutOwner(live_profile.get()) != owner ||
      live_profile->GetPrefs()->GetDict(kOverrides) != normalized)
    return ShortcutFailure("Shortcut state changed during publication; reload settings");
  RefreshActiveMenu();
  if (!live_profile || ShortcutOwner(live_profile.get()) != owner)
    return ShortcutFailure("Shortcut profile changed during menu refresh");
  auto result = GetShortcutProfile(live_profile.get());
  result.Set("persistence", "native-pref-queued");
  return result;
}
base::DictValue ResetShortcutProfile(Profile* profile,
    const std::string& owner_generation, const std::string& revision) {
  return ImportShortcutProfile(profile, owner_generation, revision, base::DictValue());
}

std::optional<std::string> SetKeyboardShortcut(Profile* profile,
                                               int command,
                                               const std::string& value) {
  const auto* binding = FindBinding(command);
  const auto parsed = ParseKeyboardShortcut(value);
  if (!binding || (!parsed && (!value.empty() || command == kPopup)))
    return "Shortcut is not valid";
  for (const auto& other : kBindings) {
    if (parsed && other.command != command &&
        ParseKeyboardShortcut(Effective(profile, other)) == parsed)
      return "This shortcut is already in use. Choose a different shortcut.";
  }
  // Allow a command's own supplied default even when it replaces a Chromium
  // menu default (notably Toggle Sidebar / Save Page). Reject other menu
  // clashes.
  if (parsed && parsed != ParseKeyboardShortcut(Default(*binding)) &&
      MenuConflict(profile, NSApp.mainMenu,
                   ui::GetKeyEquivalentAndModifierMaskFromAccelerator(*parsed),
                   command))
    return "This shortcut is already used by a browser menu command.";
  if (command == kPopup) {
    auto error = extensions::SetAuxMiniPopupShortcut(profile, value);
    if (!error) RefreshActiveMenu();
    return error;
  }
  // Single-row edits use the SAME prospective-table/OS reservation and
  // profile-CAS boundary as import. Never publish a chord the bulk editor would
  // reject, nor silently repair unknown persisted entries during one-row edit.
  const auto owner = ShortcutOwner(profile);
  if (owner.empty() || !profile->GetPrefs()->FindPreference(kOverrides))
    return "Shortcut profile authority unavailable";
  const auto revision = ShortcutRevision(profile, owner);
  if (revision.empty())
    return "Shortcut revision unavailable";
  auto mappings = profile->GetPrefs()->GetDict(kOverrides).Clone();
  mappings.Set(base::NumberToString(command), value);
  auto result = ImportShortcutProfile(profile, owner, revision, mappings);
  if (!result.FindBool("success").value_or(false)) {
    const auto* error = result.FindString("error");
    return error ? *error : "Shortcuts were not changed";
  }
  return std::nullopt;
}
std::optional<std::string> ResetKeyboardShortcut(Profile* profile,
                                                 int command) {
  const auto* binding = FindBinding(command);
  if (!binding)
    return "Unknown shortcut command";
  // Import's normalization removes a default override in its one write.
  return SetKeyboardShortcut(profile, command, Default(*binding));
}
void SetShortcutCapture(content::WebContents* sender, bool suspended) {
  auto* capture = static_cast<Capture*>(sender->GetUserData(&kCaptureKey));
  if (!capture) {
    auto owned = std::make_unique<Capture>(sender);
    capture = owned.get();
    sender->SetUserData(&kCaptureKey, std::move(owned));
  }
  capture->Set(suspended);
}
// Chords the browser keeps before the page: the commands Chromium reserves
// and anything with Control+Command or Option+Command, which web apps don't
// use. Everything else (Command+K, Command+E, Command+Left…) reaches the page
// or text field first and runs only if it goes unhandled.
bool IsBrowserFirst(int command, const ui::Accelerator& chord) {
  switch (command) {
    case IDC_NEW_TAB:
    case IDC_CLOSE_TAB:
    case IDC_RESTORE_TAB:
    case IDC_FOCUS_LOCATION:
      return true;
  }
  const int modifiers = chord.modifiers();
  return (modifiers & ui::EF_COMMAND_DOWN) &&
         (modifiers & (ui::EF_CONTROL_DOWN | ui::EF_ALT_DOWN));
}
std::optional<int> ResolveKeyboardShortcut(NSEvent* event, NSWindow* window,
                                           bool before_page) {
  if (event.type != NSEventTypeKeyDown)
    return std::nullopt;
  if (before_page) {
    for (auto* capture : Captures()) {
      if (capture->web_contents() &&
          capture->web_contents()->GetTopLevelNativeWindow() ==
              gfx::NativeWindow(window))
        return 0;
    }
  }
  auto* browser = GlobalBrowserCollection::GetInstance()->FindBrowserWithWindow(
      gfx::NativeWindow(window));
  if (!browser)
    return std::nullopt;
  auto* profile = browser->GetProfile()->GetOriginalProfile();
  int flags = 0;
  if (event.modifierFlags & NSEventModifierFlagCommand)
    flags |= ui::EF_COMMAND_DOWN;
  if (event.modifierFlags & NSEventModifierFlagControl)
    flags |= ui::EF_CONTROL_DOWN;
  if (event.modifierFlags & NSEventModifierFlagOption)
    flags |= ui::EF_ALT_DOWN;
  if (event.modifierFlags & NSEventModifierFlagShift)
    flags |= ui::EF_SHIFT_DOWN;
  const ui::Accelerator pressed(ui::KeyboardCodeFromKeyCode(event.keyCode),
                                flags);
  for (const auto& binding : kBindings) {
    if (binding.command != kPopup &&
        ParseKeyboardShortcut(Effective(profile, binding)) == pressed) {
      if (IsBrowserFirst(binding.command, pressed) == before_page)
        return binding.command;
      return std::nullopt;
    }
  }
  // Once customized, the old chord must not leak through to Chromium's
  // static accelerator table. Effective bindings above win any reassignment.
  if (before_page) {
    for (const auto& binding : kBindings) {
      if (binding.command != kPopup &&
          ParseKeyboardShortcut(Default(binding)) == pressed &&
          Effective(profile, binding) != Default(binding))
        return 0;
    }
  }
  return std::nullopt;
}
bool IsKeyboardShortcutCommandForWindow(int command, NSWindow* window) {
  return command != kPopup && FindBinding(command) &&
         GlobalBrowserCollection::GetInstance()->FindBrowserWithWindow(
             gfx::NativeWindow(window));
}
bool GetKeyboardShortcut(Profile* profile, int command, ui::Accelerator* accelerator) {
  const auto* binding = FindBinding(command);
  if (!binding) return false;
  const auto parsed = ParseKeyboardShortcut(Effective(profile->GetOriginalProfile(), *binding));
  if (!parsed) return false;
  *accelerator = *parsed;
  return true;
}
void RefreshKeyboardShortcutMenu(Profile* profile) {
  UpdateMenu(profile->GetOriginalProfile(), NSApp.mainMenu);
}
void UpdateKeyboardShortcutMenuItem(NSMenuItem* item, NSWindow* window) {
  auto* browser = GlobalBrowserCollection::GetInstance()->FindBrowserWithWindow(
      gfx::NativeWindow(window));
  if (browser) UpdateMenuItem(browser->GetProfile()->GetOriginalProfile(), item);
}
}  // namespace aux
