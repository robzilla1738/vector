// Copyright 2026 The Aux Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef CHROME_BROWSER_UI_AUX_NTP_URL_H_
#define CHROME_BROWSER_UI_AUX_NTP_URL_H_

#include <string_view>

#include "extensions/common/constants.h"
#include "url/gurl.h"

// True for the Aux agent manager's new tab page. Chats and settings share
// newtab.html but carry a route in the hash; the new tab page has none, or only
// the account prefix (#/u/0).
inline bool IsAuxNtpUrl(const GURL& url) {
  if (!url.SchemeIs(extensions::kExtensionScheme) ||
      url.host() != "gokkffaiccpmoeodpmeamcjajcagjmkm" ||
      url.path() != "/newtab.html") {
    return false;
  }
  const std::string_view ref = url.ref();
  return ref.empty() || ref == "/" ||
         (ref.starts_with("/u/") && ref.find('/', 3) == std::string_view::npos);
}

#endif  // CHROME_BROWSER_UI_AUX_NTP_URL_H_
