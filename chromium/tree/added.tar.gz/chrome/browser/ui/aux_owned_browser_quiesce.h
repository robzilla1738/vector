// Copyright 2026 The Aux Authors
#ifndef CHROME_BROWSER_UI_AUX_OWNED_BROWSER_QUIESCE_H_
#define CHROME_BROWSER_UI_AUX_OWNED_BROWSER_QUIESCE_H_

#include <optional>

#include "base/functional/callback.h"
#include "content/public/browser/aux_child_process_drain.h"
#include "chrome/browser/aux/feature_store/feature_write_participant.h"
#include "chrome/browser/aux/owned_direct_helper_quiesce.h"
#include "chrome/browser/profiles/aux_async_profile_creation_admission.h"
#include "chrome/browser/ui/aux_session_writer_participant.h"
#include "content/public/browser/aux_renderer_navigation_admission.h"
#include "content/public/browser/aux_service_worker_migration.h"
#include "extensions/browser/service_worker/service_worker_task_queue.h"

namespace aux {

// Raw observations of these native participants, never whole-profile custody.
struct OwnedBrowserQuiesceObservation {
  bool close_requested = false;
  bool process_shutdown = false;
  content::aux_migration::ChildProcessDrainSnapshot content_children;
  content::aux_migration::ChildProcessDrainSnapshot native_messaging;
  bool participant_submission_pending = false;
  bool profile_manager_unavailable = false;
  bool helper_observation_pending = false;
  bool session_observation_pending = false;
  bool feature_observation_pending = false;
  features::NativeFeatureWriteObservation feature_writes;
  AsyncProfileCreationAdmissionSnapshot async_profile_creation;
  extensions::ServiceWorkerTaskQueue::ProcessStartAdmissionSnapshot
      extension_worker_starts;
  content::aux_migration::RendererNavigationAdmissionSnapshot renderer_navigation{};
  content::aux_migration::ServiceWorkerMigrationSnapshot service_workers{};
  std::optional<OwnedDirectHelperQuiesceObservation> helpers;
  std::optional<SessionWriterParticipantObservation> sessions;
};

// UI sequence only. Closes actual process admission before starting async work.
// A returned observation may contain unresolved, failed or still-running work.
// No timeout, reopening, migration grant or ordinary-shutdown hook is provided.
void CloseOwnedBrowserParticipantsForMigration(
    base::OnceCallback<void(OwnedBrowserQuiesceObservation)> done);
OwnedBrowserQuiesceObservation InspectOwnedBrowserParticipantQuiesce();
struct BrowserParticipantDrainResult {
  bool close_requested = false;
  bool process_shutdown = false;
  bool pending = true;
  bool unknown = false;
};
// Only process shutdown may use this irreversible close. A normal window close
// or profile switch must never call it. The selected daemon peer is retained
// separately until its authenticated final browser receipt has been consumed.
void CloseOwnedBrowserParticipantsForShutdown(
    base::OnceCallback<void(OwnedBrowserQuiesceObservation)> done);
BrowserParticipantDrainResult EvaluateOwnedBrowserParticipantDrain(
    const OwnedBrowserQuiesceObservation& observation);

}  // namespace aux
#endif  // CHROME_BROWSER_UI_AUX_OWNED_BROWSER_QUIESCE_H_
