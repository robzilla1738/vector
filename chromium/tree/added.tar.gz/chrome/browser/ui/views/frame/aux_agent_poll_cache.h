// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#ifndef CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_POLL_CACHE_H_
#define CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_POLL_CACHE_H_

#include <memory>
#include <optional>
#include <string>
#include <utility>

#include "base/supports_user_data.h"
#include "base/time/time.h"
#include "chrome/browser/profiles/profile.h"

namespace aux {
// One daemon answer per profile: every window polls on its own timer, and
// whichever asks first in an interval fetches for the rest.
class AgentPollCache final : public base::SupportsUserData::Data {
 public:
  static std::optional<std::string> Recent(Profile& profile, const char* key, int account,
                                           base::TimeDelta max_age) {
    const auto* cache = static_cast<AgentPollCache*>(profile.GetUserData(key));
    if (!cache || cache->account_ != account ||
        base::TimeTicks::Now() - cache->fetched_ >= max_age)
      return std::nullopt;
    return cache->body_;
  }
  static void Store(Profile& profile, const char* key, int account, std::string body) {
    auto cache = std::make_unique<AgentPollCache>();
    cache->account_ = account;
    cache->fetched_ = base::TimeTicks::Now();
    cache->body_ = std::move(body);
    profile.SetUserData(key, std::move(cache));
  }

 private:
  int account_ = -1;
  base::TimeTicks fetched_;
  std::string body_;
};
}  // namespace aux

#endif  // CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_POLL_CACHE_H_
