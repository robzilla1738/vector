// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/ui/views/frame/aux_agent_row.h"

#include <memory>
#include <utility>

#include "base/functional/bind.h"
#include "cc/paint/paint_flags.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/views/frame/aux_agent_identity.h"
#include "chrome/browser/ui/views/location_bar/aux_agent_button.h"
#include "third_party/skia/include/core/SkPath.h"
#include "ui/base/metadata/metadata_impl_macros.h"
#include "ui/color/color_id.h"
#include "ui/color/color_provider_key.h"
#include "ui/gfx/canvas.h"
#include "ui/gfx/geometry/rrect_f.h"
#include "ui/views/accessibility/view_accessibility.h"
#include "ui/views/animation/ink_drop.h"
#include "ui/views/border.h"
#include "ui/views/controls/focus_ring.h"
#include "ui/views/controls/highlight_path_generator.h"
#include "ui/views/controls/label.h"
#include "ui/views/layout/flex_layout.h"
#include "ui/views/view_class_properties.h"
#include "ui/views/widget/widget.h"

namespace aux {
namespace {
constexpr int kHeight = 40;
constexpr int kAvatarSize = 22;
constexpr float kRadius = 10;
}  // namespace

AuxAgentRow::AuxAgentRow(BrowserWindowInterface& browser)
    : views::Button(base::BindRepeating(
          [](base::WeakPtr<BrowserWindowInterface> browser) { OpenAgent(browser.get()); },
          browser.GetWeakPtr())) {
  views::InkDrop::Get(this)->SetMode(views::InkDropHost::InkDropMode::OFF);
  SetAnimateOnStateChange(false);
  views::InstallRoundRectHighlightPathGenerator(this, gfx::Insets(), kRadius);
  SetBorder(views::CreateEmptyBorder(gfx::Insets::VH(0, 9)));
  SetLayoutManager(std::make_unique<views::FlexLayout>())
      ->SetOrientation(views::LayoutOrientation::kHorizontal)
      .SetCrossAxisAlignment(views::LayoutAlignment::kCenter);

  // The face is part of the row: the row takes the clicks and the focus.
  // The mark matches the name: primary text, never the dimmed omnibox gray.
  face_ = AddChildView(std::make_unique<AuxAgentButton>(PressedCallback(), kAvatarSize,
                                                        ui::kColorLabelForeground));
  face_->SetCanProcessEventsWithinSubtree(false);
  face_->SetFocusBehavior(FocusBehavior::NEVER);
  face_->GetViewAccessibility().SetIsIgnored(true);
  face_->SetPreferredSize(gfx::Size(kAvatarSize + 6, kAvatarSize + 6));

  name_ = AddChildView(std::make_unique<views::Label>());
  name_->SetCanProcessEventsWithinSubtree(false);
  name_->SetAutoColorReadabilityEnabled(false);
  name_->SetBackgroundColor(SK_ColorTRANSPARENT);
  name_->SetHorizontalAlignment(gfx::ALIGN_LEFT);
  name_->SetElideBehavior(gfx::FADE_TAIL);
  const auto font = name_->font_list();
  name_->SetFontList(font.Derive(2, font.GetFontStyle(), gfx::Font::Weight::MEDIUM));
  name_->SetProperty(views::kMarginsKey, gfx::Insets::TLBR(0, 8, 0, 0));
  name_->SetProperty(views::kFlexBehaviorKey,
      views::FlexSpecification(views::MinimumFlexSizeRule::kScaleToZero,
                               views::MaximumFlexSizeRule::kUnbounded));
  IdentityChanged();
}

AuxAgentRow::~AuxAgentRow() = default;

void AuxAgentRow::SetCompact(bool compact) {
  if (compact_ == compact) return;
  compact_ = compact;
  name_->SetVisible(!compact);
  static_cast<views::FlexLayout*>(GetLayoutManager())->SetMainAxisAlignment(
      compact ? views::LayoutAlignment::kCenter : views::LayoutAlignment::kStart);
  InvalidateLayout();
}

void AuxAgentRow::AddedToWidget() {
  views::Button::AddedToWidget();
  if (auto* identity = AuxAgentIdentity::FromView(this))
    subscription_ = identity->RegisterChanged(
        base::BindRepeating(&AuxAgentRow::IdentityChanged, base::Unretained(this)));
  IdentityChanged();
}

void AuxAgentRow::RemovedFromWidget() {
  subscription_ = {};
  views::Button::RemovedFromWidget();
}

void AuxAgentRow::IdentityChanged() {
  const auto* identity = AuxAgentIdentity::FromView(this);
  if (identity) {
    if (IsDrawn()) {
      const auto text = AgentStatusAnnouncement(announced_, identity->identity());
      if (!text.empty()) GetViewAccessibility().AnnounceText(text);
    }
    announced_ = identity->identity().status;
  }
  name_->SetText(identity ? identity->identity().name : AgentIdentity().name);
  const auto ask = AskAgentText(identity);
  SetTooltipText(ask);
  GetViewAccessibility().SetName(ask);
  SchedulePaint();
}

bool AuxAgentRow::Dark() const {
  return GetWidget() && GetWidget()->GetColorMode() == ui::ColorProviderKey::ColorMode::kDark;
}

void AuxAgentRow::OnThemeChanged() {
  views::Button::OnThemeChanged();
  // Same primary sidebar text as the tab rows, a step stronger than New Tab.
  name_->SetEnabledColor(Dark() ? 0xebfafafa : 0xeb0a0a0a);
  SchedulePaint();
}

void AuxAgentRow::StateChanged(ButtonState old_state) {
  views::Button::StateChanged(old_state);
  SchedulePaint();
}

void AuxAgentRow::PaintButtonContents(gfx::Canvas* canvas) {
  // A soft card at rest, a touch stronger under the pointer: present, never loud.
  const bool active = GetState() == STATE_HOVERED || GetState() == STATE_PRESSED;
  cc::PaintFlags flags;
  flags.setAntiAlias(true);
  flags.setColor(Dark() ? (active ? 0x1ffafafa : 0x0ffafafa)
                        : (active ? 0x140a0a0a : 0x0a0a0a0a));
  canvas->DrawPath(SkPath::RRect(SkRRect{gfx::RRectF(gfx::RectF(GetLocalBounds()), kRadius)}),
                   flags);
  views::Button::PaintButtonContents(canvas);
}

gfx::Size AuxAgentRow::CalculatePreferredSize(const views::SizeBounds& available_size) const {
  auto size = views::Button::CalculatePreferredSize(available_size);
  size.set_height(kHeight);
  return size;
}

BEGIN_METADATA(AuxAgentRow)
END_METADATA
}  // namespace aux
