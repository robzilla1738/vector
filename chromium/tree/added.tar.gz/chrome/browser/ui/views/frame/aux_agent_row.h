// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#ifndef CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_ROW_H_
#define CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_ROW_H_

#include "base/callback_list.h"
#include "base/memory/raw_ptr.h"
#include "chrome/browser/ui/views/frame/aux_chats_model.h"
#include "ui/base/metadata/metadata_header_macros.h"
#include "ui/views/controls/button/button.h"

class BrowserWindowInterface;
namespace views { class Label; }

namespace aux {
class AuxAgentButton;

// The Agent at the top of the sidebar, right under the address field: its
// face (picture or Aux mark, with the working ring and waiting dots) and its
// name on a soft card. Clicking it opens the Agent's side panel.
class AuxAgentRow final : public views::Button {
  METADATA_HEADER(AuxAgentRow, views::Button)

 public:
  explicit AuxAgentRow(BrowserWindowInterface& browser);
  AuxAgentRow(const AuxAgentRow&) = delete;
  AuxAgentRow& operator=(const AuxAgentRow&) = delete;
  ~AuxAgentRow() override;

  // Narrow sidebar: the face alone, centered.
  void SetCompact(bool compact);

 protected:
  // views::Button:
  void AddedToWidget() override;
  void RemovedFromWidget() override;
  void OnThemeChanged() override;
  void StateChanged(ButtonState old_state) override;
  void PaintButtonContents(gfx::Canvas* canvas) override;
  gfx::Size CalculatePreferredSize(const views::SizeBounds& available_size) const override;

 private:
  void IdentityChanged();
  bool Dark() const;

  ChatStatus announced_ = ChatStatus::kIdle;
  raw_ptr<AuxAgentButton> face_ = nullptr;
  raw_ptr<views::Label> name_ = nullptr;
  bool compact_ = false;
  base::CallbackListSubscription subscription_;
};
}  // namespace aux

#endif  // CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_ROW_H_
