// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#ifndef CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_IDENTITY_H_
#define CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_IDENTITY_H_

#include <memory>
#include <optional>
#include <string>

#include "base/callback_list.h"
#include "base/memory/weak_ptr.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "chrome/browser/ui/views/frame/aux_chats_model.h"
#include "ui/base/models/image_model.h"
#include "ui/color/color_id.h"
#include "ui/gfx/image/image_skia.h"

class BrowserWindowInterface;
class Profile;
class SkBitmap;
namespace gfx { class Canvas; class RectF; }
namespace views { class View; }

namespace aux {
class AuxChatsTransport;

// One window's view of the account's Agent: name, home-thread state and the
// decoded avatar. The window's Chats transport feeds it from the poll it
// already makes; while no feed arrives (no sidebar body, as with horizontal
// tabs) it runs a transport of its own, so the toolbar always shows the Agent.
class AuxAgentIdentity {
 public:
  explicit AuxAgentIdentity(BrowserWindowInterface& browser);
  ~AuxAgentIdentity();
  AuxAgentIdentity(const AuxAgentIdentity&) = delete;
  AuxAgentIdentity& operator=(const AuxAgentIdentity&) = delete;

  static AuxAgentIdentity* FromBrowser(BrowserWindowInterface* browser);
  // The identity of the window toolbar that hosts `view`.
  static AuxAgentIdentity* FromView(const views::View* view);

  const AgentIdentity& identity() const { return identity_; }
  // Empty until a custom avatar is decoded; the Aux mark stands in.
  const gfx::ImageSkia& avatar() const { return avatar_; }

  // Safe to outlive this object: the toolbar's child views subscribe, and
  // they are destroyed after the toolbar's members.
  base::CallbackListSubscription RegisterChanged(base::RepeatingClosure changed) {
    return changed_.Add(std::move(changed));
  }

  // A Chats poll for `account` reported `next`.
  void Update(AuxChatsTransport& source, int account, AgentIdentity next);

 private:
  void CheckFeed();
  void Reset();
  void FetchAvatar(AuxChatsTransport& source);
  void AvatarLoaded(uint64_t generation, std::optional<std::string> png);
  void AvatarDecoded(uint64_t generation, const SkBitmap& bitmap);
  void Notify();

  base::WeakPtr<BrowserWindowInterface> browser_;
  base::WeakPtr<Profile> profile_;
  std::optional<int> account_;
  AgentIdentity identity_;
  gfx::ImageSkia avatar_;
  // Bumped whenever the wanted avatar changes; stale fetches and decodes drop.
  uint64_t avatar_generation_ = 0;
  bool avatar_wanted_ = false;
  base::TimeTicks next_avatar_attempt_;
  // Whether a feed reported since the last check: the window's, or our own.
  bool fed_ = false;
  bool own_fed_ = false;
  std::unique_ptr<AuxChatsTransport> own_feed_;
  base::RepeatingTimer feed_check_;
  base::RepeatingClosureList changed_;
  base::WeakPtrFactory<AuxAgentIdentity> weak_{this};
};

// Otto, the Agent's default face: a silver pebble with two pill eyes, filling
// the square `bounds`.
void PaintOtto(gfx::Canvas* canvas, const gfx::RectF& bounds);
// The Agent's picture as a circle of `size`, or Otto while there is none.
ui::ImageModel AgentIcon(const AuxAgentIdentity* identity, int size);
// Opens the Agent's side panel in `browser`, as its toolbar action does.
void OpenAgent(BrowserWindowInterface* browser);
// "Ask <name>".
std::u16string AskAgentText(const AuxAgentIdentity* identity);
// What a screen reader hears when the Agent moves from `previous` into its
// current state; empty when nothing changed worth saying.
std::u16string AgentStatusAnnouncement(ChatStatus previous, const AgentIdentity& identity);
}  // namespace aux

#endif  // CHROME_BROWSER_UI_VIEWS_FRAME_AUX_AGENT_IDENTITY_H_
