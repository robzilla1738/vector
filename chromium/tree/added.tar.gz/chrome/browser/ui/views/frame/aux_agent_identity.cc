// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/ui/views/frame/aux_agent_identity.h"

#include <limits>
#include <utility>

#include "base/containers/span.h"
#include "base/functional/bind.h"
#include "base/functional/callback_helpers.h"
#include "chrome/browser/aux/browser_platform.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/profiles/profile_avatar_icon_util.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/ui/color/chrome_color_id.h"
#include "chrome/browser/aux/component_bootstrap.h"
#include "chrome/browser/ui/toolbar/toolbar_action_view_model.h"
#include "chrome/browser/ui/views/extensions/extensions_toolbar_desktop.h"
#include "chrome/browser/ui/views/frame/aux_chats_transport.h"
#include "chrome/browser/ui/views/frame/browser_view.h"
#include "chrome/browser/ui/views/toolbar/toolbar_action_view.h"
#include "chrome/browser/ui/views/toolbar/toolbar_view.h"
#include "chrome/grit/generated_resources.h"
#include "services/data_decoder/public/cpp/decode_image.h"
#include "third_party/skia/include/core/SkBitmap.h"
#include "ui/base/l10n/l10n_util.h"
#include "ui/gfx/image/image.h"
#include "ui/gfx/canvas.h"
#include "ui/gfx/paint_vector_icon.h"
#include "ui/gfx/vector_icon_types.h"
#include "ui/views/view_utils.h"

namespace aux {
namespace {
#include "chrome/browser/ui/tabs/aux_new_tab_mark.inc"

constexpr auto kFeedCheckInterval = base::Seconds(3);
constexpr auto kAvatarRetryDelay = base::Seconds(10);
// The daemon serves a 256px square; anything larger is shrunk while decoding.
constexpr uint64_t kAvatarMaxDecodedBytes = 4 * 512 * 512;
}  // namespace

AuxAgentIdentity::AuxAgentIdentity(BrowserWindowInterface& browser)
    : browser_(browser.GetWeakPtr()) {
  if (auto* profile = browser.GetProfile()) profile_ = profile->GetWeakPtr();
  feed_check_.Start(FROM_HERE, kFeedCheckInterval, this, &AuxAgentIdentity::CheckFeed);
  daemon_state_ = BrowserPlatform::Get().ObserveDaemonState(
      base::BindRepeating(&AuxAgentIdentity::Notify, base::Unretained(this)));
}

AuxAgentIdentity::~AuxAgentIdentity() = default;

AuxAgentIdentity* AuxAgentIdentity::FromBrowser(BrowserWindowInterface* browser) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  auto* toolbar = view ? view->toolbar() : nullptr;
  return toolbar ? toolbar->aux_agent_identity() : nullptr;
}

AuxAgentIdentity* AuxAgentIdentity::FromView(const views::View* view) {
  for (const views::View* v = view; v; v = v->parent()) {
    if (const auto* toolbar = views::AsViewClass<ToolbarView>(v))
      return const_cast<ToolbarView*>(toolbar)->aux_agent_identity();
    // The sidebar is not under the toolbar; its window's toolbar owns the identity.
    if (const auto* browser = views::AsViewClass<BrowserView>(v))
      return const_cast<BrowserView*>(browser)->toolbar()->aux_agent_identity();
  }
  return nullptr;
}

void OpenAgent(BrowserWindowInterface* browser) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  auto* extensions = view && view->toolbar() ? view->toolbar()->extensions_container() : nullptr;
  if (auto* action = extensions ? extensions->GetViewForId(kAgentExtensionId) : nullptr)
    action->view_model()->ExecuteUserAction(
        ToolbarActionViewModel::InvocationSource::kToolbarButton);
}

void AuxAgentIdentity::SetReachable(bool reachable) {
  if (reachable_ == reachable) return;
  reachable_ = reachable;
  Notify();
}

bool AuxAgentIdentity::starting() const {
  switch (BrowserPlatform::Get().daemon_state()) {
    case DaemonSupervisor::State::kStopped:
    case DaemonSupervisor::State::kStarting:
    case DaemonSupervisor::State::kAuthenticating:
      return true;
    default:
      return false;
  }
}

bool AuxAgentIdentity::failed() const {
  return BrowserPlatform::Get().daemon_state() == DaemonSupervisor::State::kFailed;
}

void AuxAgentIdentity::TryAgain() {
  BrowserPlatform::Get().RetryDaemon();
}

void AuxAgentIdentity::Stop() {
  if (source_)
    source_->PerformBulkAction(AuxChatsTransport::BulkAction::kStopAll, base::DoNothing());
}

void AuxAgentIdentity::Update(AuxChatsTransport& source, int account, AgentIdentity next) {
  SetReachable(true);
  source_ = source.GetWeakPtr();
  if (&source == own_feed_.get()) {
    own_fed_ = true;
  } else {
    fed_ = true;
    own_feed_.reset();
  }
  Profile* profile = browser_ ? browser_->GetProfile() : nullptr;
  if (profile != profile_.get()) {
    profile_ = profile ? profile->GetWeakPtr() : nullptr;
    Reset();
  }
  const bool account_changed = account_ != account;
  const bool avatar_changed = account_changed || next.avatar_revision != identity_.avatar_revision;
  if (!avatar_changed && next == identity_) {
    if (avatar_wanted_ && base::TimeTicks::Now() >= next_avatar_attempt_) FetchAvatar(source);
    return;
  }
  account_ = account;
  identity_ = std::move(next);
  if (avatar_changed) {
    ++avatar_generation_;
    avatar_wanted_ = !identity_.avatar_revision.empty();
    // Keep showing the previous picture until its replacement decodes.
    if (account_changed || !avatar_wanted_) avatar_ = gfx::ImageSkia();
    if (avatar_wanted_) FetchAvatar(source);
  }
  Notify();
}

void AuxAgentIdentity::CheckFeed() {
  Profile* profile = browser_ ? browser_->GetProfile() : nullptr;
  if (profile != profile_.get()) {
    profile_ = profile ? profile->GetWeakPtr() : nullptr;
    own_feed_.reset();
    Reset();
  }
  if (std::exchange(fed_, false) || !profile_ || profile_->IsOffTheRecord()) return;
  // A quiet transport of our own (daemon restarting, Agent reinstalled) is
  // replaced; Start is a no-op while the Agent is not installed.
  if (own_feed_ && std::exchange(own_fed_, false)) return;
  own_feed_ = std::make_unique<AuxChatsTransport>(*browser_, base::DoNothing());
  own_feed_->Start();
}

void AuxAgentIdentity::Reset() {
  account_.reset();
  identity_ = AgentIdentity();
  avatar_ = gfx::ImageSkia();
  avatar_wanted_ = false;
  ++avatar_generation_;
  Notify();
}

void AuxAgentIdentity::FetchAvatar(AuxChatsTransport& source) {
  next_avatar_attempt_ = base::TimeTicks::Now() + kAvatarRetryDelay;
  source.FetchAgentAvatar(*account_, base::BindOnce(&AuxAgentIdentity::AvatarLoaded,
                                                    weak_.GetWeakPtr(), avatar_generation_));
}

void AuxAgentIdentity::AvatarLoaded(uint64_t generation, std::optional<std::string> png) {
  if (generation != avatar_generation_ || !png || png->empty()) return;
  // Decoded in the sandboxed data decoder, never in the browser process.
  data_decoder::DecodeImageIsolated(base::as_byte_span(*png),
      data_decoder::mojom::ImageCodec::kDefault, /*shrink_to_fit=*/true,
      kAvatarMaxDecodedBytes, gfx::Size(),
      base::BindOnce(&AuxAgentIdentity::AvatarDecoded, weak_.GetWeakPtr(), generation));
}

void AuxAgentIdentity::AvatarDecoded(uint64_t generation, const SkBitmap& bitmap) {
  if (generation != avatar_generation_ || bitmap.drawsNothing()) return;
  avatar_ = gfx::ImageSkia::CreateFrom1xBitmap(bitmap);
  next_avatar_attempt_ = base::TimeTicks::Max();
  Notify();
}

void AuxAgentIdentity::Notify() {
  changed_.Notify();
}

void PaintAgentMark(gfx::Canvas* canvas, const gfx::Point& origin, int size, SkColor color) {
  canvas->Save();
  canvas->Translate(origin.OffsetFromOrigin());
  gfx::PaintVectorIcon(canvas, kAuxNewTabMarkIcon, size, color);
  canvas->Restore();
}

ui::ImageModel AgentIcon(const AuxAgentIdentity* identity, int size) {
  if (!identity || identity->avatar().isNull())
    return ui::ImageModel::FromVectorIcon(kAuxNewTabMarkIcon, kColorToolbarButtonIcon, size);
  return ui::ImageModel::FromImage(profiles::GetSizedAvatarIcon(
      gfx::Image(identity->avatar()), size, size, profiles::SHAPE_CIRCLE));
}

std::u16string AskAgentText(const AuxAgentIdentity* identity) {
  const auto name = identity ? identity->identity().name : AgentIdentity().name;
  if (!identity) return l10n_util::GetStringFUTF16(IDS_AUX_ASK_AGENT, name);
  return l10n_util::GetStringFUTF16(identity->failed()     ? IDS_AUX_AGENT_FAILED
                                    : identity->starting() ? IDS_AUX_AGENT_STARTING
                                    : identity->reachable() ? IDS_AUX_ASK_AGENT
                                                            : IDS_AUX_AGENT_UNREACHABLE,
                                    name);
}

std::u16string AgentStatusAnnouncement(ChatStatus previous, const AgentIdentity& identity) {
  if (identity.status == previous) return {};
  switch (identity.status) {
    case ChatStatus::kRunning:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_WORKING, identity.name);
    case ChatStatus::kAwaitingApproval:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_NEEDS_APPROVAL, identity.name);
    case ChatStatus::kAwaitingAnswer:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_HAS_QUESTION, identity.name);
    case ChatStatus::kFinishedUnread:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_REPLIED, identity.name);
    default:
      return {};
  }
}
}  // namespace aux
