// Copyright 2026 Aux Authors. BSD-style license: see //LICENSE.
#include "chrome/browser/ui/views/frame/aux_agent_identity.h"

#include <limits>
#include <utility>

#include "base/containers/span.h"
#include "base/functional/bind.h"
#include "base/functional/callback_helpers.h"
#include "chrome/browser/profiles/profile.h"
#include "chrome/browser/profiles/profile_avatar_icon_util.h"
#include "chrome/browser/ui/browser_window/public/browser_window_interface.h"
#include "chrome/browser/aux/component_bootstrap.h"
#include "chrome/browser/ui/toolbar/toolbar_action_view_model.h"
#include "chrome/browser/ui/views/extensions/extensions_toolbar_desktop.h"
#include "chrome/browser/ui/views/frame/aux_chats_transport.h"
#include "chrome/browser/ui/views/frame/browser_view.h"
#include "chrome/browser/ui/views/toolbar/toolbar_action_view.h"
#include "chrome/browser/ui/views/toolbar/toolbar_view.h"
#include "chrome/grit/generated_resources.h"
#include "services/data_decoder/public/cpp/decode_image.h"
#include "third_party/skia/include/core/SkBitmap.h"
#include "ui/base/l10n/l10n_util.h"
#include "ui/gfx/image/image.h"
#include "cc/paint/paint_flags.h"
#include "cc/paint/paint_shader.h"
#include "third_party/skia/include/core/SkPath.h"
#include "ui/gfx/canvas.h"
#include "ui/gfx/geometry/skia_conversions.h"
#include "ui/gfx/image/canvas_image_source.h"
#include "ui/views/view_utils.h"

namespace aux {
namespace {
constexpr auto kFeedCheckInterval = base::Seconds(3);
constexpr auto kAvatarRetryDelay = base::Seconds(10);
// The daemon serves a 256px square; anything larger is shrunk while decoding.
constexpr uint64_t kAvatarMaxDecodedBytes = 4 * 512 * 512;
}  // namespace

AuxAgentIdentity::AuxAgentIdentity(BrowserWindowInterface& browser)
    : browser_(browser.GetWeakPtr()) {
  if (auto* profile = browser.GetProfile()) profile_ = profile->GetWeakPtr();
  feed_check_.Start(FROM_HERE, kFeedCheckInterval, this, &AuxAgentIdentity::CheckFeed);
}

AuxAgentIdentity::~AuxAgentIdentity() = default;

AuxAgentIdentity* AuxAgentIdentity::FromBrowser(BrowserWindowInterface* browser) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  auto* toolbar = view ? view->toolbar() : nullptr;
  return toolbar ? toolbar->aux_agent_identity() : nullptr;
}

AuxAgentIdentity* AuxAgentIdentity::FromView(const views::View* view) {
  for (const views::View* v = view; v; v = v->parent()) {
    if (const auto* toolbar = views::AsViewClass<ToolbarView>(v))
      return const_cast<ToolbarView*>(toolbar)->aux_agent_identity();
    // The sidebar is not under the toolbar; its window's toolbar owns the identity.
    if (const auto* browser = views::AsViewClass<BrowserView>(v))
      return const_cast<BrowserView*>(browser)->toolbar()->aux_agent_identity();
  }
  return nullptr;
}

void OpenAgent(BrowserWindowInterface* browser) {
  auto* view = browser ? BrowserView::GetBrowserViewForBrowser(browser) : nullptr;
  auto* extensions = view && view->toolbar() ? view->toolbar()->extensions_container() : nullptr;
  if (auto* action = extensions ? extensions->GetViewForId(kAgentExtensionId) : nullptr)
    action->view_model()->ExecuteUserAction(
        ToolbarActionViewModel::InvocationSource::kToolbarButton);
}

void AuxAgentIdentity::Update(AuxChatsTransport& source, int account, AgentIdentity next) {
  if (&source == own_feed_.get()) {
    own_fed_ = true;
  } else {
    fed_ = true;
    own_feed_.reset();
  }
  Profile* profile = browser_ ? browser_->GetProfile() : nullptr;
  if (profile != profile_.get()) {
    profile_ = profile ? profile->GetWeakPtr() : nullptr;
    Reset();
  }
  const bool account_changed = account_ != account;
  const bool avatar_changed = account_changed || next.avatar_revision != identity_.avatar_revision;
  if (!avatar_changed && next == identity_) {
    if (avatar_wanted_ && base::TimeTicks::Now() >= next_avatar_attempt_) FetchAvatar(source);
    return;
  }
  account_ = account;
  identity_ = std::move(next);
  if (avatar_changed) {
    ++avatar_generation_;
    avatar_wanted_ = !identity_.avatar_revision.empty();
    // Keep showing the previous picture until its replacement decodes.
    if (account_changed || !avatar_wanted_) avatar_ = gfx::ImageSkia();
    if (avatar_wanted_) FetchAvatar(source);
  }
  Notify();
}

void AuxAgentIdentity::CheckFeed() {
  Profile* profile = browser_ ? browser_->GetProfile() : nullptr;
  if (profile != profile_.get()) {
    profile_ = profile ? profile->GetWeakPtr() : nullptr;
    own_feed_.reset();
    Reset();
  }
  if (std::exchange(fed_, false) || !profile_ || profile_->IsOffTheRecord()) return;
  // A quiet transport of our own (daemon restarting, Agent reinstalled) is
  // replaced; Start is a no-op while the Agent is not installed.
  if (own_feed_ && std::exchange(own_fed_, false)) return;
  own_feed_ = std::make_unique<AuxChatsTransport>(*browser_, base::DoNothing());
  own_feed_->Start();
}

void AuxAgentIdentity::Reset() {
  account_.reset();
  identity_ = AgentIdentity();
  avatar_ = gfx::ImageSkia();
  avatar_wanted_ = false;
  ++avatar_generation_;
  Notify();
}

void AuxAgentIdentity::FetchAvatar(AuxChatsTransport& source) {
  next_avatar_attempt_ = base::TimeTicks::Now() + kAvatarRetryDelay;
  source.FetchAgentAvatar(*account_, base::BindOnce(&AuxAgentIdentity::AvatarLoaded,
                                                    weak_.GetWeakPtr(), avatar_generation_));
}

void AuxAgentIdentity::AvatarLoaded(uint64_t generation, std::optional<std::string> png) {
  if (generation != avatar_generation_ || !png || png->empty()) return;
  // Decoded in the sandboxed data decoder, never in the browser process.
  data_decoder::DecodeImageIsolated(base::as_byte_span(*png),
      data_decoder::mojom::ImageCodec::kDefault, /*shrink_to_fit=*/true,
      kAvatarMaxDecodedBytes, gfx::Size(),
      base::BindOnce(&AuxAgentIdentity::AvatarDecoded, weak_.GetWeakPtr(), generation));
}

void AuxAgentIdentity::AvatarDecoded(uint64_t generation, const SkBitmap& bitmap) {
  if (generation != avatar_generation_ || bitmap.drawsNothing()) return;
  avatar_ = gfx::ImageSkia::CreateFrom1xBitmap(bitmap);
  next_avatar_attempt_ = base::TimeTicks::Max();
  Notify();
}

void AuxAgentIdentity::Notify() {
  changed_.Notify();
}

void PaintOtto(gfx::Canvas* canvas, const gfx::RectF& bounds) {
  // A 100-unit box; the extension draws the same shape (aux-agent-ui.js, MASCOT).
  const float unit = bounds.width() / 100;
  const auto at = [&](float x, float y) { return gfx::PointF(bounds.x() + x * unit, bounds.y() + y * unit); };
  cc::PaintFlags body;
  body.setAntiAlias(true);
  const SkPoint ends[] = {SkPoint::Make(0, at(0, 8).y()), SkPoint::Make(0, at(0, 96).y())};
  const SkColor4f colors[] = {SkColor4f::FromColor(0xffffffff), SkColor4f::FromColor(0xffd3d7dd),
                              SkColor4f::FromColor(0xff9aa1ab)};
  const SkScalar stops[] = {0, 0.55f, 1};
  body.setShader(cc::PaintShader::MakeLinearGradient(ends, colors, stops, 3, SkTileMode::kClamp));
  canvas->DrawCircle(at(50, 52), 44 * unit, body);
  cc::PaintFlags rim;
  rim.setAntiAlias(true);
  rim.setStyle(cc::PaintFlags::kStroke_Style);
  rim.setStrokeWidth(std::max(0.75f, 1.5f * unit));
  rim.setColor(0x1f000000);
  canvas->DrawCircle(at(50, 52), 44 * unit, rim);
  cc::PaintFlags shine;
  shine.setAntiAlias(true);
  shine.setColor(0x59ffffff);
  canvas->DrawPath(SkPath::Oval(gfx::RectFToSkRect(gfx::RectF(at(29, 19), gfx::SizeF(42 * unit, 16 * unit)))), shine);
  cc::PaintFlags eye;
  eye.setAntiAlias(true);
  eye.setColor(0xff1b1d21);
  for (const float x : {34.f, 66.f})
    canvas->DrawRoundRect(gfx::RectF(at(x - 5, 40), gfx::SizeF(10 * unit, 18 * unit)), 5 * unit, eye);
}

namespace {
class OttoSource : public gfx::CanvasImageSource {
 public:
  explicit OttoSource(int size) : gfx::CanvasImageSource(gfx::Size(size, size)) {}
  void Draw(gfx::Canvas* canvas) override { PaintOtto(canvas, gfx::RectF(gfx::SizeF(size()))); }
};
}  // namespace

ui::ImageModel AgentIcon(const AuxAgentIdentity* identity, int size) {
  if (!identity || identity->avatar().isNull())
    return ui::ImageModel::FromImageSkia(gfx::CanvasImageSource::MakeImageSkia<OttoSource>(size));
  return ui::ImageModel::FromImage(profiles::GetSizedAvatarIcon(
      gfx::Image(identity->avatar()), size, size, profiles::SHAPE_CIRCLE));
}

std::u16string AskAgentText(const AuxAgentIdentity* identity) {
  return l10n_util::GetStringFUTF16(IDS_AUX_ASK_AGENT,
      identity ? identity->identity().name : AgentIdentity().name);
}

std::u16string AgentStatusAnnouncement(ChatStatus previous, const AgentIdentity& identity) {
  if (identity.status == previous) return {};
  switch (identity.status) {
    case ChatStatus::kRunning:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_WORKING, identity.name);
    case ChatStatus::kAwaitingApproval:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_NEEDS_APPROVAL, identity.name);
    case ChatStatus::kAwaitingAnswer:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_HAS_QUESTION, identity.name);
    case ChatStatus::kFinishedUnread:
      return l10n_util::GetStringFUTF16(IDS_AUX_AGENT_REPLIED, identity.name);
    default:
      return {};
  }
}
}  // namespace aux
